package com.modcustom.moddev.fabric;

import com.modcustom.moddev.SpeedBuild;
import com.modcustom.moddev.SpeedBuildClient;
import com.modcustom.moddev.api.LevelRenderLastEvent;
import dev.architectury.utils.Env;
import dev.architectury.utils.EnvExecutor;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;

public class SpeedBuildFabric implements ModInitializer {

    @Override
    public void onInitialize() {
        SpeedBuild.init();
        EnvExecutor.runInEnv(Env.CLIENT, () -> () -> {
            WorldRenderEvents.AFTER_TRANSLUCENT.register((ctx) -> LevelRenderLastEvent.EVENT.invoker().onRenderLast(ctx.matrixStack()));
            SpeedBuildClient.init();
        });
    }
}