package com.modcustom.moddev.mixin;

import com.modcustom.moddev.api.LivingFallEvent;
import com.modcustom.moddev.api.SpawnerProvider;
import com.modcustom.moddev.events.EntityEventHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.UUID;

@Mixin(Entity.class)
public abstract class EntityMixin implements SpawnerProvider {

    @Shadow
    public float fallDistance;
    @Shadow
    private Level level;
    @Unique
    @Nullable
    private UUID spawner;

    @Shadow
    public abstract Level level();

    @Inject(method = "move", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;checkFallDamage(DZLnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;)V"))
    public void speed_build$checkFallDamage(MoverType type, Vec3 pos, CallbackInfo ci) {
        Entity entity = (Entity) (Object) this;
        if (entity instanceof LivingEntity living && this.onGround() && this.fallDistance > 0.0) {
            BlockPos blockPos = this.getOnPosLegacy();
            LivingFallEvent.EVENT.invoker().onLivingFall(living, this.level.getBlockState(blockPos), blockPos);
        }
    }

    @Shadow
    public abstract boolean onGround();

    @Shadow
    @Deprecated
    public abstract BlockPos getOnPosLegacy();

    @Inject(method = "saveWithoutId", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;addAdditionalSaveData(Lnet/minecraft/nbt/CompoundTag;)V", shift = At.Shift.AFTER))
    private void speed_build$saveWithoutId(CompoundTag compound, CallbackInfoReturnable<CompoundTag> cir) {
        UUID spawner = getSpawner();
        if (spawner != null) {
            compound.putUUID("ItemSpawnOwner", spawner);
        }
    }

    @Nullable
    @Override
    public UUID getSpawner() {
        return spawner;
    }

    @Override
    public void setSpawner(@Nullable UUID spawner) {
        this.spawner = spawner;
    }

    @Inject(method = "load", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;readAdditionalSaveData(Lnet/minecraft/nbt/CompoundTag;)V", shift = At.Shift.AFTER))
    private void speed_build$load(CompoundTag compound, CallbackInfo ci) {
        if (compound.hasUUID("ItemSpawnOwner")) {
            setSpawner(compound.getUUID("ItemSpawnOwner"));
        }
    }

    @Inject(method = "hurt", at = @At(value = "HEAD"))
    private void speed_build$hurt(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        Entity entity = (Entity) (Object) this;
        EntityEventHandler.handleEntityHurt(entity, source, amount);
    }
}
