package com.modcustom.moddev.commands.common;

import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.data.GameData;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.world.phys.Vec3;

public class QCCommand extends CommonCommand {

    public QCCommand() {
        super("qc");
    }

    @Override
    public LiteralArgumentBuilder<CommandSourceStack> build(LiteralArgumentBuilder<CommandSourceStack> builder, CommandBuildContext context) {
        return builder.executes(this::executeResetConstructionArea);
    }

    private int executeResetConstructionArea(CommandContext<CommandSourceStack> context) {
        CommandSourceStack source = context.getSource();
        Vec3 pos = source.getPosition();

        ActivityArea area = GameData.getGameData(context).getNearestActivityArea(source.getLevel(), pos, 15);

        if (area != null) {
            area.startResetConstructionAreaTask(source.getLevel());
            return 1;
        }
        return 0;
    }
}
