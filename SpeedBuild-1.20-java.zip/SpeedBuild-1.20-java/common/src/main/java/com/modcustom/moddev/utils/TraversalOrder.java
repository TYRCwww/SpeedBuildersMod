package com.modcustom.moddev.utils;

import com.modcustom.moddev.api.SerializableData;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.levelgen.structure.BoundingBox;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class TraversalOrder implements SerializableData<TraversalOrder> {

    private AxisOrder order;
    private boolean xDescending;
    private boolean yDescending;
    private boolean zDescending;

    protected TraversalOrder(AxisOrder order, boolean xDescending, boolean yDescending, boolean zDescending) {
        this.order = order;
        this.xDescending = xDescending;
        this.yDescending = yDescending;
        this.zDescending = zDescending;
    }

    public AxisOrder getOrder() {
        return order;
    }

    public void setOrder(AxisOrder order) {
        this.order = order;
    }

    public boolean isXDescending() {
        return xDescending;
    }

    public void setXDescending(boolean xDescending) {
        this.xDescending = xDescending;
    }

    public boolean isYDescending() {
        return yDescending;
    }

    public void setYDescending(boolean yDescending) {
        this.yDescending = yDescending;
    }

    public boolean isZDescending() {
        return zDescending;
    }

    public void setZDescending(boolean zDescending) {
        this.zDescending = zDescending;
    }

    public void setDescending(Direction.Axis axis, boolean descending) {
        switch (axis) {
            case X -> this.xDescending = descending;
            case Y -> this.yDescending = descending;
            case Z -> this.zDescending = descending;
        }
    }

    public void generatePositions(BoundingBox boundingBox, Consumer<BlockPos> consumer) {
        order.traverse(boundingBox, xDescending, yDescending, zDescending, consumer);
    }

    public List<BlockPos> toList(BoundingBox boundingBox) {
        List<BlockPos> positions = new ArrayList<>();
        generatePositions(boundingBox, positions::add);
        return positions;
    }

    @Override
    public void save(CompoundTag tag) {
        tag.putInt("order", order.ordinal());
        tag.putBoolean("xDescending", xDescending);
        tag.putBoolean("yDescending", yDescending);
        tag.putBoolean("zDescending", zDescending);
    }

    @Override
    public void load(CompoundTag tag) {
        if (tag.contains("order")) {
            int order = tag.getInt("order");
            if (order >= 0 && order < AxisOrder.values().length) {
                this.order = AxisOrder.values()[order];
            }
        }
        if (tag.contains("xDescending")) {
            this.xDescending = tag.getBoolean("xDescending");
        }
        if (tag.contains("yDescending")) {
            this.yDescending = tag.getBoolean("yDescending");
        }
        if (tag.contains("zDescending")) {
            this.zDescending = tag.getBoolean("zDescending");
        }
    }

    @Override
    public void copyFrom(TraversalOrder order) {
        this.order = order.order;
        this.xDescending = order.xDescending;
        this.yDescending = order.yDescending;
        this.zDescending = order.zDescending;
    }

    public static TraversalOrder fromNbt(CompoundTag tag) {
        AxisOrder order = AxisOrder.fromStringOrDefault(tag.getString("order"), AxisOrder.XZY);
        boolean xDescending = tag.getBoolean("xDescending");
        boolean yDescending = tag.getBoolean("yDescending");
        boolean zDescending = tag.getBoolean("zDescending");
        return new TraversalOrder(order, xDescending, yDescending, zDescending);
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {

        private AxisOrder order = AxisOrder.XZY;
        private boolean xDescending = false;
        private boolean yDescending = false;
        private boolean zDescending = false;

        public Builder order(AxisOrder order) {
            this.order = order;
            return this;
        }

        public Builder xDescending(boolean xDescending) {
            this.xDescending = xDescending;
            return this;
        }

        public Builder yDescending(boolean yDescending) {
            this.yDescending = yDescending;
            return this;
        }

        public Builder zDescending(boolean zDescending) {
            this.zDescending = zDescending;
            return this;
        }

        public TraversalOrder build() {
            return new TraversalOrder(order, xDescending, yDescending, zDescending);
        }
    }
}
