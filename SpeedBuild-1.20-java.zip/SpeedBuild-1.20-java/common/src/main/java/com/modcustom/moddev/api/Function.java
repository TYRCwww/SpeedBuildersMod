package com.modcustom.moddev.api;

import com.modcustom.moddev.utils.ActionResult;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public interface Function {

    default Component getDisplayName() {
        return Component.translatable("function." + getId().toLanguageKey());
    }

    ResourceLocation getId();

    @Nullable
    default Component getDescription() {
        String key = "function." + getId().toLanguageKey() + ".description";
        return Component.translatable(key);
    }

    default void copyFrom(Function function) {
        readNbt(function.writeNbt(new CompoundTag()));
    }

    default CompoundTag writeNbt(CompoundTag tag) {
        tag.putString("id", getId().toString());
        return tag;
    }

    default void readNbt(CompoundTag tag) {

    }

    default ActionResult execute(Level level, @Nullable BlockPos interactionPos, Player player, @Nullable InteractionHand hand) {
        return execute(level, player.blockPosition(), interactionPos, player, hand);
    }

    ActionResult execute(Level level, BlockPos executionPos, @Nullable BlockPos interactionPos, Player player, @Nullable InteractionHand hand);

    default ActionResult execute(Level level, BlockPos executionPos) {
        return execute(level, executionPos, null, null, null);
    }
}
