package com.modcustom.moddev.client;

import com.modcustom.moddev.api.LevelRenderLastEvent;
import com.modcustom.moddev.blocks.entities.TranslucentBlockEntity;
import com.modcustom.moddev.client.screen.SyncScreen;
import com.modcustom.moddev.config.Config;
import com.modcustom.moddev.game.AreaSelector;
import com.modcustom.moddev.game.activity.ActivityRecord;
import com.modcustom.moddev.game.area.*;
import com.modcustom.moddev.game.data.ClientCachedData;
import com.modcustom.moddev.network.Network;
import com.modcustom.moddev.network.c2s.RequestSyncC2SPacket;
import com.modcustom.moddev.registry.ModBlocks;
import com.modcustom.moddev.registry.ModKeys;
import com.modcustom.moddev.utils.Timer;
import com.modcustom.moddev.utils.*;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.datafixers.util.Pair;
import dev.architectury.event.events.client.ClientGuiEvent;
import dev.architectury.event.events.client.ClientPlayerEvent;
import dev.architectury.event.events.client.ClientTickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Position;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.awt.*;
import java.util.List;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.modcustom.moddev.utils.Util.drawCenteredStringWithBackground;

@Environment(EnvType.CLIENT)
public class ClientGameManager {

    private static final double AREA_SELECTION_RENDERING_ALPHA = 0.25;
    private static final double SPECIAL_AREA_RENDERING_ALPHA = 0.1;
    private static ClientGameManager instance;
    private final ClientCachedData cachedData = new ClientCachedData();
    private final AreaSelector targetAreaSelector = new AreaSelector();
    private final AreaSelector constructionAreaSelector = new AreaSelector();
    private final AreaSelector protectedAreaSelector = new AreaSelector();
    private final AreaSelector functionAreaSelector = new AreaSelector();
    private final Map<Integer, ActivityArea> cachedServerAreas = new ConcurrentHashMap<>();
    private final Map<String, List<ProtectedArea>> cachedProtectedAreas = new ConcurrentHashMap<>();
    private final Map<String, List<FunctionArea>> cachedFunctionAreas = new ConcurrentHashMap<>();
    private final Map<ClientLevel, Set<BlockPos>> serverUpdatingBlocks = new ConcurrentHashMap<>();
    private final Map<Integer, Pair<Set<BlockPos>, Set<BlockPos>>> serverDifferentBlocks = new ConcurrentHashMap<>();
    private int activityId = -1;
    private int previewActivityId = -1;
    private Timer activityTimer = new Timer();
    private boolean displayTimer = true;
    private String lastScore = "00:00.000";
    private String countdownText;
    private int countdownTimer;
    @Nullable
    private String scoreText;
    private int scoreTimer;
    @Nullable
    private BlockPos targetPreviewPos;
    @Nullable
    private BlockPos constructionPreviewPos;
    @Nullable
    private BlockPos protectedPreviewPos;
    @Nullable
    private BlockPos functionPreviewPos;

    public boolean isSecondPos() {
        return targetAreaSelector.hasStart();
    }

    public AreaSelector getProtectedAreaSelector() {
        return protectedAreaSelector;
    }

    public void selectTargetPos(Level level, BlockPos pos) {
        if (targetAreaSelector.select(level, pos)) {
            constructionAreaSelector.clear();
        }
    }

    public boolean selectConstructionPos(Level level, BlockPos pos) {
        Area area = constructionAreaSelector.selectWithSelector(level, pos, targetAreaSelector);
        if (area == null) return false;
        sendAreaToServer();
        Area targetArea = targetAreaSelector.getArea();
        if (targetArea != null && area.intersects(targetArea)) {
            constructionAreaSelector.clear();
        } else {
            clear();
        }
        return true;
    }

    public void sendAreaToServer() {
        Area targetArea = targetAreaSelector.getArea();
        Area constructionArea = constructionAreaSelector.getArea();
        if (constructionArea != null && targetArea != null) {
            Network.requestCreateArea(constructionArea, targetArea);
        }
    }

    public void clear() {
        targetAreaSelector.clear();
        constructionAreaSelector.clear();
    }

    public void setCachedServerAreas(Collection<ActivityArea> areas) {
        Set<Integer> ids = cachedServerAreas.keySet();
        cachedServerAreas.clear();
        addCachedServerAreas(areas);
        for (int id : ids) {
            if (!cachedServerAreas.containsKey(id)) {
                clearDifferentBlocks(id);
            }
        }
        updateScreen();
    }

    public void addCachedServerAreas(Collection<ActivityArea> areas) {
        areas.forEach(area -> cachedServerAreas.put(area.getId(), area));
        updateScreen();
    }

    private static void updateScreen() {
        Screen screen = Minecraft.getInstance().screen;
        if (screen instanceof SyncScreen syncScreen) {
            syncScreen.update();
        }
    }

    public void clearDifferentBlocks(int areaId) {
        serverDifferentBlocks.remove(areaId);
    }

    public void setProtectedAreas(Map<String, List<ProtectedArea>> areas) {
        cachedProtectedAreas.clear();
        areas.forEach((key, value) -> cachedProtectedAreas.put(key, new ArrayList<>(value)));
    }

    public void addProtectedAreas(Map<String, List<ProtectedArea>> areas) {
        areas.forEach((key, value) -> cachedProtectedAreas.computeIfAbsent(key, k -> new ArrayList<>()).addAll(value));
        updateScreen();
    }

    public void clearProtectedSelection() {
        protectedAreaSelector.clear();
    }

    public void setFunctionAreas(Map<String, List<FunctionArea>> areas) {
        cachedFunctionAreas.clear();
        areas.forEach((key, value) -> cachedFunctionAreas.put(key, new ArrayList<>(value)));
        updateScreen();
    }

    public void addFunctionAreas(Map<String, List<FunctionArea>> areas) {
        areas.forEach((key, value) -> cachedFunctionAreas.computeIfAbsent(key, k -> new ArrayList<>()).addAll(value));
        updateScreen();
    }

    public void clearFunctionSelection() {
        functionAreaSelector.clear();
        updateScreen();
    }

    public void updateAreaConfig(int id, AreaConfig config) {
        ActivityArea area = cachedServerAreas.get(id);
        if (area != null) {
            area.getConfig().copy(config);
        } else {
            Network.requestSync(RequestSyncC2SPacket.Type.ACTIVITY_AREAS);
        }
        updateScreen();
    }

    public void updateAreaHistory(int id, List<ActivityRecord> history, boolean replace) {
        ActivityArea area = cachedServerAreas.get(id);
        if (area != null) {
            if (replace) {
                area.setHistory(history);
            } else {
                area.addHistory(history);
                area.limitAndSortHistory();
            }
            updateScreen();
        } else {
            Network.requestSync(RequestSyncC2SPacket.Type.ACTIVITY_AREAS);
        }
    }

    @Nullable
    public ActivityArea getActivityArea(Level level, BlockPos pos, Direction face) {
        return getActivityAreas(level, pos).stream().findFirst().or(() -> getActivityAreas(level, pos.relative(face)).stream().findFirst()).orElse(null);
    }

    public List<ActivityArea> getActivityAreas(Level level, BlockPos pos) {
        return getActivityAreas(level, area -> area.contains(pos));
    }

    public List<ActivityArea> getActivityAreas(Level level, Predicate<ActivityArea> predicate) {
        String dimension = level.dimension().location().toString();
        return cachedServerAreas.values()
                                .stream()
                                .filter(area -> area.getDimension().equals(dimension) && predicate.test(area))
                                .collect(Collectors.toList());
    }

    public ActivityArea getNearestArea(Level level, BlockPos pos, int inflate, Predicate<ActivityArea> predicate) {
        String dimension = level.dimension().location().toString();
        return cachedServerAreas.values().stream()
                                .filter(area -> area.getDimension().equals(dimension) &&
                                                area.contains(pos, inflate) &&
                                                predicate.test(area))
                                .min(Comparator.comparing(area -> area.distanceTo(pos)))
                                .orElse(null);
    }

    public void startActivity(int id) {
        startActivity(id, 0L);
    }

    public void startActivity(int id, long startTime) {
        clearDifferentBlocks(id);
        if (cachedServerAreas.get(id) == null) Network.requestSync(RequestSyncC2SPacket.Type.ACTIVITY_AREAS);
        if (!activityTimer.isRunning() || activityId < 0 || activityId != id) activityTimer.start(startTime);
        activityId = id;
        previewActivityId = -1;
    }

    public void previewActivity(int id) {
        previewActivityId = id;
    }

    public void toggleTimer() {
        if (activityId >= 0) {
            activityTimer.toggle();
        }
    }

    public void startTimer() {
        if (!activityTimer.isRunning() && !activityTimer.isPaused()) {
            activityTimer.start();
        }
    }

    public void stopTimer() {
        if (activityTimer.isRunning() || activityTimer.isPaused()) {
            long time = activityTimer.stop();
            lastScore = Timer.formatTime(time);
        }
    }

    public void toggleTimerDisplay() {
        displayTimer = !displayTimer;
    }

    public void finishActivity(int id, @Nullable Long timeFix) {
        if (cachedServerAreas.get(id) == null) Network.requestSync(RequestSyncC2SPacket.Type.ACTIVITY_AREAS);
        if (activityId >= 0 && activityId == id) {
            long time = finishActivity(timeFix);
            scoreText = cachedServerAreas.get(id).getConfig().formattedScoreText(Timer.formatTime(time));
            scoreTimer = 3 * 20;
        }
    }

    public long finishActivity(@Nullable Long timeFix) {
        clearDifferentBlocks(activityId);
        activityId = -1;
        countdownTimer = 0;
        long time = activityTimer.stop(timeFix);
        lastScore = Timer.formatTime(time);
        return time;
    }

    public long finishActivity() {
        return finishActivity(null);
    }

    public boolean hasActivity(int id) {
        return activityId >= 0 && activityId == id;
    }

    public void updateCountdown(String text, int time) {
        countdownText = text;
        countdownTimer = time;
    }

    public boolean isProtected(Level level, BlockPos pos) {
        return getProtectedAreas(level).stream().anyMatch(area -> area.contains(pos) && area.isActive());
    }

    public boolean consumeServerUpdate(ClientLevel level, BlockPos pos) {
        return getServerUpdatingBlocks(level).remove(pos);
    }

    public boolean intersectsAnyArea(Level level, Area area, boolean includeActivity, boolean includeProtected, boolean includeFunction) {
        String dimension = level.dimension().location().toString();
        if (includeActivity && !getActivityAreas(level, a -> a.getDimension().equals(dimension) && a.intersects(area)).isEmpty()) {
            return true;
        }
        if (includeProtected && getProtectedAreas(level).stream().anyMatch(a -> a.intersects(area))) {
            return true;
        }
        return includeFunction && getFunctionAreas(level).stream().anyMatch(a -> a.intersects(area));
    }

    private void renderActivity(PoseStack poseStack, Player player) {
        String dimension = player.level().dimension().location().toString();
        ActivityArea area = cachedServerAreas.get(activityId >= 0 ? activityId : previewActivityId);

        boolean isAreaVisible = ItemUtil.isActivityAreaVisible(player.getMainHandItem()) || ItemUtil.isActivityAreaVisible(player.getOffhandItem());
        boolean shouldRender = area != null &&
                               area.getDimension().equals(dimension) &&
                               !isShowingDifference(area.getId()) &&
                               (area.getConfig().isRenderBorder() || isAreaVisible) &&
                               isInRenderDistance(player, area);

        if (shouldRender) {
            area.getConstruction().render(poseStack, Config.getInstance().getConstructionAreaColor());
            area.getTarget().render(poseStack, Config.getInstance().getTargetAreaColor());
        }
    }

    @Nullable
    public FunctionArea getFunctionArea(Level level, BlockPos pos) {
        return getFunctionAreas(level).stream().filter(area -> area.contains(pos)).findFirst().orElse(null);
    }

    @Nullable
    public FunctionArea getFunctionArea(Level level, BlockPos pos, Direction face) {
        return Optional.ofNullable(getFunctionArea(level, pos)).or(() -> Optional.ofNullable(getFunctionArea(level, pos.relative(face)))).orElse(null);
    }

    @Nullable
    public FunctionArea getFunctionArea(int id) {
        return cachedFunctionAreas.entrySet().stream().flatMap(entry -> entry.getValue().stream()).filter(area -> area.getId() == id).findFirst().orElse(null);
    }

    public boolean isLocked(Level level, BlockPos pos) {
        return getFunctionAreas(level).stream().anyMatch(area -> area.contains(pos) && area.isLocked());
    }

    public ClientCachedData getCachedData() {
        return cachedData;
    }

    public void setCachedData(ClientCachedData cachedData) {
        this.cachedData.copyFrom(cachedData);
    }

    public @Nullable BlockPos getTargetPreviewPos() {
        return targetPreviewPos;
    }

    public void setTargetPreviewPos(@Nullable BlockPos targetPreviewPos) {
        this.targetPreviewPos = targetPreviewPos;
    }

    public @Nullable BlockPos getConstructionPreviewPos() {
        return constructionPreviewPos;
    }

    public void setConstructionPreviewPos(@Nullable BlockPos constructionPreviewPos) {
        this.constructionPreviewPos = constructionPreviewPos;
    }

    @Nullable
    public BlockPos getProtectedPreviewPos() {
        return protectedPreviewPos;
    }

    public void setProtectedPreviewPos(@Nullable BlockPos protectedPreviewPos) {
        this.protectedPreviewPos = protectedPreviewPos;
    }

    @Nullable
    public BlockPos getFunctionPreviewPos() {
        return functionPreviewPos;
    }

    public void setFunctionPreviewPos(@Nullable BlockPos functionPreviewPos) {
        this.functionPreviewPos = functionPreviewPos;
    }

    public Timer getActivityTimer() {
        return activityTimer;
    }

    public void setActivityTimer(Timer activityTimer) {
        this.activityTimer = activityTimer;
    }

    public boolean isShowingDifference(int areaId) {
        return getServerDifferentBlocks(areaId) != null;
    }

    private Set<BlockPos> getServerUpdatingBlocks(ClientLevel level) {
        return serverUpdatingBlocks.computeIfAbsent(level, k -> new HashSet<>());
    }

    public void addServerUpdate(ClientLevel level, BlockPos pos) {
        getServerUpdatingBlocks(level).add(pos);
    }

    public void setServerDifferentBlocks(int areaId, Pair<Set<BlockPos>, Set<BlockPos>> blocks) {
        if (blocks == null) {
            clearDifferentBlocks(areaId);
        } else {
            serverDifferentBlocks.put(areaId, blocks);
        }
        updateScreen();
    }

    public List<ActivityArea> getActivityAreasShowingDifference(Level level, BlockPos pos) {
        return getActivityAreas(level, area -> area.contains(pos) && serverDifferentBlocks.containsKey(area.getId()));
    }

    public boolean isDifferentBlock(Level level, BlockPos pos) {
        return !getActivityAreas(level, area -> area.contains(pos) && serverDifferentBlocks.containsKey(area.getId())).isEmpty();
    }

    public AreaSelector getFunctionAreaSelector() {
        return functionAreaSelector;
    }

    public static void register() {
        LevelRenderLastEvent.EVENT.register(poseStack -> ClientGameManager.getInstance().render(poseStack));
        ClientTickEvent.CLIENT_LEVEL_POST.register(level -> ClientGameManager.getInstance().tick(level));
        ClientGuiEvent.RENDER_HUD.register((guiGraphics, delta) -> ClientGameManager.getInstance().renderHud(guiGraphics));
        ClientPlayerEvent.CLIENT_PLAYER_QUIT.register(player -> ClientGameManager.getInstance().resetManager());
    }

    public void render(PoseStack poseStack) {
        Player player = Minecraft.getInstance().player;
        if (player != null) {
            renderActivity(poseStack, player);
            renderPreviewTargetArea(poseStack, player);
            renderPreviewConstructionArea(poseStack, player);
            renderCachedActivityAreas(poseStack, player);
            renderTempActivityAreas(poseStack, player);
            renderDifferentBlocks(poseStack, player);

            renderPreviewProtectedArea(poseStack, player);
            renderProtectedAreas(poseStack, player);
            renderTempProtectedArea(poseStack, player);

            renderPreviewFunctionArea(poseStack, player);
            renderFunctionAreas(poseStack, player);
            renderTempFunctionArea(poseStack, player);
        }
    }

    @Nullable
    public Pair<Set<BlockPos>, Set<BlockPos>> getServerDifferentBlocks(int areaId) {
        return serverDifferentBlocks.get(areaId);
    }

    private boolean isInRenderDistance(Player player, Area area) {
        return area.contains(player.blockPosition(), Config.getInstance().getMaxRenderDistance());
    }

    private void renderPreviewTargetArea(PoseStack poseStack, Player player) {
        ItemStack mainStack = player.getMainHandItem();
        if (!targetAreaSelector.hasArea() && ItemUtil.isTargetAreaSelection(mainStack) && ModKeys.AIR_SELECTION.isDown()) {
            HitResult hitResult = Minecraft.getInstance().hitResult;
            if (hitResult != null) {
                BlockPos pos;
                if ((hitResult.getType() == HitResult.Type.BLOCK)) {
                    pos = ((BlockHitResult) hitResult).getBlockPos();
                } else {
                    Position position = hitResult.getLocation();
                    pos = BlockPos.containing(position);
                }
                targetPreviewPos = pos;
                RenderUtil.render(poseStack, Config.getInstance().getTargetAreaColor(), new AABB(pos));
                BlockPos start = targetAreaSelector.getStart();
                if (start != null) {
                    RenderUtil.render(poseStack, Config.getInstance().getTargetAreaColor(), AABB.of(BoundingBox.fromCorners(start, pos)));
                }
            }
        } else {
            targetPreviewPos = null;
        }
    }

    private void renderCachedActivityAreas(PoseStack poseStack, Player player) {
        ItemStack offStack = player.getOffhandItem();
        ItemStack mainStack = player.getMainHandItem();
        if (!ItemUtil.isActivityAreaVisible(mainStack) && !ItemUtil.isActivityAreaVisible(offStack)) return;
        String dimension = player.level().dimension().location().toString();
        ActivityArea airArea = PlayerUtil.findFirstActivityArea(player, 5);
        cachedServerAreas.values().stream()
                         .filter(area -> area.getDimension().equals(dimension) &&
                                         (activityId < 0 || area.getId() != activityId) &&
                                         (previewActivityId < 0 || area.getId() != previewActivityId) &&
                                         isInRenderDistance(player, area))
                         .forEach(area -> {
                             int color = (ItemUtil.isActivityAreaConfiguration(mainStack) || ItemUtil.isActivityAreaConfiguration(offStack)) && area.equals(airArea)
                                         ? Color.CYAN.getRGB()
                                         : Config.getInstance().getCombinationAreaColor();
                             area.render(poseStack, color);
                             RenderUtil.renderAreaId(poseStack, area, area.getId());
                         });
    }

    private void renderPreviewConstructionArea(PoseStack poseStack, Area targetArea, Player player) {
        ItemStack offStack = player.getOffhandItem();
        ItemStack mainStack = player.getMainHandItem();
        HitResult hitResult = Minecraft.getInstance().hitResult;
        if (!ItemUtil.isConstructionAreaSelection(mainStack) && !ItemUtil.isConstructionAreaSelection(offStack)) return;
        if (hitResult instanceof BlockHitResult blockHitResult && hitResult.getType() == HitResult.Type.BLOCK) {
            BlockPos pos = blockHitResult.getBlockPos();
            Direction face = blockHitResult.getDirection();
            Area area = new Area(face == Direction.UP ? pos.relative(face) : pos, targetArea);
            area.render(poseStack, area.intersects(targetArea) ? Color.RED.getRGB() : Config.getInstance().getPreviewAreaColor());
        }
    }

    private void renderPreviewConstructionArea(PoseStack poseStack, Player player) {
        Area targetArea = targetAreaSelector.getArea();
        if (targetArea != null && ItemUtil.isConstructionAreaSelection(player.getMainHandItem()) && ModKeys.AIR_SELECTION.isDown()) {
            HitResult hitResult = Minecraft.getInstance().hitResult;
            if (hitResult != null && hitResult.getType() == HitResult.Type.BLOCK) {
                BlockHitResult blockHitResult = (BlockHitResult) hitResult;
                BlockPos pos = blockHitResult.getBlockPos();
                if (blockHitResult.getDirection() == Direction.UP) pos = pos.relative(Direction.UP);
                constructionPreviewPos = pos;
                Area area = new Area(pos, targetArea);
                int color = area.intersects(targetArea) ? Color.RED.getRGB() : Config.getInstance().getPreviewAreaColor();
                RenderUtil.render(poseStack, color, new AABB(pos));
                RenderUtil.render(poseStack, color, area.getBox());
            }
        } else {
            constructionPreviewPos = null;
        }
    }

    private void renderDifferentBlocks(PoseStack poseStack, Player player) {
        if (!hasActivity()) return;
        ActivityArea area = getActivityAreas(activityId);
        if (area == null) return;
        Level level = player.level();
        if (!level.dimension().location().toString().equals(area.getDimension())) return;
        Pair<Set<BlockPos>, Set<BlockPos>> blocks = getServerDifferentBlocks(activityId);
        if (blocks == null) return;
        List<BlockPos> constructionBlocks = area.getConstructionAreaBlocks();

        Vec3 position = Minecraft.getInstance().getEntityRenderDispatcher().camera.getPosition();

        Map<BlockPos, Integer> blockMap = new HashMap<>();

        int transparency = Config.getInstance().getDifferenceBlockRenderingTransparency();
        float alpha = Mth.clamp(transparency / 255f, 0f, 1f);
        int rgb = Util.getRGBWithAlpha(Color.RED, alpha);
        int rgb1 = Util.getRGBWithAlpha(Color.YELLOW, alpha);

        blocks.getFirst().forEach(pos -> blockMap.put(pos, rgb));
        blocks.getSecond().forEach(pos -> blockMap.put(pos, rgb1));

        blockMap.entrySet().stream()
                .sorted(Comparator.comparingDouble(e -> -e.getKey().distToCenterSqr(position)))
                .forEach(e -> {
                    RenderUtil.render(poseStack, 0xFFFFFFFF, e.getValue(), new AABB(e.getKey()));
                    constructionBlocks.remove(e.getKey());
                });

        for (BlockPos pos : constructionBlocks) {
            BlockState state = level.getBlockState(pos);
            if (state.isAir() || state.is(ModBlocks.TRANSLUCENT_BLOCK.get())) continue;
            level.setBlock(pos, ModBlocks.TRANSLUCENT_BLOCK.get().defaultBlockState(), Block.UPDATE_CLIENTS);
            BlockEntity blockEntity = level.getBlockEntity(pos);
            if (blockEntity instanceof TranslucentBlockEntity entity) {
                entity.setRenderingState(state);
            }
        }
    }

    private void renderTempActivityAreas(PoseStack poseStack, Player player) {
        ResourceLocation dimension = player.level().dimension().location();
        BlockPos startTargetPos = targetAreaSelector.getStart();
        Area targetArea = targetAreaSelector.getArea();
        Area constructionArea = constructionAreaSelector.getArea();
        ResourceLocation targetDimension = targetAreaSelector.getDimension();
        if (!dimension.equals(targetDimension)) return;
        Config config = Config.getInstance();
        if (targetArea != null && constructionArea != null && (isInRenderDistance(player, targetArea) || isInRenderDistance(player, constructionArea))) {
            ActivityArea.render(poseStack, config.getTargetAreaColor(), constructionArea, targetArea);
        }
        if (targetArea != null && isInRenderDistance(player, targetArea)) {
            targetArea.render(poseStack, config.getTargetAreaColor());
        } else if (startTargetPos != null && isInRenderDistance(player, new Area(new BoundingBox(startTargetPos)))) {
            new Area(new BoundingBox(startTargetPos)).render(poseStack, config.getTargetAreaColor());
        }
        if (constructionArea != null && isInRenderDistance(player, constructionArea)) {
            constructionArea.render(poseStack, config.getConstructionAreaColor());
        } else if (targetArea != null && isInRenderDistance(player, targetArea)) {
            renderPreviewConstructionArea(poseStack, targetArea, player);
        }
    }

    public ActivityArea getActivityAreas(int id) {
        return cachedServerAreas.get(id);
    }

    public boolean hasActivity() {
        return activityId >= 0 && activityTimer.isRunning();
    }

    private void renderPreviewProtectedArea(PoseStack poseStack, Player player) {
        ItemStack mainStack = player.getMainHandItem();
        if (!protectedAreaSelector.hasArea() && ItemUtil.isProtectedAreaSelection(mainStack)) {
            HitResult hitResult = Minecraft.getInstance().hitResult;
            if (hitResult != null) {
                BlockPos pos;
                if ((hitResult.getType() == HitResult.Type.BLOCK)) {
                    pos = ((BlockHitResult) hitResult).getBlockPos();
                } else {
                    Position position = hitResult.getLocation();
                    pos = BlockPos.containing(position);
                }
                protectedPreviewPos = pos;
                RenderUtil.render(poseStack, Util.getRGBWithAlpha(Color.WHITE, AREA_SELECTION_RENDERING_ALPHA), new AABB(pos), true);
                BlockPos start = protectedAreaSelector.getStart();
                if (start != null) {
                    RenderUtil.render(poseStack, Util.getRGBWithAlpha(Color.WHITE, AREA_SELECTION_RENDERING_ALPHA), AABB.of(BoundingBox.fromCorners(start, pos)), true);
                }
            }
        } else {
            protectedPreviewPos = null;
        }
    }

    private void renderProtectedAreas(PoseStack poseStack, Player player) {
        List<ProtectedArea> protectedAreas = getProtectedAreas(player.level());
        if (protectedAreas != null) {
            for (ProtectedArea area : protectedAreas) {
                if (isInRenderDistance(player, area) && (Config.getInstance().isProtectedAreaVisible() || ItemUtil.isProtectedAreaVisible(player.getMainHandItem()) || ItemUtil.isProtectedAreaVisible(player.getOffhandItem()) || area.getBox().contains(Minecraft.getInstance().getEntityRenderDispatcher().camera.getPosition()))) {
                    int color = Util.getRGBWithAlpha(area.isActive() ? Color.RED : Color.ORANGE, SPECIAL_AREA_RENDERING_ALPHA);
                    RenderUtil.render(poseStack, color, area.getBox(), true);
                }
            }
        }
    }

    private List<ProtectedArea> getProtectedAreas(Level level) {
        return cachedProtectedAreas.computeIfAbsent(level.dimension().location().toString(), k -> new ArrayList<>());
    }

    private void renderTempProtectedArea(PoseStack poseStack, Player player) {
        if (!player.level().dimension().location().equals(protectedAreaSelector.getDimension())) return;
        Area selectorArea = protectedAreaSelector.getArea();
        if (selectorArea != null && isInRenderDistance(player, selectorArea)) {
            RenderUtil.render(poseStack, Util.getRGBWithAlpha(Color.WHITE, AREA_SELECTION_RENDERING_ALPHA), selectorArea.getBox(), true);
        } else {
            BlockPos start = protectedAreaSelector.getStart();
            if (start != null) {
                Area area = new Area(new BoundingBox(start));
                if (isInRenderDistance(player, area)) {
                    RenderUtil.render(poseStack, Util.getRGBWithAlpha(Color.WHITE, AREA_SELECTION_RENDERING_ALPHA), area.getBox(), true);
                }
            }
        }
    }

    private void renderPreviewFunctionArea(PoseStack poseStack, Player player) {
        ItemStack mainStack = player.getMainHandItem();
        if (!functionAreaSelector.hasArea() && ItemUtil.isFunctionAreaSelection(mainStack)) {
            HitResult hitResult = Minecraft.getInstance().hitResult;
            if (hitResult != null) {
                BlockPos pos;
                if ((hitResult.getType() == HitResult.Type.BLOCK)) {
                    pos = ((BlockHitResult) hitResult).getBlockPos();
                } else {
                    Position position = hitResult.getLocation();
                    pos = BlockPos.containing(position);
                }
                functionPreviewPos = pos;
                RenderUtil.render(poseStack, Util.getRGBWithAlpha(Color.CYAN, AREA_SELECTION_RENDERING_ALPHA), new AABB(pos), true);
                BlockPos start = functionAreaSelector.getStart();
                if (start != null) {
                    RenderUtil.render(poseStack, Util.getRGBWithAlpha(Color.CYAN, AREA_SELECTION_RENDERING_ALPHA), AABB.of(BoundingBox.fromCorners(start, pos)), true);
                }
            }
        } else {
            functionPreviewPos = null;
        }
    }

    private void renderFunctionAreas(PoseStack poseStack, Player player) {
        List<FunctionArea> functionAreas = getFunctionAreas(player.level());
        if (functionAreas != null) {
            for (FunctionArea area : functionAreas) {
                if (isInRenderDistance(player, area) && (Config.getInstance().isFunctionAreaVisible() || ItemUtil.isFunctionAreaVisible(player.getMainHandItem()) || ItemUtil.isFunctionAreaVisible(player.getOffhandItem()) || area.getBox().contains(Minecraft.getInstance().getEntityRenderDispatcher().camera.getPosition()))) {
                    int color = Util.getRGBWithAlpha(Color.BLUE, SPECIAL_AREA_RENDERING_ALPHA);
                    RenderUtil.render(poseStack, color, area.getBox(), true);
                    RenderUtil.renderAreaId(poseStack, area, area.getId());
                }
            }
        }
    }

    private List<FunctionArea> getFunctionAreas(Level level) {
        return cachedFunctionAreas.computeIfAbsent(level.dimension().location().toString(), k -> new ArrayList<>());
    }

    private void renderTempFunctionArea(PoseStack poseStack, Player player) {
        if (!player.level().dimension().location().equals(functionAreaSelector.getDimension())) return;
        Area selectorArea = functionAreaSelector.getArea();
        if (selectorArea != null && isInRenderDistance(player, selectorArea)) {
            RenderUtil.render(poseStack, Util.getRGBWithAlpha(Color.CYAN, AREA_SELECTION_RENDERING_ALPHA), selectorArea.getBox(), true);
        } else {
            BlockPos start = functionAreaSelector.getStart();
            if (start != null) {
                Area area = new Area(new BoundingBox(start));
                if (isInRenderDistance(player, area)) {
                    RenderUtil.render(poseStack, Util.getRGBWithAlpha(Color.CYAN, AREA_SELECTION_RENDERING_ALPHA), area.getBox(), true);
                }
            }
        }
    }

    public void tick(ClientLevel level) {
        if (scoreTimer > 0) scoreTimer--;
        ActivityArea area = cachedServerAreas.get(activityId);
        if (area == null || !level.dimension().location().toString().equals(area.getDimension())) return;
        if (countdownTimer > 0) countdownTimer--;
    }

    public void renderHud(GuiGraphics guiGraphics) {
        drawTimer(guiGraphics);
        drawCountdown(guiGraphics);
        drawScore(guiGraphics);
    }

    private void drawTimer(GuiGraphics guiGraphics) {
        Config config = Config.getInstance();
        float scale = config.getTimerSize();
        if (!displayTimer || scale <= 0) {
            return;
        }
        MutableComponent timerText = Component.literal(activityTimer.getFormattedTime());
        if (activityTimer.isPaused()) {
            timerText = timerText.withStyle(ChatFormatting.STRIKETHROUGH);
        }
        int centerX = Math.round(guiGraphics.guiWidth() * config.getTimerPos().x / 100);
        int y = Math.round(guiGraphics.guiHeight() * config.getTimerPos().y / 100);
        PoseStack poseStack = guiGraphics.pose();
        poseStack.pushPose();
        if (scale != 1f) {
            poseStack.scale(scale, scale, 1f);
        }
        drawCenteredStringWithBackground(guiGraphics, timerText, Math.round(centerX / scale), Math.round(y / scale), config.getTimerColor(), config.getTimerBackgroundColor());
        drawCenteredStringWithBackground(guiGraphics, Component.literal(lastScore), Math.round(centerX / scale), Math.round(y / scale) + Minecraft.getInstance().font.lineHeight + 3, config.getTimerColor(), config.getTimerBackgroundColor());
        poseStack.popPose();
    }

    private void drawCountdown(GuiGraphics guiGraphics) {
        if (countdownTimer == 0 || countdownText == null) {
            return;
        }
        Config config = Config.getInstance();
        float scale = config.getCountdownSize();
        if (scale <= 0) {
            return;
        }
        int centerX = Math.round(guiGraphics.guiWidth() * config.getCountdownPos().x / 100);
        int y = Math.round(guiGraphics.guiHeight() * config.getCountdownPos().y / 100);
        PoseStack poseStack = guiGraphics.pose();
        poseStack.pushPose();
        if (scale != 1f) {
            poseStack.scale(scale, scale, 1f);
        }
        guiGraphics.drawCenteredString(Minecraft.getInstance().font, countdownText, Math.round(centerX / scale), Math.round(y / scale), adjustAlpha(config.getCountdownColor(), countdownTimer / 20f));
        poseStack.popPose();
    }

    private int adjustAlpha(int color, float factory) {
        float alpha = ((color >> 24) & 0xFF) * Math.max(0f, Math.min(factory, 1f));
        return ((int) alpha << 24) | (color & 0x00FFFFFF);
    }

    private void drawScore(GuiGraphics guiGraphics) {
        if (scoreTimer == 0 || scoreText == null) {
            return;
        }
        Config config = Config.getInstance();
        float scale = config.getScoreSize();
        if (scale <= 0) {
            return;
        }
        int centerX = Math.round(guiGraphics.guiWidth() * config.getScorePos().x / 100);
        int y = Math.round(guiGraphics.guiHeight() * config.getScorePos().y / 100);
        PoseStack poseStack = guiGraphics.pose();
        poseStack.pushPose();
        if (scale != 1f) {
            poseStack.scale(scale, scale, 1f);
        }
        guiGraphics.drawCenteredString(Minecraft.getInstance().font, scoreText, Math.round(centerX / scale), Math.round(y / scale), adjustAlpha(config.getScoreColor(), scoreTimer / 20f));
        poseStack.popPose();
    }

    public void resetManager() {
        instance = new ClientGameManager();
    }

    public static ClientGameManager getInstance() {
        if (instance == null) {
            instance = new ClientGameManager();
        }
        return instance;
    }
}
