package com.modcustom.moddev.registry;

import com.modcustom.moddev.blocks.entities.TranslucentBlockEntity;
import com.modcustom.moddev.renderer.TranslucentBlockEntityRenderer;
import dev.architectury.event.events.client.ClientLifecycleEvent;
import dev.architectury.registry.client.rendering.BlockEntityRendererRegistry;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

import java.util.Arrays;
import java.util.function.Supplier;

import static com.modcustom.moddev.SpeedBuild.MOD_ID;

public class ModBlockEntityTypes {

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(MOD_ID, Registries.BLOCK_ENTITY_TYPE);

    public static final RegistrySupplier<BlockEntityType<TranslucentBlockEntity>> TRANSLUCENT_BLOCK_ENTITY = register("translucent_block", TranslucentBlockEntity::new, ModBlocks.TRANSLUCENT_BLOCK);

    public static <T extends BlockEntity> RegistrySupplier<BlockEntityType<T>> register(String id, BlockEntityType.BlockEntitySupplier<T> factory, RegistrySupplier<Block>... blocks) {
        return BLOCK_ENTITIES.register(id, () -> BlockEntityType.Builder.of(factory, Arrays.stream(blocks).map(Supplier::get).toArray(Block[]::new)).build(null));
    }


    public static <T extends BlockEntity> RegistrySupplier<BlockEntityType<T>> register(String id, BlockEntityType.BlockEntitySupplier<T> factory, Supplier<Block> block) {
        return BLOCK_ENTITIES.register(id, () -> BlockEntityType.Builder.of(factory, block.get()).build(null));
    }

    public static void register() {
        BLOCK_ENTITIES.register();
    }

    public static void registerRenderers() {
        ClientLifecycleEvent.CLIENT_SETUP.register(instance -> {
            BlockEntityRendererRegistry.register(TRANSLUCENT_BLOCK_ENTITY.get(), TranslucentBlockEntityRenderer::new);
        });
    }
}
