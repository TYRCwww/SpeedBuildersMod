package com.modcustom.moddev.commands;

import com.modcustom.moddev.commands.common.*;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.architectury.event.events.common.CommandRegistrationEvent;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.SharedSuggestionProvider;

import java.util.HashMap;
import java.util.Map;

public abstract class Command<T extends SharedSuggestionProvider> {

    protected static final Map<String, String> DESCRIPTIONS = new HashMap<>();
    private static final String COMMAND_DESCRIPTION_PREFIX = "command.moddev.description.";
    private static final String COMMAND_PREFIX = "RBG-";
    protected final String value;
    private final String root;
    private final String descriptionKey;

    protected Command(String root) {
        this.root = root;
        this.value = COMMAND_PREFIX + this.root;
        this.descriptionKey = COMMAND_DESCRIPTION_PREFIX + this.root;
    }

    public String getRoot() {
        return root;
    }

    public abstract LiteralArgumentBuilder<T> build(LiteralArgumentBuilder<T> builder, CommandBuildContext context);

    public static void register() {
        CommandRegistrationEvent.EVENT.register((dispatcher, context, selection) -> {
            registerCommands(dispatcher, context,
                             new MSTJCommand(),
                             new KSCommand(),
                             new QCCommand(),
                             new CJCommand(),
                             new HelpCommand(),
                             new DXCommand(),
                             new ZXCommand(),
                             new FPHCommand(),
                             new CompareCommand(),
                             new GiveCommand(),
                             new ExclusionCommand(),
                             new HideCommand(),
                             new TimerCommand(),
                             new FunctionCommand()
            );
        });
    }

    @SafeVarargs
    public static <T extends SharedSuggestionProvider> void registerCommands(CommandDispatcher<T> dispatcher, CommandBuildContext context, Command<T>... commands) {
        for (Command<T> command : commands) {
            command.register(dispatcher, context);
            DESCRIPTIONS.put(command.value, command.descriptionKey);
        }
    }

    public abstract void register(CommandDispatcher<T> dispatcher, CommandBuildContext context);
}
