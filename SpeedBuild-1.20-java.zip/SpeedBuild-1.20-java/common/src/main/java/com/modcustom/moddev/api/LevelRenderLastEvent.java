package com.modcustom.moddev.api;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.architectury.event.Event;
import dev.architectury.event.EventFactory;

@FunctionalInterface
public interface LevelRenderLastEvent {

    Event<LevelRenderLastEvent> EVENT = EventFactory.createLoop();

    void onRenderLast(PoseStack stack);
}
