package com.modcustom.moddev;

import com.modcustom.moddev.config.GlobeConfig;
import com.modcustom.moddev.events.ModEventRegister;
import com.modcustom.moddev.functions.FunctionManager;
import com.modcustom.moddev.network.ModChannels;
import com.modcustom.moddev.registry.ModBlockEntityTypes;
import com.modcustom.moddev.registry.ModBlocks;
import com.modcustom.moddev.registry.ModItems;
import dev.architectury.platform.Platform;
import net.minecraft.resources.ResourceLocation;

public final class SpeedBuild {

    public static final String MOD_ID = "moddev";
    private static String version;

    public static void init() {
        version = Platform.getMod(MOD_ID).getVersion();
        GlobeConfig.load();
        ModItems.register();
        ModBlocks.register();
        ModBlockEntityTypes.register();
        ModEventRegister.register();
        ModChannels.register();
        FunctionManager.register();
    }

    public static String getVersion() {
        return version;
    }

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MOD_ID, path);
    }
}
