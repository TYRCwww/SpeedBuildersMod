package com.modcustom.moddev.mixin;

import com.modcustom.moddev.config.SneakTweakConfig;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Pose;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {

    @Unique
    private final Pose[] speed_build$lastPoses = new Pose[2];
    @Shadow
    private float eyeHeight;
    @Shadow
    private Entity entity;

    @Inject(method = "tick", at = @At(value = "HEAD"))
    public void speed_build$storePose(CallbackInfo ci) {
        if (this.entity != null) {
            Pose pose = entity.getPose();
            if (pose != speed_build$lastPoses[0]) {
                speed_build$lastPoses[1] = speed_build$lastPoses[0];
                speed_build$lastPoses[0] = pose;
            }
        }
    }

    @Inject(method = "tick", at = @At(value = "FIELD", target = "Lnet/minecraft/client/Camera;eyeHeight:F", ordinal = 0))
    public void speed_build$modifyCameraY(CallbackInfo ci) {
        if (!SneakTweakConfig.getInstance().isSmoothingEnabled() && speed_build$isValidPose()) {
            eyeHeight = entity.getEyeHeight();
        }
    }

    @Unique
    private boolean speed_build$isValidPose() {
        return speed_build$lastPoses[1] == Pose.STANDING && speed_build$lastPoses[0] == Pose.CROUCHING || speed_build$lastPoses[1] == Pose.CROUCHING && speed_build$lastPoses[0] == Pose.STANDING;
    }

    @ModifyConstant(method = "tick", constant = @Constant(floatValue = 0.5f))
    public float speed_build$modifyCameraYSpeed(float modifier) {
        if (!speed_build$isValidPose()) return modifier;
        return SneakTweakConfig.getInstance().isSmoothingEnabled() ? modifier * SneakTweakConfig.getInstance().getSpeedModifier() : 0;
    }

}
