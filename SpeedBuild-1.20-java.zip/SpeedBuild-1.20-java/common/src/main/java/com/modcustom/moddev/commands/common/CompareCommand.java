package com.modcustom.moddev.commands.common;

import com.modcustom.moddev.config.GlobeConfig;
import com.modcustom.moddev.utils.TranslationUtil;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.datafixers.util.Pair;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class CompareCommand extends CommonCommand {

    public CompareCommand() {
        super("compare");
    }

    @Override
    public LiteralArgumentBuilder<CommandSourceStack> build(LiteralArgumentBuilder<CommandSourceStack> builder, CommandBuildContext context) {
        return builder.then(executeEntities()).then(executeBlocks()).then(executeBlockEntities());
    }

    private LiteralArgumentBuilder<CommandSourceStack> executeEntities() {
        return Commands.literal("entities").then(Commands.argument("entity1", EntityArgument.entity()).then(Commands.argument("entity2", EntityArgument.entity()).executes(context -> {
            Entity entity = EntityArgument.getEntity(context, "entity1");
            Entity entity1 = EntityArgument.getEntity(context, "entity2");
            Map<String, Pair<Tag, Tag>> difference = new HashMap<>();
            CompoundTag tag = entity.saveWithoutId(new CompoundTag());
            CompoundTag tag1 = entity1.saveWithoutId(new CompoundTag());
            Set<String> except = GlobeConfig.getInstance().getExceptAttributes("entity", EntityType.getKey(entity.getType()));
            for (String key : tag.getAllKeys()) {
                if (except.contains(key)) continue;
                Tag value1 = tag.get(key);
                Tag value2 = tag1.get(key);
                if (value1 != null && !value1.equals(value2)) {
                    difference.put(key, new Pair<>(value1, value2));
                }
            }
            Set<String> except1 = GlobeConfig.getInstance().getExceptAttributes("entity", EntityType.getKey(entity1.getType()));
            for (String key : tag1.getAllKeys()) {
                if (difference.containsKey(key) || except1.contains(key)) continue;
                Tag value1 = tag.get(key);
                Tag value2 = tag1.get(key);
                if (value1 != null && !value1.equals(value2)) {
                    difference.put(key, new Pair<>(value1, value2));
                }
            }
            sendDifferenceMessage(context, "entity", entity.getDisplayName().getString(), difference, entity1.getDisplayName().getString());
            return 1;
        })));
    }

    private LiteralArgumentBuilder<CommandSourceStack> executeBlocks() {
        return Commands.literal("blocks").then(Commands.argument("pos1", BlockPosArgument.blockPos()).then(Commands.argument("pos2", BlockPosArgument.blockPos()).executes(context -> {
            BlockPos pos = BlockPosArgument.getBlockPos(context, "pos1");
            BlockPos pos1 = BlockPosArgument.getBlockPos(context, "pos2");
            Map<String, Pair<Comparable<?>, Comparable<?>>> difference = new HashMap<>();
            BlockState state = context.getSource().getLevel().getBlockState(pos);
            BlockState state1 = context.getSource().getLevel().getBlockState(pos1);
            Set<String> except = GlobeConfig.getInstance().getExceptAttributes("block", BuiltInRegistries.BLOCK.getKey(state.getBlock()));
            for (Map.Entry<Property<?>, Comparable<?>> entry : state.getValues().entrySet()) {
                Property<?> property = entry.getKey();
                Comparable<?> value = entry.getValue();
                if (except.contains(property.getName())) continue;
                Comparable<?> value1 = state1.getOptionalValue(property).orElse(null);
                if (!value.equals(value1)) {
                    difference.put(property.getName(), new Pair<>(value, value1));
                }
            }
            Set<String> except1 = GlobeConfig.getInstance().getExceptAttributes("block", BuiltInRegistries.BLOCK.getKey(state1.getBlock()));
            for (Map.Entry<Property<?>, Comparable<?>> entry : state1.getValues().entrySet()) {
                Property<?> property = entry.getKey();
                Comparable<?> value = entry.getValue();
                if (difference.containsKey(property.getName()) || except1.contains(property.getName())) {
                    continue;
                }
                Comparable<?> value1 = state.getOptionalValue(property).orElse(null);
                if (!value.equals(value1)) {
                    difference.put(property.getName(), new Pair<>(value, value1));
                }
            }
            sendDifferenceMessage(context, "block", state.getBlock().getName().getString(), difference, state1.getBlock().getName().getString());
            return 1;
        })));
    }

    private LiteralArgumentBuilder<CommandSourceStack> executeBlockEntities() {
        return Commands.literal("storages").then(Commands.argument("pos1", BlockPosArgument.blockPos()).then(Commands.argument("pos2", BlockPosArgument.blockPos()).executes(context -> {
            BlockPos pos = BlockPosArgument.getBlockPos(context, "pos1");
            BlockPos pos1 = BlockPosArgument.getBlockPos(context, "pos2");
            Map<String, Pair<Tag, Tag>> difference = new HashMap<>();
            ServerLevel level = context.getSource().getLevel();
            BlockEntity blockEntity = level.getBlockEntity(pos);
            BlockEntity blockEntity1 = level.getBlockEntity(pos1);
            CompoundTag tag = blockEntity != null ? blockEntity.saveWithoutMetadata() : new CompoundTag();
            CompoundTag tag1 = blockEntity1 != null ? blockEntity1.saveWithoutMetadata() : new CompoundTag();
            Set<String> except = GlobeConfig.getInstance().getExceptAttributes("storage", blockEntity != null ? BuiltInRegistries.BLOCK_ENTITY_TYPE.getKey(blockEntity.getType()) : null);
            for (String key : tag.getAllKeys()) {
                if (except.contains(key)) continue;
                Tag value1 = tag.get(key);
                Tag value2 = tag1.get(key);
                if (value1 != null && !value1.equals(value2)) {
                    difference.put(key, new Pair<>(value1, value2));
                }
            }
            Set<String> except1 = GlobeConfig.getInstance().getExceptAttributes("storage", blockEntity1 != null ? BuiltInRegistries.BLOCK_ENTITY_TYPE.getKey(blockEntity1.getType()) : null);
            for (String key : tag1.getAllKeys()) {
                if (difference.containsKey(key) || except1.contains(key)) continue;
                Tag value1 = tag.get(key);
                Tag value2 = tag1.get(key);
                if (value1 != null && !value1.equals(value2)) {
                    difference.put(key, new Pair<>(value1, value2));
                }
            }
            sendDifferenceMessage(context, "storage", level.getBlockState(pos).getBlock().getName().getString(), difference, level.getBlockState(pos1).getBlock().getName().getString());
            return 1;
        })));
    }

    private <T> void sendDifferenceMessage(CommandContext<CommandSourceStack> context, String type, String name, Map<String, Pair<T, T>> difference, String name1) {
        if (difference.isEmpty()) {
            context.getSource().sendSuccess(() -> TranslationUtil.messageComponent("no_difference"), true);
        } else {
            context.getSource().sendSuccess(() -> TranslationUtil.messageComponent("difference", name, name1, difference.size()), true);
            int i = 0;
            for (Map.Entry<String, Pair<T, T>> entry : difference.entrySet()) {
                i++;
                Pair<T, T> value = entry.getValue();
                int index = i;
                context.getSource().sendSuccess(() -> Component.literal(" " + index + ") ").append(Component.literal(entry.getKey()).withStyle(style -> style.withClickEvent(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, entry.getKey())).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TranslationUtil.messageComponent("clipboard"))))).append(CommonComponents.space()).append(TranslationUtil.messageComponent("directly_add").withStyle(style -> style.withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/RBG-exclusion add " + type + " " + entry.getKey())).withColor(ChatFormatting.AQUA).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TranslationUtil.messageComponent("click_to_add"))))).append(Component.literal(": ")).append(Component.literal(cut(value.getFirst().toString())).withStyle(ChatFormatting.GREEN)).append(Component.literal(" -> ").withStyle(ChatFormatting.AQUA)).append(Component.literal(cut(value.getSecond().toString())).withStyle(ChatFormatting.RED)), true);
            }
            context.getSource().sendSuccess(() -> Component.literal("").append(TranslationUtil.messageComponent("copy_all").withStyle(style -> style.withClickEvent(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, String.join(", ", difference.keySet()))).withColor(ChatFormatting.GREEN).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, TranslationUtil.messageComponent("clipboard"))))), true);
        }
    }

    private String cut(String s) {
        return cut(s, 200, "...");
    }

    private String cut(String s, int length, String suffix) {
        return s.length() > length ? s.substring(0, length) + suffix : s;
    }
}
