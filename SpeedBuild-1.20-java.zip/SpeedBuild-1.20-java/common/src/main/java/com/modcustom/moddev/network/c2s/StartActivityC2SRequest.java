package com.modcustom.moddev.network.c2s;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.game.AreaFinder;
import com.modcustom.moddev.game.activity.ActivityManager;
import com.modcustom.moddev.utils.PlayerUtil;
import com.modcustom.moddev.utils.TranslationUtil;
import dev.architectury.networking.NetworkManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;

import java.util.function.Supplier;

public class StartActivityC2SRequest implements NetworkPacket {

    private final int id;

    public StartActivityC2SRequest(FriendlyByteBuf buf) {
        this(buf.readInt());
    }

    public StartActivityC2SRequest(int id) {
        this.id = id;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(id);
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        if (contextSupplier.get().getPlayer() instanceof ServerPlayer player) {
            AreaFinder areaFinder = PlayerUtil.getAreaFinder(player);
            boolean started = ActivityManager.startActivity(player, id, areaFinder);
            if (!started && id == -1 && areaFinder == AreaFinder.POSITION) {
                player.sendSystemMessage(TranslationUtil.messageComponent("not_in_area"));
            }
        }
    }
}
