package com.modcustom.moddev.api;

import net.minecraft.world.entity.Entity;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

public interface SpawnerProvider {

    static UUID getSpawner(Entity entity) {
        if (entity instanceof SpawnerProvider provider) {
            return provider.getSpawner();
        }
        return null;
    }

    @Nullable
    UUID getSpawner();

    void setSpawner(@Nullable UUID spawner);

    static void setSpawner(Entity entity, UUID spawner) {
        if (entity instanceof SpawnerProvider provider) {
            provider.setSpawner(spawner);
        }
    }
}
