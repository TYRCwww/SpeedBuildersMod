package com.modcustom.moddev.utils;

public enum ActionResult {
    SUCCESS(true),
    FAILURE(false),
    PASS(null);

    private final Boolean success;

    ActionResult(Boolean success) {
        this.success = success;
    }

    public Boolean getResult() {
        return success;
    }

    public boolean hasResult() {
        return success != null;
    }

    public boolean isSuccess() {
        return this == SUCCESS;
    }

    public boolean isFailure() {
        return this == FAILURE;
    }

    public boolean isPass() {
        return this == PASS;
    }

    public static ActionResult of(Boolean result) {
        return result == null ? PASS : result ? SUCCESS : FAILURE;
    }

    public static ActionResult success() {
        return SUCCESS;
    }

    public static ActionResult failure() {
        return FAILURE;
    }

    public static ActionResult pass() {
        return PASS;
    }
}
