package com.modcustom.moddev.utils;

import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;

public class NumberUtil {

    public static boolean isIntOrEmpty(String str) {
        return str.isEmpty() || "-".equals(str) || isInt(str);
    }

    public static boolean isInt(String str) {
        return parseIntOrNull(str) != null;
    }

    @Nullable
    public static Integer parseIntOrNull(String str) {
        try {
            return Integer.parseInt(str);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * @param min inclusive
     * @param max exclusive
     */
    public static boolean isIntBetweenOrEmpty(String str, int min, int max) {
        return str.isEmpty() || min < 0 && "-".equals(str) || isIntBetween(str, min, max);
    }

    /**
     * @param min inclusive
     * @param max exclusive
     */
    public static boolean isIntBetween(String str, int min, int max) {
        Integer i = parseIntOrNull(str);
        return i != null && i >= min && i < max;
    }

    public static OptionalInt getOptionalInt(String str) {
        Integer value = parseIntOrNull(str);
        return value != null ? OptionalInt.of(value) : OptionalInt.empty();
    }

    /**
     * @param min inclusive
     * @param max exclusive
     */
    public static OptionalInt getOptionalIntBetween(String str, int min, int max) {
        Integer value = parseIntOrNull(str);
        return (value != null && value >= min && value < max) ? OptionalInt.of(value) : OptionalInt.empty();
    }

    public static boolean isDoubleOrEmpty(String str) {
        return str.isEmpty() || "-".equals(str) || isDouble(str);
    }

    public static boolean isDouble(String str) {
        return parseDoubleOrNull(str) != null;
    }

    @Nullable
    public static Double parseDoubleOrNull(String str) {
        try {
            return Double.parseDouble(str);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * @param min inclusive
     * @param max inclusive
     */
    public static boolean isDoubleBetweenOrEmpty(String str, double min, double max) {
        return str.isEmpty() || min < 0 && "-".equals(str) || isDoubleBetween(str, min, max);
    }

    /**
     * @param min inclusive
     * @param max inclusive
     */
    public static boolean isDoubleBetween(String str, double min, double max) {
        Double d = parseDoubleOrNull(str);
        return d != null && d >= min && d <= max;
    }

    public static OptionalDouble getOptionalDouble(String str) {
        Double value = parseDoubleOrNull(str);
        return value != null ? OptionalDouble.of(value) : OptionalDouble.empty();
    }

    /**
     * @param min inclusive
     * @param max inclusive
     */
    public static OptionalDouble getOptionalDoubleBetween(String str, double min, double max) {
        Double value = parseDoubleOrNull(str);
        return (value != null && value >= min && value <= max) ? OptionalDouble.of(value) : OptionalDouble.empty();
    }

    public static boolean isFloatOrEmpty(String str) {
        return str.isEmpty() || "-".equals(str) || isFloat(str);
    }

    public static boolean isFloat(String str) {
        return parseFloatOrNull(str) != null;
    }

    @Nullable
    public static Float parseFloatOrNull(String str) {
        try {
            return Float.parseFloat(str);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * @param min inclusive
     * @param max inclusive
     */
    public static boolean isFloatBetweenOrEmpty(String str, float min, float max) {
        return str.isEmpty() || min < 0 && "-".equals(str) || isFloatBetween(str, min, max);
    }

    /**
     * @param min inclusive
     * @param max inclusive
     */
    public static boolean isFloatBetween(String str, float min, float max) {
        Float f = parseFloatOrNull(str);
        return f != null && f >= min && f <= max;
    }

    public static Optional<Float> getOptionalFloat(String str) {
        Float value = parseFloatOrNull(str);
        return value != null ? Optional.of(value) : Optional.empty();
    }

    /**
     * @param min inclusive
     * @param max inclusive
     */
    public static Optional<Float> getOptionalFloatBetween(String str, float min, float max) {
        Float value = parseFloatOrNull(str);
        return (value != null && value >= min && value <= max) ? Optional.of(value) : Optional.empty();
    }
}
