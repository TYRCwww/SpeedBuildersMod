package com.modcustom.moddev.game.activity;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.HistoryLogManager;
import com.modcustom.moddev.game.SoundSetting;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.area.Area;
import com.modcustom.moddev.game.data.ClientCachedData;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.game.data.ItemGivingData;
import com.modcustom.moddev.network.Network;
import com.mojang.datafixers.util.Pair;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.phys.AABB;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class Activity {

    private final ServerLevel level;
    private final ActivityArea area;
    @Nullable
    private final String initiator;
    private final Set<ServerPlayer> players;

    private long startTime = 0;
    private int countdown;
    private boolean started = false;
    private boolean finished = false;
    @Nullable
    private Long currentRuntime = null;
    @Nullable
    private Long lastPlacingBlockTime = null;
    @Nullable
    private Long lastPlacingEntityTime = null;

    private boolean syncDifference = false;
    private Pair<Set<BlockPos>, Set<BlockPos>> lastSyncedBlocks = Pair.of(Set.of(), Set.of());

    public Activity(ServerLevel level, ActivityArea area, @Nullable String initiator, Set<ServerPlayer> players) {
        this.level = level;
        this.area = area;
        this.initiator = initiator;
        this.players = new HashSet<>(players);
        this.countdown = area.getConfig().getCountdown() * 20;

        if (area.getConfig().isSimpleMode()) {
            start();
        } else {
            area.startCopyTargetTask(level);
            Network.previewActivity(this);
        }
    }

    public void start() {
        if (!started && !finished) {
            startTime = System.currentTimeMillis();
            started = true;
            if (!area.getConfig().isSimpleMode()) clearBlocks();
            ItemGivingData data = area.getConfig().getItemGivingData();
            if (data.getCondition() == ItemGivingData.TriggerCondition.START) {
                data.run(this);
            }
            Network.startActivityTimer(this);
            playSound(area.getConfig().getStartSound());
        }
    }

    public void clearBlocks() {
        area.startResetConstructionAreaTask(level);
    }

    public void playSound(SoundSetting soundSetting) {
        SoundEvent sound = soundSetting.getSound();
        if (sound != null) {
            players.forEach(player -> player.playNotifySound(sound, SoundSource.VOICE, soundSetting.getVolume(), soundSetting.getPitch()));
        }
    }

    public void tick(long startTickTime) {
        currentRuntime = startTickTime - startTime;
        players.removeIf(player -> {
            if (!level.getServer().getPlayerList().getPlayers().contains(player)) {
                return true;
            }
            if (player.level() != level || !AABB.of(area.getBoundingBox().inflatedBy(64)).intersects(player.getBoundingBox())) {
                Network.finishActivity(player);
                return true;
            }
            return false;
        });
        if (players.isEmpty() || !level.isLoaded(area.getBoundingBox().getCenter())) {
            finished = true;
            if (!started) clearBlocks();
            return;
        }
        if (area.getConfig().isSimpleMode() && checkEmpty()) {
            finish(true);
            ItemGivingData data = area.getConfig().getItemGivingData();
            if (data.getCondition() == ItemGivingData.TriggerCondition.CLEAR) {
                data.run(this);
            }
            return;
        }
        if (!started && !area.getConfig().isSimpleMode()) {
            String text = area.getConfig().formattedCountdownText((int) Math.ceil(countdown / 20.0));
            Network.sendCountdownMessageForAll(players, text, 20);
            if (countdown > 0) {
                if (countdown % 20 == 0) playSound(area.getConfig().getCountdownSound());
                countdown--;
            } else {
                start();
            }
            return;
        }
        if (started && !finished) {
            level.getServer().execute(() -> {
                compareAndFinish();
                trySyncDifference();
            });
        }
    }

    private boolean checkEmpty() {
        return area.isConstructionAreaEmpty(level) && area.getConstructionAreaEntities(level).isEmpty();
    }

    public void finish(boolean noScore) {
        finished = true;
        long runtime = getRuntime();
        Network.finishActivity(this, noScore ? -1 : area.getId(), runtime);
        if (!noScore) {
            playSound(area.getConfig().getFinishSound());
            ActivityArea area = GameData.getGameData(level).getActivityArea(this.area.getId());
            if (area != null) {
                ActivityRecord record = ActivityRecord.createFinishedRecord(area.getId(), initiator, players.stream().collect(Collectors.toMap(player -> player.getDisplayName().getString(), ClientCachedData::get)), startTime, runtime);
                area.addHistory(record);
                HistoryLogManager.appendHistory(level.getServer(), record);
                Network.updateAreaHistory(level.getServer(), area);
            }
        }
    }

    public void interrupt() {
        finished = true;
        long runtime = getRuntime();
        Network.finishActivity(this, area.getId(), runtime);
        playSound(area.getConfig().getFinishSound());
        ActivityArea area = GameData.getGameData(level).getActivityArea(this.area.getId());
        if (area != null) {
            int unrestoredBlockProgress = area.compareBlocks(level, false);
            int unrestoredEntityProgress = area.compareEntities(level, false);
            boolean restored = unrestoredBlockProgress == 0 && unrestoredEntityProgress == 0;
            ActivityRecord record = ActivityRecord.createInterruptedRecord(area.getId(), initiator, players.stream().collect(Collectors.toMap(player -> player.getDisplayName().getString(), ClientCachedData::get)), startTime, runtime, restored, lastPlacingBlockTime, lastPlacingEntityTime, unrestoredBlockProgress, unrestoredEntityProgress);
            area.addHistory(record);
            HistoryLogManager.appendHistory(level.getServer(), record);
            Network.updateAreaHistory(level.getServer(), area);
        }
    }

    public long getRuntime() {
        if (!started) return 0;
        Long currentRuntime = getCurrentRuntimeAndClear();
        return currentRuntime != null ? currentRuntime : (System.currentTimeMillis() - startTime);
    }

    @Nullable
    public Long getCurrentRuntimeAndClear() {
        Long time = currentRuntime;
        if (currentRuntime != null) {
            currentRuntime = null;
        }
        return time;
    }

    private void compareAndFinish() {
        if (area.compare(level, true) != 0) return;
        finish();
    }

    public void finish() {
        finish(false);
    }

    public boolean isInActivityArea(BlockPos pos) {
        return area.contains(pos);
    }

    public ServerLevel getLevel() {
        return level;
    }

    @Nullable
    public String getInitiator() {
        return initiator;
    }

    public int getCountdown() {
        return countdown;
    }

    public boolean isStarted() {
        return started;
    }

    public boolean isFinished() {
        return finished;
    }

    public boolean isSyncDifference() {
        return syncDifference;
    }

    public void setSyncDifference(boolean enabled) {
        this.syncDifference = enabled;
        lastSyncedBlocks = null;
    }

    public void trySyncDifference() {
        if (!started || finished || !syncDifference) return;
        Pair<Set<BlockPos>, Set<BlockPos>> blocks = area.getDifferentAndExtraBlocks(level);
        if (!blocks.equals(lastSyncedBlocks)) {
            Network.updateDifferentBlocks(players, area.getId(), blocks);
            lastSyncedBlocks = blocks;
        }
    }

    @Nullable
    public Long getLastPlacingBlockTime() {
        return lastPlacingBlockTime;
    }

    public void markBlockPlaced() {
        if (!started) return;
        this.lastPlacingBlockTime = System.currentTimeMillis();
    }

    @Nullable
    public Long getLastPlacingEntityTime() {
        return lastPlacingEntityTime;
    }

    public void markEntityPlaced() {
        if (!started) return;
        this.lastPlacingEntityTime = System.currentTimeMillis();
    }

    public static boolean checkSpecialBlockEntity(BlockEntity blockEntity, BlockEntity blockEntity1) {
        if (blockEntity instanceof SpawnerBlockEntity spawnerBlockEntity && blockEntity1 instanceof SpawnerBlockEntity spawnerBlockEntity1) {
            Level blockEntityLevel = blockEntity.getLevel();
            Level blockEntityLevel1 = blockEntity1.getLevel();
            if (blockEntityLevel != null && blockEntityLevel1 != null) {
                Entity entity = spawnerBlockEntity.getSpawner().getOrCreateDisplayEntity(blockEntityLevel, blockEntityLevel.random, blockEntity.getBlockPos());
                Entity entity1 = spawnerBlockEntity1.getSpawner().getOrCreateDisplayEntity(blockEntityLevel1, blockEntityLevel1.random, blockEntity1.getBlockPos());
                return entity == null && entity1 == null || entity != null && entity1 != null && entity.getType().equals(entity1.getType());
            }
        }
        return false;
    }

    public static void tryStartActivity(Level level, BlockPos pos, Entity placer) {
        tryStartActivity(level, pos, placer, null);
    }

    public static void tryStartActivity(Level level, BlockPos pos, Entity placer, @Nullable Entity entity) {
        if (level instanceof ServerLevel serverLevel) {
            ServerPlayer player = placer instanceof ServerPlayer serverPlayer ? serverPlayer : null;
            GameData gameData = GameData.getGameData(serverLevel);
            Optional.ofNullable(gameData.getActivityArea(serverLevel, pos, area -> {
                Area construction = area.getConstruction();
                return area.getConfig().isSimpleMode() &&
                       construction.contains(pos) &&
                       area.getConstructionAreaBlocks()
                           .stream()
                           .filter(blockPos -> !blockPos.equals(pos))
                           .allMatch(blockPos -> serverLevel.getBlockState(blockPos).isAir()) &&
                       area.getConstructionAreaEntities(serverLevel, entity).isEmpty();
            })).filter(area -> !ActivityManager.hasActivity(area.getId())).ifPresent(area -> {
                if (player != null) {
                    if (ActivityManager.hasActivity(player)) {
                        Network.finishActivity(player);
                    }
                }
                Set<ServerPlayer> entities = new HashSet<>(serverLevel.getEntitiesOfClass(ServerPlayer.class, area.getBox()));
                entities.add(player);
                ActivityManager.addActivity(serverLevel, area, placer != null ? placer.getDisplayName().getString() : null, entities);
            });

            if (player != null && !ActivityManager.hasActivity(player)) {
                ActivityManager.getActivities(serverLevel, pos)
                               .stream()
                               .filter(activity -> activity.getArea().getConstruction().contains(pos))
                               .findFirst()
                               .ifPresent(activity -> {
                                   activity.getPlayers().add(player);
                                   Network.startActivityTimer(activity, activity.getStartTime());
                               });
            }
        } else if (level.isClientSide && !ClientGameManager.getInstance().hasActivity()) {
            ClientGameManager.getInstance()
                             .getActivityAreas(level, pos)
                             .stream()
                             .filter(area -> area.getConfig().isSimpleMode() &&
                                             area.getConstruction().contains(pos) &&
                                             area.getConstructionAreaBlocks()
                                                 .stream()
                                                 .filter(blockPos -> !blockPos.equals(pos))
                                                 .allMatch(blockPos -> level.getBlockState(blockPos).isAir()) &&
                                             area.getConstructionAreaEntities(level, entity).isEmpty())
                             .findFirst()
                             .ifPresent(area -> ClientGameManager.getInstance().startActivity(area.getId()));
        }
    }

    public ActivityArea getArea() {
        return area;
    }

    public Set<ServerPlayer> getPlayers() {
        return players;
    }

    public long getStartTime() {
        return startTime;
    }
}
