package com.modcustom.moddev.mixin;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.area.ProtectedArea;
import com.modcustom.moddev.network.s2c.ProtectedBlocksUpdateS2CPacket;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.HashSet;
import java.util.Set;

@Mixin(ClientLevel.class)
public class ClientLevelMixin extends LevelMixin {

    @Unique
    private final Set<BlockPos> speedbuild$serverUpdatingBlocks = new HashSet<>();

    @Inject(method = "setServerVerifiedBlockState", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;setBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;II)Z"))
    public void speed_build$setServerVerifiedBlockState(BlockPos pos, BlockState state, int flags, CallbackInfo ci) {
        ClientLevel level = (ClientLevel) (Object) this;
        if (flags == ProtectedBlocksUpdateS2CPacket.SERVER_UPDATE_FLAGS && ClientGameManager.getInstance().consumeServerUpdate(level, pos)) {
            speedbuild$serverUpdatingBlocks.add(pos);
        }
    }

    @Override
    public void speed_build$setBlock(BlockPos blockPos, BlockState blockState, int i, int j, CallbackInfoReturnable<Boolean> cir) {
        if (speedbuild$serverUpdatingBlocks.remove(blockPos)) return;
        if (ProtectedArea.isProtected((ClientLevel) (Object) this, blockPos)) {
            cir.setReturnValue(false);
        }
    }
}
