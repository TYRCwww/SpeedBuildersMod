package com.modcustom.moddev.mixin;

import com.modcustom.moddev.api.SpawnerProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.function.Consumer;

@Mixin(EntityType.class)
public class EntityTypeMixin<T extends Entity> {

    @Redirect(method = "spawn(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/MobSpawnType;ZZ)Lnet/minecraft/world/entity/Entity;", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/EntityType;spawn(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/nbt/CompoundTag;Ljava/util/function/Consumer;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/MobSpawnType;ZZ)Lnet/minecraft/world/entity/Entity;"))
    private T onSpawn(EntityType<T> instance, ServerLevel level, CompoundTag compound, Consumer<T> consumer, BlockPos pos, MobSpawnType spawnType, boolean shouldOffsetY, boolean shouldOffsetYMore, ServerLevel serverLevel, @Nullable ItemStack stack, @Nullable Player player) {
        if (player != null) {
            Consumer<T> spawnerConsumer = (entity) -> {
                if (entity instanceof SpawnerProvider provider) {
                    provider.setSpawner(player.getUUID());
                }
            };
            consumer = consumer == null ? spawnerConsumer : consumer.andThen(spawnerConsumer);
        }
        return instance.spawn(level, compound, consumer, pos, spawnType, shouldOffsetY, shouldOffsetYMore);
    }
}
