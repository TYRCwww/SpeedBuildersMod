package com.modcustom.moddev.api;

import dev.architectury.event.Event;
import dev.architectury.event.EventFactory;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.state.BlockState;

@FunctionalInterface
public interface LivingFallEvent {

    Event<LivingFallEvent> EVENT = EventFactory.createLoop();

    void onLivingFall(LivingEntity entity, BlockState state, BlockPos pos);
}
