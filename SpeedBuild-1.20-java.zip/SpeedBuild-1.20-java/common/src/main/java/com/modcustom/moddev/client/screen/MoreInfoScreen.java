package com.modcustom.moddev.client.screen;

import com.modcustom.moddev.utils.TranslationUtil;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.MutableComponent;
import org.jetbrains.annotations.Nullable;

public class MoreInfoScreen extends SyncScreen {

    private static final MutableComponent TITLE = TranslationUtil.screenComponent("more_info.title");

    public MoreInfoScreen() {
        this(null);
    }

    public MoreInfoScreen(@Nullable Screen parent) {
        super(TITLE, parent);
    }

    @Override
    protected void init() {
        super.init();

        Button backButton = Button.builder(TranslationUtil.screenComponent("back"), button -> {
            if (minecraft != null) {
                minecraft.setScreen(parent);
            }
        }).bounds(10, height - 30, 100, 20).build();
        addRenderableWidget(backButton);

        Button serverButton = Button.builder(TranslationUtil.screenComponent("more_info.server_button"), button -> {
            if (minecraft != null) {
                minecraft.setScreen(new ServerRecommendScreen(this));
            }
        }).bounds(10, 32, 100, 20).build();
        serverButton.active = false;
        addRenderableWidget(serverButton);
    }

    @Override
    public void update() {

    }
}
