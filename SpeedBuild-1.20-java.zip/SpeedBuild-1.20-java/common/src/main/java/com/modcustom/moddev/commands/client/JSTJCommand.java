package com.modcustom.moddev.commands.client;

import com.modcustom.moddev.config.Config;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.world.phys.Vec2;

import java.awt.*;

import static dev.architectury.event.events.client.ClientCommandRegistrationEvent.ClientCommandSourceStack;

public class JSTJCommand extends ClientCommand {

    public JSTJCommand() {
        super("jstj");
    }

    @Override
    public LiteralArgumentBuilder<ClientCommandSourceStack> build(LiteralArgumentBuilder<ClientCommandSourceStack> builder, CommandBuildContext context) {
        return builder.then(executeSetPos((x, y) -> {
            Config.getInstance().setTimerPos(new Vec2(x, y));
            return 1;
        })).then(executeSetSize(size -> {
            Config.getInstance().setTimerSize(size);
            return 1;
        })).then(executeSetColorRGBA((r, g, b, a) -> {
            Config.getInstance().setTimerColor(new Color(r, g, b, a).getRGB());
            return 1;
        })).then(executeSetColorFormatting(formatting -> {
            if (formatting.getColor() != null) {
                Config.getInstance().setTimerColor(formatting.getColor());
            }
            return 1;
        })).then(executeSetColor(color -> {
            Config.getInstance().setTimerColor(color.getRGB());
            return 1;
        }));
    }
}
