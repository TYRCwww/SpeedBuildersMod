package com.modcustom.moddev.api;

import com.modcustom.moddev.game.area.Area;
import org.jetbrains.annotations.Nullable;

public interface AreaVisible {

    default boolean isVisible(@Nullable Area.Type type) {
        return true;
    }
}
