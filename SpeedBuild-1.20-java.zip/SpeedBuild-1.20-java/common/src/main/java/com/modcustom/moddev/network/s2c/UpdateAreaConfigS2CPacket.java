package com.modcustom.moddev.network.s2c;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.area.AreaConfig;
import dev.architectury.networking.NetworkManager;
import dev.architectury.utils.Env;
import net.minecraft.network.FriendlyByteBuf;

import java.util.function.Supplier;

public class UpdateAreaConfigS2CPacket implements NetworkPacket {

    private final int id;
    private final AreaConfig config;

    public UpdateAreaConfigS2CPacket(FriendlyByteBuf buf) {
        this(buf.readInt(), AreaConfig.fromNbt(buf.readAnySizeNbt()));
    }

    public UpdateAreaConfigS2CPacket(int id, AreaConfig config) {
        this.id = id;
        this.config = config;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(id);
        buf.writeNbt(config.toNbt());
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        NetworkManager.PacketContext context = contextSupplier.get();
        if (context.getEnvironment() == Env.CLIENT) {
            ClientGameManager.getInstance().updateAreaConfig(id, config);
        }
    }
}
