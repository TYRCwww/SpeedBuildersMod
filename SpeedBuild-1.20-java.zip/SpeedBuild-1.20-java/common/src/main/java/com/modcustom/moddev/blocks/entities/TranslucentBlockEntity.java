package com.modcustom.moddev.blocks.entities;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.registry.ModBlockEntityTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;

public class TranslucentBlockEntity extends BlockEntity {

    private BlockState renderingState = Blocks.AIR.defaultBlockState();

    public TranslucentBlockEntity(BlockPos pos, BlockState blockState) {
        super(ModBlockEntityTypes.TRANSLUCENT_BLOCK_ENTITY.get(), pos, blockState);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        if (level != null && tag.contains("renderingState")) {
            renderingState = NbtUtils.readBlockState(level.holderLookup(Registries.BLOCK), tag.getCompound("renderingState"));
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("renderingState", NbtUtils.writeBlockState(renderingState));
    }

    public static void tick(Level level, BlockPos blockPos, BlockState state, TranslucentBlockEntity entity) {
        if (!level.isClientSide) return;
        ClientGameManager manager = ClientGameManager.getInstance();
        List<ActivityArea> areas = manager.getActivityAreas(level, blockPos);
        if (areas.stream().noneMatch(area -> manager.isShowingDifference(area.getId()))) {
            entity.revert();
        }
    }

    public boolean revert() {
        if (level == null || !level.isClientSide) {
            return false;
        }
        return level.setBlock(worldPosition, getRenderingState(), Block.UPDATE_CLIENTS);
    }

    public BlockState getRenderingState() {
        return renderingState;
    }

    public void setRenderingState(BlockState state) {
        renderingState = state;
        setChanged();
    }
}
