package com.modcustom.moddev.client.screen;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.client.components.CallbackCheckbox;
import com.modcustom.moddev.client.components.HorizontalComponentList;
import com.modcustom.moddev.client.components.SoundEventEditBox;
import com.modcustom.moddev.client.components.SoundValueEditBox;
import com.modcustom.moddev.config.Config;
import com.modcustom.moddev.config.SneakTweakConfig;
import com.modcustom.moddev.game.AreaFinder;
import com.modcustom.moddev.game.SoundSetting;
import com.modcustom.moddev.game.data.ClientCachedData;
import com.modcustom.moddev.network.Network;
import com.modcustom.moddev.network.c2s.RequestSyncC2SPacket;
import com.modcustom.moddev.utils.NumberUtil;
import com.modcustom.moddev.utils.Timer;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import org.jetbrains.annotations.Nullable;

import static com.modcustom.moddev.utils.NumberUtil.*;
import static com.modcustom.moddev.utils.TranslationUtil.screenComponent;

public class PlayerConfigScreen extends SyncScreen {

    private static final MutableComponent TITLE = screenComponent("player_config.title");
    private HorizontalComponentList componentList;
    private EditBox extraJumpBox;
    private EditBox extraJumpPowerBox;
    private SoundEventEditBox jumpSoundEventBox;
    private SoundValueEditBox.Volume jumpSoundVolumeBox;
    private SoundValueEditBox.Pitch jumpSoundPitchBox;
    private CallbackCheckbox defaultAnimationCheckBox;
    private CallbackCheckbox oldAnimationCheckBox;
    private CycleButton<AreaFinder> areaFinderButton;
    private CallbackCheckbox extraJumpEnabledButton;
    private CallbackCheckbox jumpMovementLimitButton;
    private CallbackCheckbox protectedAreaDisplayButton;
    private CallbackCheckbox functionAreaDisplayButton;
    private CycleButton<Boolean> protectedAreaOverlappingButton;
    private EditBox timerErrorCorrectionBox;
    private EditBox timerFormatBox;
    private CallbackCheckbox jumpingParticlesButton;
    @Nullable
    private String soundEventSuggestion;

    public PlayerConfigScreen() {
        super(TITLE);
    }

    @Override
    public void onClose() {
        if (Config.getInstance().isPlayerConfigAutoSave()) {
            save();
        }
        super.onClose();
    }

    @Override
    public void update() {
        ClientCachedData data = getData();
        extraJumpBox.setValue(String.valueOf(data.getExtraJump()));
        extraJumpPowerBox.setValue(String.valueOf(data.getExtraJumpPower()));
        areaFinderButton.setValue(data.getAreaFinder());
        extraJumpEnabledButton.setSelected(data.isExtraJumpEnabled());
        jumpMovementLimitButton.setSelected(data.isJumpMovementLimit());
        protectedAreaOverlappingButton.setValue(data.isOverlappingProtectedAreas());
        timerErrorCorrectionBox.setValue(String.valueOf(data.getTimerErrorCorrection()));
        timerFormatBox.setValue(String.valueOf(data.getTimerErrorCorrection()));
        jumpingParticlesButton.setSelected(data.hasJumpingParticles());

        SoundSetting jumpSound = data.getJumpSound();
        SoundEvent sound = jumpSound.getSound();
        jumpSoundEventBox.setValue(sound != null ? sound.getLocation().toString() : "");
        jumpSoundVolumeBox.setValue(String.valueOf(jumpSound.getVolume()));
        jumpSoundPitchBox.setValue(String.valueOf(jumpSound.getPitch()));

        SneakTweakConfig sneakTweakConfig = SneakTweakConfig.getInstance();
        defaultAnimationCheckBox.setSelected(sneakTweakConfig.isDefault());
        oldAnimationCheckBox.setSelected(sneakTweakConfig.isOld());

        Config config = Config.getInstance();
        protectedAreaDisplayButton.setSelected(config.isProtectedAreaVisible());
        functionAreaDisplayButton.setSelected(config.isFunctionAreaVisible());
    }

    private void save() {
        saveLocalConfig();
        if (minecraft != null) {
            Network.syncPlayerData(minecraft.player);
        }
    }

    private void saveLocalConfig() {
        Config config = Config.getInstance();
        config.setProtectedAreaVisible(protectedAreaDisplayButton.selected());
        config.setFunctionAreaVisible(functionAreaDisplayButton.selected());
        config.setTimerFormat(timerFormatBox.getValue());

        ClientCachedData data = getData();
        data.setAreaFinder(areaFinderButton.getValue());
        data.setExtraJumpEnabled(extraJumpEnabledButton.selected());
        data.setJumpMovementLimit(jumpMovementLimitButton.selected());
        data.setOverlappingProtectedAreas(protectedAreaOverlappingButton.getValue());
        data.setJumpingParticles(jumpingParticlesButton.selected());
        getOptionalInt(extraJumpBox.getValue()).ifPresent(data::setExtraJump);
        getOptionalDouble(extraJumpPowerBox.getValue()).ifPresent(data::setExtraJumpPower);
        getOptionalInt(timerErrorCorrectionBox.getValue()).ifPresent(data::setTimerErrorCorrection);

        SoundSetting jumpSound = data.getJumpSound();
        SoundEvent sound = SoundSetting.tryParse(jumpSoundEventBox.getValue());
        if (sound != null) {
            jumpSound.setSound(sound);
        }
        getOptionalFloat(jumpSoundVolumeBox.getValue()).ifPresent(jumpSound::setVolume);
        getOptionalFloat(jumpSoundPitchBox.getValue()).ifPresent(jumpSound::setPitch);

        SneakTweakConfig sneakTweakConfig = SneakTweakConfig.getInstance();
        if (defaultAnimationCheckBox.selected()) {
            sneakTweakConfig.reset();
        } else if (oldAnimationCheckBox.selected()) {
            sneakTweakConfig.convertToOld();
        }
    }

    protected ClientCachedData getData() {
        return ClientGameManager.getInstance().getCachedData();
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (jumpSoundEventBox.keyPressed(keyCode, scanCode, modifiers, () -> soundEventSuggestion)) {
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void init() {
        super.init();

        componentList = new HorizontalComponentList(minecraft, width, height - 64, 32, height - 32, 32);
        addRenderableWidget(componentList);

        ClientCachedData data = getData();

        extraJumpEnabledButton = new CallbackCheckbox(font, screenComponent("extra_jump_enable"), data.isExtraJumpEnabled());
        jumpMovementLimitButton = new CallbackCheckbox(font, screenComponent("jump_movement_limit"), data.isJumpMovementLimit());
        jumpingParticlesButton = new CallbackCheckbox(font, screenComponent("jumping_particles"), data.hasJumpingParticles());
        protectedAreaDisplayButton = new CallbackCheckbox(font, screenComponent("protected_area_display"), Config.getInstance().isProtectedAreaVisible());
        functionAreaDisplayButton = new CallbackCheckbox(font, screenComponent("function_area_display"), Config.getInstance().isFunctionAreaVisible());
        addLine(extraJumpEnabledButton, jumpMovementLimitButton, jumpingParticlesButton);
        addLine(protectedAreaDisplayButton, functionAreaDisplayButton);

        extraJumpBox = new EditBox(font, 0, 0, 50, 20, screenComponent("extra_jump"));
        extraJumpBox.setValue(String.valueOf(data.getExtraJump()));
        extraJumpBox.setFilter(s -> isIntBetweenOrEmpty(s, 0, 1000));
        addLine(
                createStringWidget(screenComponent("extra_jump")),
                extraJumpBox,
                createResetButton(button -> extraJumpBox.setValue("1")),
                createButton(Component.literal("+"), button -> getOptionalInt(extraJumpBox.getValue()).ifPresent(value -> extraJumpBox.setValue(String.valueOf(value + 1)))),
                createButton(Component.literal("-"), button -> getOptionalInt(extraJumpBox.getValue()).ifPresent(value -> extraJumpBox.setValue(String.valueOf(value - 1))))
        );

        extraJumpPowerBox = new EditBox(font, 0, 0, 50, 20, screenComponent("extra_jump_power"));
        extraJumpPowerBox.setValue(String.valueOf(data.getExtraJumpPower()));
        extraJumpPowerBox.setFilter(s -> isDoubleBetweenOrEmpty(s, 0.0, 2.0));
        addLine(
                createStringWidget(screenComponent("extra_jump_power")),
                extraJumpPowerBox,
                createResetButton(button -> extraJumpPowerBox.setValue("1.0")),
                createButton(Component.literal("+"), button -> extraJumpPowerBox.setValue(toFormattedString(Double.parseDouble(extraJumpPowerBox.getValue()) + (hasShiftDown() ? 1.0 : 0.1)))),
                createButton(Component.literal("-"), button -> extraJumpPowerBox.setValue(toFormattedString(Double.parseDouble(extraJumpPowerBox.getValue()) - (hasShiftDown() ? 1.0 : 0.1))))
        );

        jumpSoundEventBox = new SoundEventEditBox(font, data.getJumpSound(), screenComponent("jump_sound"), SoundEvents.BLAZE_SHOOT.getLocation().toString(), suggestion -> soundEventSuggestion = suggestion);
        jumpSoundEventBox.setAutoSetting(false);
        addLine(jumpSoundEventBox.createRow());

        jumpSoundVolumeBox = new SoundValueEditBox.Volume(font, data.getJumpSound(), screenComponent("jump_sound_volume"));
        jumpSoundVolumeBox.setAutoSetting(false);
        addLine(jumpSoundVolumeBox.createRow());

        jumpSoundPitchBox = new SoundValueEditBox.Pitch(font, data.getJumpSound(), screenComponent("jump_sound_pitch"));
        jumpSoundPitchBox.setAutoSetting(false);
        addLine(jumpSoundPitchBox.createRow());

        defaultAnimationCheckBox = new CallbackCheckbox(font, Component.literal("1.20"), SneakTweakConfig.getInstance().isDefault(), selected -> {
            if (selected) {
                oldAnimationCheckBox.setSelected(false);
                return true;
            }
            return false;
        });

        oldAnimationCheckBox = new CallbackCheckbox(font, Component.literal("1.12"), SneakTweakConfig.getInstance().isOld(), selected -> {
            if (selected) {
                defaultAnimationCheckBox.setSelected(false);
                return true;
            }
            return false;
        });
        addLine(
                createStringWidget(screenComponent("animation_version")),
                defaultAnimationCheckBox,
                oldAnimationCheckBox
        );

        areaFinderButton = CycleButton.builder(AreaFinder::getComponent).withValues(AreaFinder.values()).withInitialValue(data.getAreaFinder()).displayOnlyValue().create(0, 0, 100, 20, screenComponent("area_finder"));
        addLine(
                createStringWidget(screenComponent("area_finder")),
                areaFinderButton
        );

        protectedAreaOverlappingButton = CycleButton.booleanBuilder(screenComponent("protected_area_overlapping.on"), screenComponent("protected_area_overlapping.off")).withInitialValue(data.isOverlappingProtectedAreas()).displayOnlyValue().create(0, 0, 100, 20, screenComponent("protected_area_overlapping"));
        addLine(
                createStringWidget(screenComponent("protected_area_overlapping")),
                protectedAreaOverlappingButton
        );

        timerErrorCorrectionBox = new EditBox(font, 0, 0, 50, 20, screenComponent("timer_error_correction"));
        timerErrorCorrectionBox.setValue(String.valueOf(data.getTimerErrorCorrection()));
        timerErrorCorrectionBox.setFilter(NumberUtil::isIntOrEmpty);
        addLine(
                createStringWidget(screenComponent("timer_error_correction")),
                timerErrorCorrectionBox,
                createResetButton(button -> timerErrorCorrectionBox.setValue("0")),
                createButton(Component.literal("+"), button -> {
                    getOptionalInt(timerErrorCorrectionBox.getValue()).ifPresent(value -> timerErrorCorrectionBox.setValue(String.valueOf(value + 10)));
                }),
                createButton(Component.literal("-"), button -> {
                    getOptionalInt(timerErrorCorrectionBox.getValue()).ifPresent(value -> timerErrorCorrectionBox.setValue(String.valueOf(value - 10)));
                })
        );

        timerFormatBox = new EditBox(font, 0, 0, 100, 20, screenComponent("timer_format"));
        timerFormatBox.setValue(Config.getInstance().getTimerFormat());
        addLine(
                createStringWidget(screenComponent("timer_format")),
                timerFormatBox,
                createResetButton(button -> timerFormatBox.setValue(Timer.DEFAULT_FORMAT))
        );

        addRenderableWidget(Button.builder(screenComponent("save_button"), button -> save()).bounds(width - 60, height - 30, 50, 20).build());

        MutableComponent component = screenComponent("auto_save");
        int componentWidth = 24 + font.width(component);
        CallbackCheckbox autoSaveBox = new CallbackCheckbox(font, width - componentWidth - 10, 10, component, Config.getInstance().isPlayerConfigAutoSave(), true, selected -> {
            Config.getInstance().setPlayerConfigAutoSave(selected);
            return true;
        }).leftComponent();
        addRenderableWidget(autoSaveBox);

        Button moreButton = Button.builder(screenComponent("more_button"), button -> {
            if (minecraft != null) {
                minecraft.setScreen(new MoreInfoScreen(this));
            }
        }).bounds(width - 120, height - 30, 50, 20).build();
        addRenderableWidget(moreButton);

        Network.requestSync(RequestSyncC2SPacket.Type.PLAYER_DATA);
    }

    @Override
    public void tick() {
        super.tick();
        componentList.tick();
    }

    private void addLine(AbstractWidget... widgets) {
        componentList.addEntry(new HorizontalComponentList.Entry(10, 10, widgets));
    }

    public static String toFormattedString(double value) {
        return String.format("%.1f", value);
    }
}
