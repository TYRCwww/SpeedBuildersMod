package com.modcustom.moddev.game.area;

import com.modcustom.moddev.api.SerializableData;
import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.functions.AreaFunction;
import com.modcustom.moddev.functions.FunctionManager;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.network.Network;
import com.modcustom.moddev.utils.ActionResult;
import com.modcustom.moddev.utils.TranslationUtil;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

public class FunctionArea extends Area implements SerializableData<FunctionArea> {

    private final int id;
    private final List<AreaFunction> functions;
    private boolean showResult = true;
    private boolean locked = false;
    private boolean swingHand = true;

    public FunctionArea(int id, BlockPos start, BlockPos end) {
        this(id, start, end, FunctionManager.getFunctions(AreaFunction.class));
    }

    public FunctionArea(int id, BlockPos start, BlockPos end, List<AreaFunction> functions) {
        super(start, end);
        this.id = id;
        this.functions = new ArrayList<>(functions);
    }

    public void executeByPlayer(Level level, @Nullable BlockPos interactionPos, Player player, @Nullable InteractionHand hand) {
        boolean showResult = isShowResult();
        List<Component> successComponents = new ArrayList<>();
        List<Component> failComponents = new ArrayList<>();
        for (AreaFunction function : functions) {
            if (!function.isEnabled()) continue;
            ActionResult result = function.execute(level, interactionPos, player, hand);
            if (showResult && result.hasResult()) {
                if (result.isSuccess()) {
                    successComponents.add(function.successComponent());
                } else if (result.isFailure()) {
                    failComponents.add(function.getDisplayName().copy().withStyle(ChatFormatting.GREEN).append(": ").append(function.failComponent().copy().withStyle(ChatFormatting.RED)));
                }
            }
        }

        sendActionResults(player, successComponents, failComponents);
    }

    public void executeWithoutPlayer(Level level, BlockPos pos, Consumer<Component> consumer) {
        boolean showResult = isShowResult();
        List<Component> components = new ArrayList<>();
        for (AreaFunction function : functions) {
            if (!function.isEnabled()) continue;
            ActionResult result = function.execute(level, pos);
            if (showResult && result.hasResult()) {
                if (result.isSuccess()) {
                    components.add(function.successComponent());
                } else if (result.isFailure()) {
                    components.add(function.getDisplayName().copy().withStyle(ChatFormatting.GREEN).append(": ").append(function.failComponent().copy().withStyle(ChatFormatting.RED)));
                }
            }
        }

        sendActionResults(components, consumer);
    }

    public boolean isShowResult() {
        return showResult;
    }

    public void setShowResult(boolean showResult) {
        this.showResult = showResult;
    }

    @Override
    public Type getType() {
        return Type.FUNCTION;
    }

    public boolean isSwingHand() {
        return swingHand;
    }

    public void setSwingHand(boolean swingHand) {
        this.swingHand = swingHand;
    }

    protected static void sendActionResults(List<Component> components, Consumer<Component> consumer) {
        for (Component component : components) {
            consumer.accept(component);
        }
    }

    public int getId() {
        return id;
    }

    public List<AreaFunction> getFunctions() {
        return List.copyOf(functions);
    }

    public boolean swap(int index, boolean swapWithPrevious) {
        return swapByIndex(functions, index, swapWithPrevious);
    }

    protected static void sendActionResults(Player player, List<Component> successComponents, List<Component> failComponents) {
        if (successComponents.size() == 1 && failComponents.isEmpty()) {
            sendActionResult(player, true, successComponents.get(0), Component.empty());
        } else if (failComponents.size() == 1 && successComponents.isEmpty()) {
            sendActionResult(player, false, Component.empty(), failComponents.get(0));
        } else {
            if (!successComponents.isEmpty()) {
                sendOverlayMessage(player, TranslationUtil.messageComponent("successful_operation_count", successComponents.size()));
            }
            for (Component failComponent : failComponents) {
                player.sendSystemMessage(failComponent);
            }
        }
    }

    @Override
    public void load(CompoundTag tag) {
        if (tag.contains("locked")) {
            locked = tag.getBoolean("locked");
        }
        if (tag.contains("showResult")) {
            showResult = tag.getBoolean("showResult");
        }
        if (tag.contains("swingHand")) {
            swingHand = tag.getBoolean("swingHand");
        }
        if (tag.contains("functions")) {
            functions.clear();
            tag.getList("functions", Tag.TAG_COMPOUND).stream()
               .map(t -> FunctionManager.tryParse(AreaFunction.class, ((CompoundTag) t)))
               .filter(Objects::nonNull).forEach(functions::add);
        }
    }

    public boolean isLocked() {
        return locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
    }

    @Override
    public void copyFrom(FunctionArea area) {
        this.functions.clear();
        this.functions.addAll(area.functions);
        this.showResult = area.showResult;
        this.swingHand = area.swingHand;
        this.locked = area.locked;
    }

    protected static void sendActionResult(Player player, boolean success, Component successedComponent, Component failededComponent) {
        if (success) {
            if (successedComponent.getString().isEmpty()) return;
            sendOverlayMessage(player, successedComponent);
        } else if (!failededComponent.getString().isEmpty()) {
            player.sendSystemMessage(failededComponent);
        }
    }

    protected static void sendOverlayMessage(Player player, Component component) {
        if (player instanceof ServerPlayer serverPlayer) {
            serverPlayer.sendSystemMessage(component, true);
        } else {
            Minecraft.getInstance().gui.setOverlayMessage(component, false);
        }
    }

    @Override
    public void save(CompoundTag tag) {
        super.save(tag);
        tag.putInt("id", id);
        tag.putBoolean("locked", locked);
        tag.putBoolean("showResult", showResult);
        tag.putBoolean("swingHand", swingHand);
        ListTag list = new ListTag();
        for (AreaFunction function : functions) {
            list.add(function.writeNbt(new CompoundTag()));
        }
        tag.put("functions", list);
    }

    public static <T> boolean swapByIndex(List<T> list, int index, boolean swapWithPrevious) {
        if (index < 0 || index >= list.size()) {
            return false;
        }

        int swapIndex = swapWithPrevious ? index - 1 : index + 1;

        if (swapIndex < 0 || swapIndex >= list.size()) {
            return false;
        }

        T element1 = list.get(index);
        T element2 = list.get(swapIndex);

        list.set(index, element2);
        list.set(swapIndex, element1);

        return true;
    }

    public static boolean remove(ServerLevel level, BlockPos pos) {
        boolean removed = GameData.getGameData(level).getFunctionAreas(level).removeIf(area -> area.contains(pos));
        if (removed) {
            Network.updateFunctionAreas(level.getServer());
        }
        return removed;
    }

    public static boolean add(ServerLevel level, FunctionArea area) {
        GameData gameData = GameData.getGameData(level);
        int id = area.getId();
        List<FunctionArea> areas = gameData.getFunctionAreas(level);
        if (areas.stream().anyMatch(a -> a.getId() == id || a.intersects(area))) {
            return false;
        }
        areas.add(area);
        Network.updateNewFunctionArea(level, area);
        return true;
    }

    @Nullable
    public static FunctionArea get(ServerLevel level, BlockPos pos) {
        return GameData.getGameData(level).getFunctionArea(level, pos);
    }

    public static boolean isLocked(Level level, BlockPos pos) {
        if (level instanceof ServerLevel serverLevel) {
            return GameData.getGameData(serverLevel).isLocked(serverLevel, pos);
        } else {
            return ClientGameManager.getInstance().isLocked(level, pos);
        }
    }

    @Nullable
    public static FunctionArea fromNbt(CompoundTag tag) {
        Area area = Area.fromNbt(tag);
        if (area != null && tag.contains("id", Tag.TAG_INT)) {
            return new FunctionArea(tag.getInt("id"), area.getMinPos(), area.getMaxPos()).readNbt(tag);
        }
        return null;
    }
}
