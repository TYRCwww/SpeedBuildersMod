package com.modcustom.moddev.network.s2c;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.client.ClientGameManager;
import dev.architectury.networking.NetworkManager;
import dev.architectury.utils.Env;
import net.minecraft.network.FriendlyByteBuf;

import java.util.function.Supplier;

public class FinishActivityS2CPacket implements NetworkPacket {

    private final int id;
    private final long runtime;

    public FinishActivityS2CPacket() {
        this(-1, -1L);
    }

    public FinishActivityS2CPacket(int id, long runtime) {
        this.id = id;
        this.runtime = runtime;
    }

    public FinishActivityS2CPacket(FriendlyByteBuf buf) {
        this(buf.readInt(), buf.readLong());
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(id);
        buf.writeLong(runtime);
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        NetworkManager.PacketContext context = contextSupplier.get();
        if (context.getEnvironment() == Env.CLIENT) {
            ClientGameManager manager = ClientGameManager.getInstance();
            int correction = manager.getCachedData().getTimerErrorCorrection();
            Long timeFix = (runtime > 0L) ? (correction != 0 ? Math.max(runtime + correction, 0L) : runtime) : null;
            if (id == -1) {
                manager.finishActivity(timeFix);
            } else {
                manager.finishActivity(id, timeFix);
            }
        }
    }
}
