package com.modcustom.moddev.commands.common;

import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.area.Area;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.network.Network;
import com.modcustom.moddev.utils.TranslationUtil;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;

import java.util.Collection;

public class CJCommand extends CommonCommand {

    public CJCommand() {
        super("cj");
    }

    @Override
    public LiteralArgumentBuilder<CommandSourceStack> build(LiteralArgumentBuilder<CommandSourceStack> builder, CommandBuildContext context) {
        return builder.requires(source -> source.hasPermission(2)).then(executeLiftCreateLimit()).then(executeCreate()).then(executeClear());
    }

    private LiteralArgumentBuilder<CommandSourceStack> executeLiftCreateLimit() {
        return Commands.literal("player").then(Commands.argument("players", EntityArgument.players()).executes(context -> {
            Collection<ServerPlayer> players = EntityArgument.getPlayers(context, "players");
            for (ServerPlayer player : players) {
                GameData.getGameData(context).liftCreateLimit(player);
            }
            context.getSource().sendSuccess(() -> TranslationUtil.messageComponent("lift_create_limit", players.size()), true);
            return 1;
        }));
    }

    private LiteralArgumentBuilder<CommandSourceStack> executeCreate() {
        return Commands.literal("cj").then(Commands.argument("pos1", BlockPosArgument.blockPos()).then(Commands.argument("pos2", BlockPosArgument.blockPos()).then(Commands.argument("pos3", BlockPosArgument.blockPos()).executes(context -> {
            BlockPos pos1 = BlockPosArgument.getBlockPos(context, "pos1");
            BlockPos pos2 = BlockPosArgument.getBlockPos(context, "pos2");
            BlockPos pos3 = BlockPosArgument.getBlockPos(context, "pos3");
            Area target = new Area(pos1, pos2);
            Area construction = new Area(pos3, target);
            ActivityArea area = ActivityArea.create(GameData.getGameData(context).getNextActivityAreaId(), context.getSource().getPlayer() != null ? context.getSource().getPlayer().getUUID() : null, context.getSource().getLevel().dimension().location().toString(), construction, target, null);
            if (area != null) {
                GameData.getGameData(context).addActivityArea(area);
                Network.updateActivityAreasForAll(context.getSource().getServer());
                context.getSource().sendSuccess(() -> TranslationUtil.messageComponent("create_area.callback"), true);
                return 1;
            } else {
                context.getSource().sendSuccess(() -> TranslationUtil.messageComponent("create_area.callback.failed"), true);
                return 0;
            }
        }))));
    }

    private LiteralArgumentBuilder<CommandSourceStack> executeClear() {
        return Commands.literal("xc").executes(context -> {
            int count = GameData.getGameData(context).clearActivityAreas();
            Network.updateActivityAreasForAll(context.getSource().getServer());
            context.getSource().sendSuccess(() -> TranslationUtil.messageComponent("clear_areas", count), true);
            return 1;
        });
    }
}
