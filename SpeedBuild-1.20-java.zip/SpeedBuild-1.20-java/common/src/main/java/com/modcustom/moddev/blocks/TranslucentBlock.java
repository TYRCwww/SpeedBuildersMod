package com.modcustom.moddev.blocks;

import com.modcustom.moddev.blocks.entities.TranslucentBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

public class TranslucentBlock extends BaseEntityBlock {

    public TranslucentBlock(Properties properties) {
        super(properties);
    }

    @Nullable
    @Override
    public TranslucentBlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new TranslucentBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> blockEntityType) {
        return createTickerHelper(blockEntityType, blockEntityType, (level1, blockPos, blockState, blockEntity) -> TranslucentBlockEntity.tick(level1, blockPos, blockState, (TranslucentBlockEntity) blockEntity));
    }

    @Override
    public boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
        return true;
    }

    @Override
    public ItemStack getCloneItemStack(BlockGetter level, BlockPos pos, BlockState state) {
        if (level.getBlockEntity(pos) instanceof TranslucentBlockEntity entity) {
            BlockState renderingState = entity.getRenderingState();
            return renderingState.getBlock().getCloneItemStack(level, pos, renderingState);
        }
        return super.getCloneItemStack(level, pos, state);
    }

    @Override
    public float getShadeBrightness(BlockState state, BlockGetter level, BlockPos pos) {
        return 1.0f;
    }
}
