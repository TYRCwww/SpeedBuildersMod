package com.modcustom.moddev.game.activity;

import com.modcustom.moddev.game.AreaFinder;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.network.Network;
import dev.architectury.event.events.client.ClientPlayerEvent;
import dev.architectury.event.events.common.TickEvent;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class ActivityManager {

    private static final Map<Integer, Activity> ACTIVITIES = new ConcurrentHashMap<>();

    public static void register() {
        TickEvent.SERVER_LEVEL_POST.register(ActivityManager::tick);
    }

    public static void tick(ServerLevel level) {
        long time = System.currentTimeMillis();
        ResourceKey<Level> dimension = level.dimension();
        Iterator<Map.Entry<Integer, Activity>> iterator = ACTIVITIES.entrySet().iterator();
        while (iterator.hasNext()) {
            Activity activity = iterator.next().getValue();
            if (!dimension.equals(activity.getLevel().dimension())) continue;
            activity.tick(time);
            if (activity.isFinished()) {
                iterator.remove();
            }
        }
    }

    public static void registerClient() {
        ClientPlayerEvent.CLIENT_PLAYER_QUIT.register(player -> ACTIVITIES.clear());
    }

    @Nullable
    public static Activity getActivity(int id) {
        return ACTIVITIES.get(id);
    }

    public static List<Activity> getActivities(ServerLevel level, BlockPos pos) {
        List<Activity> result = new ArrayList<>();
        for (Activity activity : ACTIVITIES.values()) {
            if (activity.getLevel().equals(level) && activity.isInActivityArea(pos)) {
                result.add(activity);
            }
        }
        return result;
    }

    public static boolean hasActivity(int id) {
        return ACTIVITIES.containsKey(id);
    }

    public static void removeActivity(int id) {
        if (ACTIVITIES.containsKey(id)) {
            ACTIVITIES.get(id).finish(true);
            ACTIVITIES.remove(id);
        }
    }

    public static boolean startActivity(ServerPlayer player, int areaId, @Nullable AreaFinder areaFinder) {
        ServerLevel level = player.serverLevel();
        GameData gameData = GameData.getGameData(player);
        ActivityArea area = areaFinder != null && areaId == -1 ? areaFinder.find(level, player.blockPosition(), area1 -> !area1.getConfig().isSimpleMode()) : gameData.getActivityArea(areaId);
        if (area == null || area.getConfig().isSimpleMode()) return false;
        if (!findActivities(player).contains(area.getId())) {
            Network.finishActivity(player);
        }
        Set<ServerPlayer> players = new HashSet<>();
        players.add(player);
        players.addAll(level.getEntitiesOfClass(ServerPlayer.class, area.getBox()));
        addActivity(level, area, player.getDisplayName().getString(), players);
        return true;
    }

    public static boolean startActivity(ServerLevel level, BlockPos pos, int areaId, @Nullable AreaFinder areaFinder) {
        ActivityArea area = areaFinder != null ? areaFinder.find(level, pos, area1 -> !area1.getConfig().isSimpleMode()) : GameData.getGameData(level).getActivityArea(areaId);
        if (area == null || area.getConfig().isSimpleMode()) return false;
        List<ServerPlayer> players = level.getEntitiesOfClass(ServerPlayer.class, area.getBox());
        addActivity(level, area, null, new HashSet<>(players));
        return true;
    }

    public static void addActivity(ServerLevel level, ActivityArea area, @Nullable String initiator, Set<ServerPlayer> players) {
        if (ACTIVITIES.containsKey(area.getId())) {
            ACTIVITIES.get(area.getId()).finish(true);
        }
        if (!area.getConfig().isSimpleMode()) {
            players.addAll(area.getConfig().getForcedPlayers(level));
        }
        players.stream().filter(ActivityManager::hasActivity).forEach(Network::finishActivity);
        ACTIVITIES.values().forEach(activity -> activity.getPlayers().removeIf(players::contains));
        ACTIVITIES.put(area.getId(), new Activity(level, area.copy(), initiator, players));
    }

    public static boolean hasActivity(ServerPlayer player) {
        return !findActivities(player).isEmpty();
    }

    public static Set<Integer> findActivities(ServerPlayer player) {
        Set<Integer> result = new HashSet<>();
        for (Map.Entry<Integer, Activity> entry : ACTIVITIES.entrySet()) {
            if (entry.getValue().getPlayers().contains(player)) {
                result.add(entry.getKey());
            }
        }
        return result;
    }

    public static void stopActivity(int id) {
        if (ACTIVITIES.containsKey(id)) {
            ACTIVITIES.get(id).interrupt();
            ACTIVITIES.remove(id);
        }
    }
}
