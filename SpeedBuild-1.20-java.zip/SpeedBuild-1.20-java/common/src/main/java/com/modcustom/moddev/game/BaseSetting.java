package com.modcustom.moddev.game;

import com.modcustom.moddev.api.SerializableData;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import org.jetbrains.annotations.Nullable;

public class BaseSetting implements SerializableData<BaseSetting> {

    public static final Block DEFAULT_FILL_BLOCK = Blocks.GRASS_BLOCK;
    private boolean ignoreProtectedArea = true;
    private boolean copyAir = false;
    private boolean autoFill = false;
    @Nullable
    private Block fillBlock = DEFAULT_FILL_BLOCK;

    public boolean isIgnoreProtectedArea() {
        return ignoreProtectedArea;
    }

    public void setIgnoreProtectedArea(boolean ignoreProtectedArea) {
        this.ignoreProtectedArea = ignoreProtectedArea;
    }

    public boolean isCopyAir() {
        return copyAir;
    }

    public void setCopyAir(boolean copyAir) {
        this.copyAir = copyAir;
    }

    public boolean isAutoFill() {
        return autoFill;
    }

    public void setAutoFill(boolean autoFill) {
        this.autoFill = autoFill;
    }

    @Nullable
    public Block getFillBlock() {
        return !autoFill ? null : fillBlock;
    }

    public void setFillBlock(@Nullable Block fillBlock) {
        this.fillBlock = fillBlock;
    }

    @Nullable
    public Block getActuallyFillBlock() {
        return fillBlock;
    }

    @Nullable
    public ResourceLocation getFillBlockId() {
        return fillBlock != null ? BuiltInRegistries.BLOCK.getKey(fillBlock) : null;
    }

    @Override
    public void save(CompoundTag tag) {
        tag.putBoolean("ignoreProtectedArea", ignoreProtectedArea);
        tag.putBoolean("copyAir", copyAir);
        tag.putBoolean("autoFill", autoFill);
        if (fillBlock != null) {
            tag.putString("fillBlock", BuiltInRegistries.BLOCK.getKey(fillBlock).toString());
        }
    }

    @Override
    public void load(CompoundTag tag) {
        if (tag.contains("ignoreProtectedArea")) {
            this.ignoreProtectedArea = tag.getBoolean("ignoreProtectedArea");
        }
        if (tag.contains("copyAir")) {
            this.copyAir = tag.getBoolean("copyAir");
        }
        if (tag.contains("autoFill")) {
            this.autoFill = tag.getBoolean("autoFill");
        }
        if (tag.contains("fillBlock")) {
            ResourceLocation id = ResourceLocation.tryParse(tag.getString("fillBlock"));
            if (id != null) {
                this.fillBlock = BuiltInRegistries.BLOCK.get(id);
            } else {
                this.fillBlock = null;
            }
        }
    }

    @Override
    public void copyFrom(BaseSetting data) {
        this.ignoreProtectedArea = data.ignoreProtectedArea;
        this.copyAir = data.copyAir;
        this.autoFill = data.autoFill;
        this.fillBlock = data.fillBlock;
    }

    public static BaseSetting fromNbt(CompoundTag tag) {
        return new BaseSetting().readNbt(tag);
    }

    public static Block tryParse(String str) {
        ResourceLocation id = ResourceLocation.tryParse(str);
        return id != null ? BuiltInRegistries.BLOCK.getOptional(id).orElse(null) : BuiltInRegistries.BLOCK.stream().filter(block -> I18n.get(block.getDescriptionId()).equals(str)).findFirst().orElse(null);
    }
}
