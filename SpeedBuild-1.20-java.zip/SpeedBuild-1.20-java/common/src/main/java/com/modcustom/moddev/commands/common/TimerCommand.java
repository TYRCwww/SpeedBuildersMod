package com.modcustom.moddev.commands.common;

import com.modcustom.moddev.network.Network;
import com.modcustom.moddev.network.s2c.ControlTimerS2CPacket;
import com.modcustom.moddev.utils.TranslationUtil;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;

public class TimerCommand extends CommonCommand {

    public TimerCommand() {
        super("timer");
    }

    @Override
    public LiteralArgumentBuilder<CommandSourceStack> build(LiteralArgumentBuilder<CommandSourceStack> builder, CommandBuildContext context) {
        builder = builder.requires(stack -> stack.hasPermission(2));
        for (ControlTimerS2CPacket.Action action : ControlTimerS2CPacket.Action.values()) {
            builder = builder.then(execute(action.getName(), action));
        }
        return builder;
    }

    private LiteralArgumentBuilder<CommandSourceStack> execute(String name, ControlTimerS2CPacket.Action action) {
        return Commands.literal(name).then(Commands.argument("players", EntityArgument.players()).executes(ctx -> {
            EntityArgument.getPlayers(ctx, "players").forEach(player -> Network.controlTimer(player, action));
            ctx.getSource().sendSuccess(TranslationUtil::successComponent, true);
            return 1;
        }));
    }
}
