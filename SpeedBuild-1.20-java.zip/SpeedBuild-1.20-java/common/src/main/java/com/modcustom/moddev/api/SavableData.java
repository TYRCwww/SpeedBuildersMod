package com.modcustom.moddev.api;

import com.mojang.logging.LogUtils;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtUtils;
import org.slf4j.Logger;

import java.io.File;
import java.io.IOException;

public interface SavableData {

    Logger LOGGER = LogUtils.getLogger();

    default CompoundTag toNbt() {
        return writeNbt(new CompoundTag());
    }

    default CompoundTag writeNbt(CompoundTag tag) {
        save(tag);
        return tag;
    }

    void save(CompoundTag tag);

    default void save(File file) {
        CompoundTag compoundTag = new CompoundTag();
        compoundTag.put("data", this.writeNbt(new CompoundTag()));
        NbtUtils.addCurrentDataVersion(compoundTag);
        try {
            NbtIo.writeCompressed(compoundTag, file);
        } catch (IOException iOException) {
            LOGGER.error("Could not save data {}", this, iOException);
        }
    }
}
