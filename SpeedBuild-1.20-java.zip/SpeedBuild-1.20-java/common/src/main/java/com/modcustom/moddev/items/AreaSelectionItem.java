package com.modcustom.moddev.items;

import com.modcustom.moddev.game.AreaSelector;
import com.modcustom.moddev.utils.TranslationUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public abstract class AreaSelectionItem extends AreaVisibleItem {

    public AreaSelectionItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand interactionHand) {
        if (level.isClientSide()) {
            AreaSelector selector = getAreaSelector();
            if (!player.isDescending()) {
                player.sendSystemMessage(TranslationUtil.messageComponent("clear_area"));
                selector.clear();
            } else if (selector.hasArea()) {
                requestCreateArea(selector);
                selector.clear();
            } else {
                Minecraft.getInstance().gui.setOverlayMessage(TranslationUtil.messageComponent("no_area"), false);
            }
        }
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(interactionHand), level.isClientSide());
    }

    protected abstract AreaSelector getAreaSelector();

    protected abstract void requestCreateArea(AreaSelector selector);
}
