package com.modcustom.moddev.mixin;

import com.modcustom.moddev.events.EntityEventHandler;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.EntityHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(Projectile.class)
public abstract class ProjectileMixin {

    @Redirect(method = "onHit", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/projectile/Projectile;onHitEntity(Lnet/minecraft/world/phys/EntityHitResult;)V"))
    private void speed_build$onHit(Projectile instance, EntityHitResult result) {
        if (!EntityEventHandler.tryDiscardEntity(result.getEntity())) {
            this.onHitEntity(result);
        }
    }

    @Shadow
    protected abstract void onHitEntity(EntityHitResult result);
}
