package com.modcustom.moddev.events;

import com.modcustom.moddev.api.AreaVisible;
import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.AreaSelector;
import com.modcustom.moddev.game.area.FunctionArea;
import com.modcustom.moddev.items.AreaVisibleItem;
import com.modcustom.moddev.utils.ItemUtil;
import com.modcustom.moddev.utils.PlayerUtil;
import com.modcustom.moddev.utils.TranslationUtil;
import dev.architectury.event.EventResult;
import dev.architectury.event.events.common.InteractionEvent;
import dev.architectury.platform.Platform;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;

import java.util.Optional;

public class InteractionEventHandler {

    private static long lastClickTime = 0L;
    private static long lastClientClickTime = 0L;
    private static long lastServerClickTime = 0L;

    public static void register() {
        InteractionEvent.LEFT_CLICK_BLOCK.register(InteractionEventHandler::handleLeftClick);
        InteractionEvent.LEFT_CLICK_BLOCK.register((player, hand, pos, face) -> handleInteractFunctionArea(player, hand, pos, face, false));
        InteractionEvent.RIGHT_CLICK_BLOCK.register((player, hand, pos, face) -> handleInteractFunctionArea(player, hand, pos, face, true));
        InteractionEvent.CLIENT_LEFT_CLICK_AIR.register(InteractionEventHandler::handleAirLeftClick);
    }

    private static EventResult handleInteractFunctionArea(Player player, InteractionHand hand, BlockPos pos, Direction face, boolean rightClick) {
        EventResult result = EventResult.pass();
        if (hand != InteractionHand.MAIN_HAND) return result;
        ItemStack stack = player.getItemInHand(hand);
        if (rightClick && stack.getItem() instanceof AreaVisibleItem item) {
            InteractionResult interactionResult = item.useOn(new UseOnContext(player, hand, new BlockHitResult(pos.getCenter(), face, pos, false)));
            return EventResult.interrupt(interactionResult.consumesAction());
        }
        long currentTime = System.currentTimeMillis();
        Level level = player.level();
        long interval = rightClick ? 250L : 150L;
        FunctionArea area;
        if (level instanceof ServerLevel serverLevel) {
            area = Optional.ofNullable(FunctionArea.get(serverLevel, pos)).orElse(FunctionArea.get(serverLevel, pos.relative(face)));
            if (area != null && area.isLocked()) {
                result = EventResult.interruptFalse();
            }
            if (currentTime - lastServerClickTime < interval) {
                lastServerClickTime = currentTime;
                return result;
            }
            if (area != null) {
                area.executeByPlayer(level, pos, player, hand);
            }
            lastServerClickTime = currentTime;
        } else {
            area = Optional.ofNullable(ClientGameManager.getInstance().getFunctionArea(level, pos)).orElse(ClientGameManager.getInstance().getFunctionArea(level, pos.relative(face)));
            if (area != null && area.isLocked()) {
                result = EventResult.interruptDefault();
            }
            if (currentTime - lastClientClickTime < interval) {
                lastClientClickTime = currentTime;
                return result;
            }
            if (area != null) {
                area.executeByPlayer(level, pos, player, hand);
            }
            lastClientClickTime = currentTime;
        }

        if (area != null && area.isSwingHand()) {
            player.swing(hand);
        }
        return result;
    }

    private static EventResult handleLeftClick(Player player, InteractionHand hand, BlockPos pos, Direction face) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(stack.getItem() instanceof AreaVisible)) return EventResult.pass();

        EventResult result = EventResult.interrupt(Platform.isForge());
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastClickTime < 100L) {
            lastClickTime = currentTime;
            return result;
        }

        if (ItemUtil.isTargetAreaSelection(stack)) {
            selectTargetPos(player, pos);
        } else if (ItemUtil.isConstructionAreaSelection(stack)) {
            selectConstructionPos(player, face == Direction.UP ? pos.relative(face) : pos);
        } else if (ItemUtil.isProtectedAreaSelection(stack)) {
            selectProtectedPos(player, pos);
        } else if (ItemUtil.isFunctionAreaSelection(stack)) {
            selectFunctionPos(player, pos);
        } else if (ItemUtil.isActivityAreaConfiguration(stack)) {
            printAreaInfo(player, face == Direction.UP ? pos.relative(face) : pos);
        }

        lastClickTime = currentTime;
        return result;
    }

    private static void selectTargetPos(Player player, BlockPos pos) {
        Level level = player.level();
        if (!level.isClientSide()) return;
        player.sendSystemMessage(TranslationUtil.messageComponent("select_pos." + (ClientGameManager.getInstance().isSecondPos() ? "second" : "first"), pos.getX(), pos.getY(), pos.getZ()));
        ClientGameManager.getInstance().selectTargetPos(level, pos);
    }

    private static void selectConstructionPos(Player player, BlockPos pos) {
        Level level = player.level();
        if (!level.isClientSide()) return;
        if (!ClientGameManager.getInstance().selectConstructionPos(level, pos)) {
            player.sendSystemMessage(TranslationUtil.messageComponent("select_target_pos.failed"));
        }
    }

    private static void selectProtectedPos(Player player, BlockPos pos) {
        Level level = player.level();
        if (!level.isClientSide()) return;
        ClientGameManager manager = ClientGameManager.getInstance();
        boolean overlapping = manager.getCachedData().isOverlappingProtectedAreas();
        if (!overlapping && (!manager.getActivityAreas(level, pos).isEmpty() || manager.isProtected(level, pos))) {
            player.sendSystemMessage(TranslationUtil.messageComponent("area_intersected"));
            return;
        }
        AreaSelector selector = manager.getProtectedAreaSelector();
        boolean hasArea = selector.select(level, pos);
        if (hasArea && !overlapping && manager.intersectsAnyArea(level, selector.getArea(), true, true, false)) {
            player.sendSystemMessage(TranslationUtil.messageComponent("area_intersected"));
            selector.deselectLast();
            return;
        }
        player.sendSystemMessage(TranslationUtil.messageComponent("select_pos." + (hasArea ? "second" : "first"), pos.getX(), pos.getY(), pos.getZ()));
    }

    private static void selectFunctionPos(Player player, BlockPos pos) {
        Level level = player.level();
        if (!level.isClientSide()) return;
        ClientGameManager manager = ClientGameManager.getInstance();
        if (manager.getFunctionArea(level, pos) != null) {
            player.sendSystemMessage(TranslationUtil.messageComponent("area_intersected"));
            return;
        }
        AreaSelector selector = manager.getFunctionAreaSelector();
        boolean hasArea = selector.select(level, pos);
        if (hasArea && manager.intersectsAnyArea(level, selector.getArea(), false, false, true)) {
            player.sendSystemMessage(TranslationUtil.messageComponent("area_intersected"));
            selector.deselectLast();
            return;
        }
        player.sendSystemMessage(TranslationUtil.messageComponent("select_pos." + (hasArea ? "second" : "first"), pos.getX(), pos.getY(), pos.getZ()));
    }

    private static void printAreaInfo(Player player, BlockPos pos) {
        if (!player.level().isClientSide()) return;
        ClientGameManager.getInstance().getActivityAreas(player.level(), pos).forEach(area -> area.sendInfo(player));
    }

    private static void handleAirLeftClick(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return;
        Optional.ofNullable(ClientGameManager.getInstance().getTargetPreviewPos()).ifPresent(pos -> selectTargetPos(player, pos));
        Optional.ofNullable(ClientGameManager.getInstance().getConstructionPreviewPos()).ifPresent(pos -> selectConstructionPos(player, pos));
        Optional.ofNullable(ClientGameManager.getInstance().getProtectedPreviewPos()).ifPresent(pos -> selectProtectedPos(player, pos));
        Optional.ofNullable(ClientGameManager.getInstance().getFunctionPreviewPos()).ifPresent(pos -> selectFunctionPos(player, pos));
        if (ItemUtil.isActivityAreaConfiguration(player.getItemInHand(hand))) {
            Optional.ofNullable(PlayerUtil.findFirstActivityArea(player, 5)).ifPresent(area -> area.sendInfo(player));
        }
    }
}
