package com.modcustom.moddev.network.s2c;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.client.ClientGameManager;
import dev.architectury.networking.NetworkManager;
import dev.architectury.utils.Env;
import net.minecraft.network.FriendlyByteBuf;

import java.util.function.Supplier;

public class ControlTimerS2CPacket implements NetworkPacket {

    private final Action action;

    public ControlTimerS2CPacket(FriendlyByteBuf buf) {
        this(Action.fromId(buf.readInt()));
    }

    public ControlTimerS2CPacket(Action action) {
        this.action = action;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(action.ordinal());
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        NetworkManager.PacketContext context = contextSupplier.get();
        if (context.getEnvironment() == Env.CLIENT) {
            action.execute();
        }
    }

    public enum Action {
        START("start") {
            @Override
            void execute() {
                ClientGameManager.getInstance().startTimer();
            }
        },
        STOP("stop") {
            @Override
            void execute() {
                ClientGameManager.getInstance().stopTimer();
            }
        },
        PAUSE("pause") {
            @Override
            void execute() {
                ClientGameManager.getInstance().getActivityTimer().pause();
            }
        },
        RESUME("resume") {
            @Override
            void execute() {
                ClientGameManager.getInstance().getActivityTimer().resume();
            }
        };

        private final String name;

        Action(String name) {
            this.name = name;
        }

        abstract void execute();

        public String getName() {
            return name;
        }

        public static Action fromId(int id) {
            return values()[id];
        }
    }
}
