package com.modcustom.moddev.items.activity;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.items.AreaVisibleItem;
import com.modcustom.moddev.utils.TranslationUtil;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class TargetAreaSelectionItem extends AreaVisibleItem {

    public TargetAreaSelectionItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand interactionHand) {
        if (level.isClientSide()) {
            player.sendSystemMessage(TranslationUtil.messageComponent("clear_area"));
            ClientGameManager.getInstance().clear();
        }
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(interactionHand), level.isClientSide());
    }
}
