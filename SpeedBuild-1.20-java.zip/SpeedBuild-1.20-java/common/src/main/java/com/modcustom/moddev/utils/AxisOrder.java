package com.modcustom.moddev.utils;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.function.Consumer;

public enum AxisOrder implements StringRepresentable {
    XYZ {
        @Override
        public void traverse(BoundingBox boundingBox, boolean xDescending, boolean yDescending, boolean zDescending, Consumer<BlockPos> consumer) {
            int[] xRange = getRange(boundingBox.minX(), boundingBox.maxX(), xDescending);
            int[] yRange = getRange(boundingBox.minY(), boundingBox.maxY(), yDescending);
            int[] zRange = getRange(boundingBox.minZ(), boundingBox.maxZ(), zDescending);

            for (int x = xRange[0]; x != xRange[1] + xRange[2]; x += xRange[2]) {
                for (int y = yRange[0]; y != yRange[1] + yRange[2]; y += yRange[2]) {
                    for (int z = zRange[0]; z != zRange[1] + zRange[2]; z += zRange[2]) {
                        consumer.accept(new BlockPos(x, y, z));
                    }
                }
            }
        }
    },
    XZY {
        @Override
        public void traverse(BoundingBox boundingBox, boolean xDescending, boolean yDescending, boolean zDescending, Consumer<BlockPos> consumer) {
            int[] xRange = getRange(boundingBox.minX(), boundingBox.maxX(), xDescending);
            int[] zRange = getRange(boundingBox.minZ(), boundingBox.maxZ(), zDescending);
            int[] yRange = getRange(boundingBox.minY(), boundingBox.maxY(), yDescending);

            for (int x = xRange[0]; x != xRange[1] + xRange[2]; x += xRange[2]) {
                for (int z = zRange[0]; z != zRange[1] + zRange[2]; z += zRange[2]) {
                    for (int y = yRange[0]; y != yRange[1] + yRange[2]; y += yRange[2]) {
                        consumer.accept(new BlockPos(x, y, z));
                    }
                }
            }
        }
    },
    YXZ {
        @Override
        public void traverse(BoundingBox boundingBox, boolean xDescending, boolean yDescending, boolean zDescending, Consumer<BlockPos> consumer) {
            int[] yRange = getRange(boundingBox.minY(), boundingBox.maxY(), yDescending);
            int[] xRange = getRange(boundingBox.minX(), boundingBox.maxX(), xDescending);
            int[] zRange = getRange(boundingBox.minZ(), boundingBox.maxZ(), zDescending);

            for (int y = yRange[0]; y != yRange[1] + yRange[2]; y += yRange[2]) {
                for (int x = xRange[0]; x != xRange[1] + xRange[2]; x += xRange[2]) {
                    for (int z = zRange[0]; z != zRange[1] + zRange[2]; z += zRange[2]) {
                        consumer.accept(new BlockPos(x, y, z));
                    }
                }
            }
        }
    },
    YZX {
        @Override
        public void traverse(BoundingBox boundingBox, boolean xDescending, boolean yDescending, boolean zDescending, Consumer<BlockPos> consumer) {
            int[] yRange = getRange(boundingBox.minY(), boundingBox.maxY(), yDescending);
            int[] zRange = getRange(boundingBox.minZ(), boundingBox.maxZ(), zDescending);
            int[] xRange = getRange(boundingBox.minX(), boundingBox.maxX(), xDescending);

            for (int y = yRange[0]; y != yRange[1] + yRange[2]; y += yRange[2]) {
                for (int z = zRange[0]; z != zRange[1] + zRange[2]; z += zRange[2]) {
                    for (int x = xRange[0]; x != xRange[1] + xRange[2]; x += xRange[2]) {
                        consumer.accept(new BlockPos(x, y, z));
                    }
                }
            }
        }
    },
    ZXY {
        @Override
        public void traverse(BoundingBox boundingBox, boolean xDescending, boolean yDescending, boolean zDescending, Consumer<BlockPos> consumer) {
            int[] zRange = getRange(boundingBox.minZ(), boundingBox.maxZ(), zDescending);
            int[] xRange = getRange(boundingBox.minX(), boundingBox.maxX(), xDescending);
            int[] yRange = getRange(boundingBox.minY(), boundingBox.maxY(), yDescending);

            for (int z = zRange[0]; z != zRange[1] + zRange[2]; z += zRange[2]) {
                for (int x = xRange[0]; x != xRange[1] + xRange[2]; x += xRange[2]) {
                    for (int y = yRange[0]; y != yRange[1] + yRange[2]; y += yRange[2]) {
                        consumer.accept(new BlockPos(x, y, z));
                    }
                }
            }
        }
    },
    ZYX {
        @Override
        public void traverse(BoundingBox boundingBox, boolean xDescending, boolean yDescending, boolean zDescending, Consumer<BlockPos> consumer) {
            int[] zRange = getRange(boundingBox.minZ(), boundingBox.maxZ(), zDescending);
            int[] yRange = getRange(boundingBox.minY(), boundingBox.maxY(), yDescending);
            int[] xRange = getRange(boundingBox.minX(), boundingBox.maxX(), xDescending);

            for (int z = zRange[0]; z != zRange[1] + zRange[2]; z += zRange[2]) {
                for (int y = yRange[0]; y != yRange[1] + yRange[2]; y += yRange[2]) {
                    for (int x = xRange[0]; x != xRange[1] + xRange[2]; x += xRange[2]) {
                        consumer.accept(new BlockPos(x, y, z));
                    }
                }
            }
        }
    };

    public static final Codec<AxisOrder> CODEC = StringRepresentable.fromEnum(AxisOrder::values);

    @NotNull
    @Override
    public String getSerializedName() {
        return name();
    }

    public abstract void traverse(BoundingBox boundingBox, boolean xDescending, boolean yDescending, boolean zDescending, Consumer<BlockPos> consumer);

    protected int[] getRange(int min, int max, boolean descending) {
        return descending ? new int[]{max, min, -1} : new int[]{min, max, 1};
    }

    public static AxisOrder fromStringOrDefault(String str, AxisOrder defaultOrder) {
        AxisOrder axisOrder = fromString(str);
        return axisOrder != null ? axisOrder : defaultOrder;
    }

    @Nullable
    public static AxisOrder fromString(String str) {
        return Arrays.stream(values()).filter(axisOrder -> axisOrder.name().equalsIgnoreCase(str)).findFirst().orElse(null);
    }
}