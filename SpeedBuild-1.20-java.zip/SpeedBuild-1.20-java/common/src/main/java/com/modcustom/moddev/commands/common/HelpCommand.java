package com.modcustom.moddev.commands.common;

import com.modcustom.moddev.SpeedBuild;
import com.modcustom.moddev.utils.TranslationUtil;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;

import java.util.Map;

public class HelpCommand extends CommonCommand {

    public HelpCommand() {
        super("?");
    }

    @Override
    public LiteralArgumentBuilder<CommandSourceStack> build(LiteralArgumentBuilder<CommandSourceStack> builder, CommandBuildContext context) {
        return builder.executes(this::executeSendMessage);
    }

    private int executeSendMessage(CommandContext<CommandSourceStack> context) {
        for (Map.Entry<String, String> entry : DESCRIPTIONS.entrySet()) {
            String value = entry.getKey();
            String key = entry.getValue();
            context.getSource().sendSystemMessage(Component.literal("/" + value + " ").withStyle(ChatFormatting.GREEN).append(Component.translatable(key).withStyle(ChatFormatting.WHITE)).withStyle(style -> style.withClickEvent(new ClickEvent(ClickEvent.Action.SUGGEST_COMMAND, "/" + value))));
        }
        context.getSource().sendSystemMessage(TranslationUtil.messageComponent("authors"));
        context.getSource().sendSystemMessage(TranslationUtil.messageComponent("version", SpeedBuild.getVersion()));
        return 1;
    }
}
