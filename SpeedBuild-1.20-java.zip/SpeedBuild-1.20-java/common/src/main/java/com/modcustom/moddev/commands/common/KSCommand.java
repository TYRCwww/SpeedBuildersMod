package com.modcustom.moddev.commands.common;

import com.modcustom.moddev.game.activity.ActivityManager;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.data.GameData;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Set;

public class KSCommand extends CommonCommand {

    public KSCommand() {
        super("ks");
    }

    @Override
    public LiteralArgumentBuilder<CommandSourceStack> build(LiteralArgumentBuilder<CommandSourceStack> builder, CommandBuildContext context) {
        return builder.executes(this::executeAddNearestActivity);
    }

    private int executeAddNearestActivity(CommandContext<CommandSourceStack> context) {
        CommandSourceStack source = context.getSource();
        Vec3 pos = source.getPosition();
        ServerLevel level = source.getLevel();

        GameData gameData = GameData.getGameData(context);
        ActivityArea nearestArea = gameData.getNearestActivityArea(level, pos, 15, area -> !area.getConfig().isSimpleMode());

        if (nearestArea != null) {
            Set<ServerPlayer> players = new HashSet<>(level.getEntitiesOfClass(ServerPlayer.class, nearestArea.getBox()));
            if (source.getPlayer() != null) {
                players.add(source.getPlayer());
            }
            ActivityManager.addActivity(level, nearestArea, source.getDisplayName().getString(), players);
        }
        return 1;
    }
}
