package com.modcustom.moddev.network.s2c;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.client.ClientGameManager;
import dev.architectury.networking.NetworkManager;
import dev.architectury.utils.Env;
import net.minecraft.network.FriendlyByteBuf;

import java.util.function.Supplier;

public class StartActivityTimerS2CPacket implements NetworkPacket {

    private final int id;
    private final long startTime;

    public StartActivityTimerS2CPacket(FriendlyByteBuf buf) {
        this(buf.readInt(), buf.readLong());
    }

    public StartActivityTimerS2CPacket(int id, long startTime) {
        this.id = id;
        this.startTime = startTime;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(id);
        buf.writeLong(startTime);
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        NetworkManager.PacketContext context = contextSupplier.get();
        if (context.getEnvironment() == Env.CLIENT) {
            ClientGameManager.getInstance().startActivity(id, startTime);
        }
    }
}
