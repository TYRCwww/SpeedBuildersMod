package com.modcustom.moddev.utils;

import com.modcustom.moddev.api.AreaVisible;
import com.modcustom.moddev.game.area.Area;
import com.modcustom.moddev.registry.ModItems;
import net.minecraft.world.item.ItemStack;

public class ItemUtil {

    public static boolean isActivityAreaConfiguration(ItemStack itemStack) {
        return itemStack.is(ModItems.AREA_CONFIGURATION.get());
    }

    public static boolean isTargetAreaSelection(ItemStack itemStack) {
        return itemStack.is(ModItems.TARGET_AREA_SELECTION.get());
    }

    public static boolean isConstructionAreaSelection(ItemStack itemStack) {
        return itemStack.is(ModItems.CONSTRUCTION_AREA_SELECTION.get());
    }

    public static boolean isProtectedAreaSelection(ItemStack itemStack) {
        return itemStack.is(ModItems.PROTECTED_AREA_SELECTION.get());
    }

    public static boolean isFunctionAreaSelection(ItemStack itemStack) {
        return itemStack.is(ModItems.FUNCTION_AREA_SELECTION.get());
    }

    public static boolean isActivityAreaVisible(ItemStack itemStack) {
        return itemStack.getItem() instanceof AreaVisible areaVisible && areaVisible.isVisible(Area.Type.ACTIVITY);
    }

    public static boolean isProtectedAreaVisible(ItemStack itemStack) {
        return itemStack.getItem() instanceof AreaVisible areaVisible && areaVisible.isVisible(Area.Type.PROTECTED);
    }

    public static boolean isFunctionAreaVisible(ItemStack itemStack) {
        return itemStack.getItem() instanceof AreaVisible areaVisible && areaVisible.isVisible(Area.Type.FUNCTION);
    }
}
