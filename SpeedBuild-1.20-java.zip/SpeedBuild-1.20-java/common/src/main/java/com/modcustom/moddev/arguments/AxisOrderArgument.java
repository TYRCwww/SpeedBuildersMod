package com.modcustom.moddev.arguments;

import com.modcustom.moddev.utils.AxisOrder;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.arguments.StringRepresentableArgument;

public class AxisOrderArgument extends StringRepresentableArgument<AxisOrder> {

    protected AxisOrderArgument() {
        super(AxisOrder.CODEC, AxisOrder::values);
    }

    public static AxisOrderArgument order() {
        return new AxisOrderArgument();
    }

    public static AxisOrder getOrder(CommandContext<CommandSourceStack> context, String name) {
        return context.getArgument(name, AxisOrder.class);
    }
}
