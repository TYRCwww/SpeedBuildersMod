package com.modcustom.moddev.network.c2s;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.config.GlobeConfig;
import com.modcustom.moddev.utils.TranslationUtil;
import dev.architectury.networking.NetworkManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;

import java.util.HashSet;
import java.util.Set;
import java.util.function.Supplier;

public class ModifyGlobeConfigC2SRequest implements NetworkPacket {

    private final String key;
    private final String value;
    private final Action action;

    public ModifyGlobeConfigC2SRequest(FriendlyByteBuf buf) {
        this(buf.readUtf(), buf.readUtf(), buf.readEnum(Action.class));
    }

    public ModifyGlobeConfigC2SRequest(String key, String value, Action action) {
        this.key = key;
        this.value = value;
        this.action = action;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeUtf(key);
        buf.writeUtf(value);
        buf.writeEnum(action);
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        if (contextSupplier.get().getPlayer() instanceof ServerPlayer player) {
            GlobeConfig config = GlobeConfig.getInstance();
            if (action == Action.REMOVE && !config.getExceptAttributes().containsKey(key)) {
                return;
            }

            Set<String> strings = config.getExceptAttributes().computeIfAbsent(key, k -> new HashSet<>());
            if (action == Action.ADD) {
                strings.add(value);
            } else {
                strings.remove(value);
            }

            GlobeConfig.save();
            player.sendSystemMessage(TranslationUtil.successComponent());
        }
    }

    public enum Action {
        ADD, REMOVE
    }
}
