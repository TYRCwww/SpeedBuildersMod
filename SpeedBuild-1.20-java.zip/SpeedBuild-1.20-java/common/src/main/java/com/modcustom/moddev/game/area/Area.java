package com.modcustom.moddev.game.area;

import com.modcustom.moddev.api.SavableData;
import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.utils.RenderUtil;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Position;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.phys.AABB;

public class Area implements SavableData {

    private final BoundingBox box;

    public Area(BlockPos start, Area area) {
        this(area.box.moved(start.getX() - area.box.minX(), start.getY() - area.box.minY(), start.getZ() - area.box.minZ()));
    }

    public Area(BoundingBox box) {
        this.box = box;
    }

    public Area(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
        this(new BlockPos(minX, minY, minZ), new BlockPos(maxX, maxY, maxZ));
    }

    public Area(BlockPos start, BlockPos end) {
        this(BoundingBox.fromCorners(start, end));
    }

    public BoundingBox getBoundingBox() {
        return box;
    }

    public BlockPos getMinPos() {
        return new BlockPos(box.minX(), box.minY(), box.minZ());
    }

    public BlockPos getMaxPos() {
        return new BlockPos(box.maxX(), box.maxY(), box.maxZ());
    }

    public boolean contains(BlockPos pos) {
        return contains(pos, 0);
    }

    public boolean contains(BlockPos pos, int inflate) {
        if (inflate == 0) {
            return box.isInside(pos);
        } else {
            return box.inflatedBy(inflate).isInside(pos);
        }
    }

    @Override
    public void save(CompoundTag tag) {
        tag.putIntArray("box", new int[]{box.minX(), box.minY(), box.minZ(), box.maxX(), box.maxY(), box.maxZ()});
    }

    public Area copy() {
        return new Area(box.minX(), box.minY(), box.minZ(), box.maxX(), box.maxY(), box.maxZ());
    }

    public double distanceTo(BlockPos pos) {
        return distanceTo(pos.getCenter());
    }

    public double distanceTo(Position pos) {
        double px = pos.x();
        double py = pos.y();
        double pz = pos.z();
        double x1 = box.minX();
        double y1 = box.minY();
        double z1 = box.minZ();
        double x2 = box.maxX();
        double y2 = box.maxY();
        double z2 = box.maxZ();

        double minX = Math.min(x1, x2);
        double maxX = Math.max(x1, x2);
        double minY = Math.min(y1, y2);
        double maxY = Math.max(y1, y2);
        double minZ = Math.min(z1, z2);
        double maxZ = Math.max(z1, z2);

        double dx = 0;
        if (px < minX) {
            dx = minX - px;
        } else if (px > maxX) {
            dx = px - maxX;
        }

        double dy = 0;
        if (py < minY) {
            dy = minY - py;
        } else if (py > maxY) {
            dy = py - maxY;
        }

        double dz = 0;
        if (pz < minZ) {
            dz = minZ - pz;
        } else if (pz > maxZ) {
            dz = pz - maxZ;
        }

        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    public void render(PoseStack stack, int color) {
        RenderUtil.render(stack, color, getBox());
    }

    public AABB getBox() {
        return AABB.of(box);
    }

    public Area combine(Area area) {
        return new Area(new BoundingBox(Math.min(box.minX(), area.box.minX()), Math.min(box.minY(), area.box.minY()), Math.min(box.minZ(), area.box.minZ()), Math.max(box.maxX(), area.box.maxX()), Math.max(box.maxY(), area.box.maxY()), Math.max(box.maxZ(), area.box.maxZ())));
    }

    public boolean intersects(Area area) {
        return box.intersects(area.box);
    }

    public Type getType() {
        return Type.NONE;
    }

    @Override
    public String toString() {
        return "Area(" + box + ")";
    }

    public static Area fromNbt(CompoundTag tag) {
        if (tag.contains("box")) {
            int[] box = tag.getIntArray("box");
            if (box.length >= 6) {
                return new Area(new BlockPos(box[0], box[1], box[2]), new BlockPos(box[3], box[4], box[5]));
            }
        }
        return null;
    }

    public static boolean hasArea(Level level, BlockPos pos) {
        if (level instanceof ServerLevel serverLevel) {
            return GameData.getGameData(serverLevel).getActivityArea(serverLevel, pos) != null;
        } else {
            return !ClientGameManager.getInstance().getActivityAreas(level, pos).isEmpty();
        }
    }

    public enum Type {
        NONE, ACTIVITY, PROTECTED, FUNCTION
    }
}
