package com.modcustom.moddev.events;

import com.modcustom.moddev.SpeedBuild;
import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.client.screen.AreaConfigScreen;
import com.modcustom.moddev.client.screen.FunctionSelectionScreen;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.area.FunctionArea;
import com.modcustom.moddev.game.data.ClientCachedData;
import com.modcustom.moddev.mixin.ClientLevelAccessor;
import com.modcustom.moddev.network.Network;
import com.modcustom.moddev.utils.PlayerUtil;
import com.modcustom.moddev.utils.TranslationUtil;
import com.mojang.logging.LogUtils;
import dev.architectury.event.EventResult;
import dev.architectury.event.events.client.ClientPlayerEvent;
import dev.architectury.event.events.client.ClientRawInputEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.slf4j.Logger;

import java.util.UUID;

@Environment(EnvType.CLIENT)
public class ClientEventHandler {

    private static final Logger LOGGER = LogUtils.getLogger();
    private static final String DISCORD_URL = "https://discord.gg/FvbGPhDSmu";
    public static long firstJumpTime = 0L;
    public static boolean wasJumped = false;
    public static int jumpCount = 0;

    public static void registerClient() {
        ClientRawInputEvent.KEY_PRESSED.register(ClientEventHandler::handleKeyPressed);
        ClientPlayerEvent.CLIENT_PLAYER_JOIN.register(ClientEventHandler::sendWelcomeMessage);
    }

    private static EventResult handleKeyPressed(Minecraft minecraft, int keyCode, int scanCode, int action, int modifiers) {
        Player player = minecraft.player;
        if (player == null) return EventResult.pass();
        if (minecraft.screen == null && minecraft.options.keyJump.matches(keyCode, scanCode) && action == 1) {
            ClientCachedData data = ClientGameManager.getInstance().getCachedData();
            if (data.isExtraJumpEnabled() && !player.getAbilities().flying && !player.isSwimming() && !player.isFallFlying() && jumpCount < data.getExtraJump()) {
                if (!wasJumped) {
                    wasJumped = true;
                    firstJumpTime = System.currentTimeMillis();
                    PlayerUtil.sendTestMessage(player, String.format("第%d次跳跃", jumpCount + 1));
                } else if (jumpCount == 0 && System.currentTimeMillis() - firstJumpTime > 300) {
                    firstJumpTime = System.currentTimeMillis();
                    PlayerUtil.sendTestMessage(player, "跳跃超时重置");
                } else {
                    jumpCount++;
                    PlayerUtil.sendTestMessage(player, String.format("第%d次跳跃", jumpCount + 1));
                    data.getJumpSound().play(player);
                    PlayerUtil.jump(player, data.getExtraJumpPower());
                    Network.requestDoubleJump();
                    if (data.hasJumpingParticles()) {
                        spawnParticles(minecraft, player.getRandom(), ParticleTypes.CLOUD, false, player.getX(), player.getY(), player.getZ(), 0f, 0f, 0f, 0.1f, 5);
                    }
                }
            }
        }
        return EventResult.pass();
    }

    private static <T extends ParticleOptions> void spawnParticles(Minecraft minecraft, RandomSource random, T particle, boolean overrideLimiter, double x, double y, double z, double xDist, double yDist, double zDist, double maxSpeed, int count) {
        for (int i = 0; i < count; ++i) {
            double g = random.nextGaussian() * xDist;
            double h = random.nextGaussian() * yDist;
            double j = random.nextGaussian() * zDist;
            double k = random.nextGaussian() * maxSpeed;
            double l = random.nextGaussian() * maxSpeed;
            double m = random.nextGaussian() * maxSpeed;
            try {
                minecraft.level.addParticle(particle, overrideLimiter, x + g, y + h, z + j, k, l, m);
            } catch (Throwable throwable2) {
                LOGGER.error("Could not spawn particle effect {}", particle);
                return;
            }
        }
    }

    private static void sendWelcomeMessage(Player player) {
        player.sendSystemMessage(TranslationUtil.messageComponent("load").withStyle(ChatFormatting.AQUA));
        player.sendSystemMessage(TranslationUtil.messageComponent("version", SpeedBuild.getVersion()));
        player.sendSystemMessage(TranslationUtil.messageComponent("authors"));
        player.sendSystemMessage(TranslationUtil.messageComponent("help").withStyle(ChatFormatting.GREEN));
        MutableComponent officialGroup = TranslationUtil.messageComponent("official_group").withStyle(ChatFormatting.YELLOW);
        if (!"zh_cn".equals(Minecraft.getInstance().getLanguageManager().getSelected())) {
            officialGroup = officialGroup.withStyle(style -> style.withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, DISCORD_URL)));
        }
        player.sendSystemMessage(officialGroup);
    }

    public static void handleLocalPlayerFall(LivingEntity entity, BlockState state, BlockPos pos, Player player) {
        if (jumpCount > 0 || wasJumped) {
            jumpCount = 0;
            wasJumped = false;
            firstJumpTime = 0;
            PlayerUtil.sendTestMessage(player, String.format("落地重置 方块:%s 坐标:%s 玩家脚下方块:%s", state.getBlock().getName().getString(), pos.toShortString(), entity.blockPosition()));
        }
    }

    public static Entity getSpawnerClient(Level level, UUID uuid) {
        if (level instanceof ClientLevel clientLevel) {
            return ((ClientLevelAccessor) clientLevel).callGetEntities().get(uuid);
        }
        return null;
    }

    public static void openActivityAreaConfigScreen(ActivityArea area) {
        Minecraft.getInstance().setScreen(new AreaConfigScreen(area));
    }

    public static void openFunctionSelectionScreen(FunctionArea area) {
        Minecraft.getInstance().setScreen(new FunctionSelectionScreen(area));
    }

    public static void openFunctionSelectionScreen(FunctionArea area, BlockPos pos) {
        Minecraft.getInstance().setScreen(new FunctionSelectionScreen(area, pos));
    }

    public static void sendCommand(Player player, String command) {
        if (player instanceof LocalPlayer localPlayer) {
            localPlayer.connection.sendCommand(command);
        }
    }
}
