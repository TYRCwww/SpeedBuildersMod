package com.modcustom.moddev.mixin;

import com.modcustom.moddev.events.BlockEventHandler;
import com.modcustom.moddev.game.area.FunctionArea;
import com.modcustom.moddev.game.area.ProtectedArea;
import com.modcustom.moddev.utils.TranslationUtil;
import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(ServerPlayer.class)
public abstract class ServerPlayerMixin extends Player {

    public ServerPlayerMixin(Level level, BlockPos pos, float yRot, GameProfile gameProfile) {
        super(level, pos, yRot, gameProfile);
    }

    @Override
    public boolean blockActionRestricted(Level level, BlockPos blockPos, GameType gameType) {
        ServerPlayer player = (ServerPlayer) (Object) this;
        if (ProtectedArea.isProtected(level, blockPos)) {
            player.sendSystemMessage(TranslationUtil.messageComponent("protected_area.break_block"), true);
            return true;
        } else if (FunctionArea.isLocked(level, blockPos)) {
//            player.sendSystemMessage(TranslationUtil.messageComponent("function_area.break_block"), true);
            return true;
        } else if (gameType == GameType.ADVENTURE) {
            return !BlockEventHandler.allowAdventureBlockAction(level, blockPos);
        }
        return false;
    }
}
