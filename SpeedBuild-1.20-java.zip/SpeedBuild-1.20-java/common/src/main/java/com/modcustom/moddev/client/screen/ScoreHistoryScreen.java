package com.modcustom.moddev.client.screen;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.activity.ActivityRecord;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.data.ClientCachedData;
import com.modcustom.moddev.network.Network;
import com.modcustom.moddev.utils.Timer;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.tooltip.DefaultTooltipPositioner;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.FormattedCharSequence;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.modcustom.moddev.utils.TranslationUtil.messageComponent;
import static com.modcustom.moddev.utils.TranslationUtil.screenComponent;

public class ScoreHistoryScreen extends SyncAreaScreen {

    private static final MutableComponent TITLE = screenComponent("history.button");
    public int infoScale = 80;
    public int infoYOffset;
    private ScoreHistoryList scoreHistoryList;
    private Button saveButton;
    private Button copyButton;

    public ScoreHistoryScreen(ActivityArea area) {
        this(area, null);
    }

    public ScoreHistoryScreen(ActivityArea area, @Nullable Screen parent) {
        super(TITLE, area, parent);
    }

    @Override
    protected void init() {
        super.init();
        scoreHistoryList = new ScoreHistoryList(minecraft);
        addRenderableWidget(scoreHistoryList);
        if (parent != null) {
            addRenderableWidget(Button.builder(screenComponent("back"), button -> {
                if (minecraft != null) {
                    minecraft.setScreen(parent);
                }
            }).bounds(width - 110, 10, 100, 20).build());
        }

        saveButton = Button.builder(screenComponent("interrupt_and_save"), button -> {
            if (ClientGameManager.getInstance().hasActivity(id)) {
                Network.requestInterruptActivity(id);
                if (minecraft != null) {
                    minecraft.setScreen(null);
                }
            }
        }).bounds(10, height - 30, 100, 20).tooltip(Tooltip.create(screenComponent("interrupt_and_save.tooltip"))).build();
        updateSaveButton();
        addRenderableWidget(saveButton);

        copyButton = Button.builder(screenComponent("copy_info"), button -> {
            if (scoreHistoryList == null) return;
            ScoreHistoryList.Entry focused = scoreHistoryList.getFocused();
            if (focused == null) return;

            List<String> strings = focused.infoTexts.stream()
                                                    .map(Component::getString)
                                                    .collect(Collectors.toList());

            focused.record.getPlayers().forEach((name, data) -> strings.add(strings.size() + 1 + ") " + name + ": " + data.toString()));

            String info = String.join("\n", strings);
            if (minecraft != null) {
                minecraft.keyboardHandler.setClipboard(info);
                LocalPlayer player = minecraft.player;
                if (player != null) {
                    player.displayClientMessage(messageComponent("copied"), true);
                }
                minecraft.setScreen(null);
            }
        }).bounds(saveButton.getX() + saveButton.getWidth() + 10, height - 30, 100, 20).build();
        updateCopyButton();
        addRenderableWidget(copyButton);
    }

    protected void updateSaveButton() {
        saveButton.active = ClientGameManager.getInstance().hasActivity(id);
    }

    protected void updateCopyButton() {
        copyButton.active = scoreHistoryList != null && scoreHistoryList.getFocused() != null;
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.render(guiGraphics, mouseX, mouseY, partialTick);

        MutableComponent tip = screenComponent("score_history_scale_tip");
        guiGraphics.drawString(font, tip, width - 2 - font.width(tip), height - font.lineHeight - 2, 0x757575, false);

        if (scoreHistoryList != null) {
            ScoreHistoryList.Entry focused = scoreHistoryList.getFocused();
            if (focused != null) {
                float scale = infoScale / 100f;
                guiGraphics.pose().pushPose();
                guiGraphics.pose().scale(scale, scale, scale);

                ActivityRecord record = focused.getRecord();
                int originalX = scoreHistoryList.getRowRight() + 42;
                int originalY = 37;
                guiGraphics.enableScissor(originalX - 5, originalY - 5, width, height);

                int startX = (int) (originalX / scale);
                int startY = (int) (originalY / scale) - infoYOffset;
                int maxWidth = (int) ((width - 20) / scale);
                int lastY = renderInfoTexts(guiGraphics, focused.infoTexts, startX, startY, maxWidth);

                guiGraphics.disableScissor();
                guiGraphics.pose().popPose();
                renderPlayerNames(guiGraphics, record, mouseX, mouseY, scale, originalX, originalY, lastY, maxWidth);
            }
        }
    }

    @Override
    public void update() {
        rebuildWidgets();
    }

    private int renderInfoTexts(GuiGraphics guiGraphics, List<Component> infoTexts, int x, int y, int maxWidth) {
        for (Component infoText : infoTexts) {
            for (FormattedCharSequence line : font.split(infoText, maxWidth - x)) {
                guiGraphics.drawString(font, line, x, y, 0xFFFFFF);
                y += 16;
            }
        }
        return y;
    }

    private void renderPlayerNames(GuiGraphics guiGraphics, ActivityRecord record, int mouseX, int mouseY, float scale, int originalX, int originalY, int y, int maxWidth) {
        int x = (int) (originalX / scale);
        List<Map.Entry<String, ClientCachedData>> names = List.copyOf(record.getPlayers().entrySet());

        for (int index = 0; index < names.size(); index++) {
            Map.Entry<String, ClientCachedData> entry = names.get(index);
            String name = entry.getKey();
            ClientCachedData data = entry.getValue();
            List<Component> tooltip = buildTooltip(data);

            if (x + font.width(name) > maxWidth) {
                x = originalX;
                y += 16;
            }

            boolean full = isFullNameList(names, index, x, y, maxWidth);
            Component suffix = buildSuffix(names, index, full);
            MutableComponent nameComponent = tooltip.isEmpty() ? Component.literal(name) : Component.literal(name).withStyle(ChatFormatting.RED, ChatFormatting.UNDERLINE);

            guiGraphics.pose().pushPose();
            guiGraphics.enableScissor(originalX - 5, originalY - 5, width, height);
            guiGraphics.pose().scale(scale, scale, scale);
            guiGraphics.drawString(font, nameComponent, x, y, 0xFFFFFF);
            guiGraphics.drawString(font, suffix, x + font.width(name) + (full ? -1 : 1), y, 0xFFFFFF);
            guiGraphics.disableScissor();
            guiGraphics.pose().popPose();

            handleTooltips(guiGraphics, names, tooltip, index, mouseX, mouseY, x, y, name, suffix, full);

            if (full) break;
            x += font.width(name) + 5;
        }
    }

    private boolean isFullNameList(List<Map.Entry<String, ClientCachedData>> names, int index, int x, int y, int maxWidth) {
        return index != names.size() - 1 && x + font.width(names.get(index + 1).getKey()) + 5 > maxWidth && y + 16 + font.lineHeight > height / (infoScale / 100f) - 10;
    }

    private Component buildSuffix(List<Map.Entry<String, ClientCachedData>> names, int index, boolean full) {
        if (full) {
            return Component.literal(" ...(+").append(String.valueOf(names.size() - index - 1)).append(")").withStyle(ChatFormatting.GRAY);
        } else if (index == names.size() - 1) {
            return Component.empty();
        }
        return Component.literal(",");
    }

    private void handleTooltips(GuiGraphics guiGraphics, List<Map.Entry<String, ClientCachedData>> names, List<Component> tooltips, int index, int mouseX, int mouseY, int x, int y, String name, Component suffix, boolean full) {
        float scale = infoScale / 100f;
        int scaledMouseX = (int) (mouseX / scale);
        int scaledMouseY = (int) (mouseY / scale);

        if (full && scaledMouseX >= x + font.width(name) + 4 && scaledMouseX < x + font.width(name) + 5 + font.width(suffix) && scaledMouseY >= y - 1 && scaledMouseY < y + font.lineHeight) {
            guiGraphics.renderTooltip(font, font.split(Component.literal(String.join(", ", names.subList(index + 1, names.size()).stream().map(Map.Entry::getKey).toList())), (int) (width / scale / 2)), DefaultTooltipPositioner.INSTANCE, mouseX, mouseY);
        } else if (!tooltips.isEmpty() && scaledMouseX >= x && scaledMouseX < x + font.width(name) + 2 && scaledMouseY >= y - 1 && scaledMouseY < y + font.lineHeight) {
            guiGraphics.renderTooltip(font, tooltips, Optional.empty(), mouseX, mouseY);
        }
    }

    private List<Component> buildTooltip(ClientCachedData data) {
        List<Component> tooltip = new ArrayList<>();
        ClientCachedData defaultData = new ClientCachedData();

        addTooltipIfDifferent(tooltip, "extra_jump", data.getExtraJump(), defaultData.getExtraJump());
        addTooltipIfDifferent(tooltip, "extra_jump_power", data.getExtraJumpPower(), defaultData.getExtraJumpPower());
        addTooltipIfDifferent(tooltip, "jump_movement_limit", data.isJumpMovementLimit(), defaultData.isJumpMovementLimit());
        addTooltipIfDifferent(tooltip, "timer_error_correction", data.getTimerErrorCorrection(), defaultData.getTimerErrorCorrection());

        if (!tooltip.isEmpty()) tooltip.add(0, screenComponent("special_status"));
        return tooltip;
    }

    private <T> void addTooltipIfDifferent(List<Component> tooltip, String key, T value, T defaultValue) {
        if (!value.equals(defaultValue)) {
            tooltip.add(screenComponent(key).append(": ").append(String.valueOf(value)));
        }
    }

    private void addTooltipIfDifferent(List<Component> tooltip, String key, boolean value, boolean defaultValue) {
        if (value != defaultValue) {
            tooltip.add(screenComponent(key).append(": ").append(screenComponent(value ? "on" : "off")));
        }
    }

    @Override
    public void tick() {
        super.tick();
        updateSaveButton();
        updateCopyButton();
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (mouseX > scoreHistoryList.getScrollbarPosition() + 6) {
            if (hasShiftDown()) {
                if (delta > 0) {
                    infoScale += 5;
                } else if (delta < 0) {
                    infoScale -= 5;
                }

                if (infoScale < 50) {
                    infoScale = 50;
                } else if (infoScale > 150) {
                    infoScale = 150;
                }
            } else {
                infoYOffset += delta > 0 ? 10 : -10;

                if (infoYOffset < 0) {
                    infoYOffset = 0;
                } else {
                    if (infoYOffset > 150) {
                        infoYOffset = 150;
                    }
                }
            }
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    class ScoreHistoryList extends ObjectSelectionList<ScoreHistoryList.Entry> {

        public ScoreHistoryList(Minecraft minecraft) {
            super(minecraft, ScoreHistoryScreen.this.width, ScoreHistoryScreen.this.height, 32, ScoreHistoryScreen.this.height - 40, 18);
            setRenderBackground(false);
            setRenderTopAndBottom(false);
            setLeftPos(-width / 4 + 24);
            area.getLimitedHistory().forEach(record -> addEntry(new Entry(record)));
        }

        @Override
        public int getRowWidth() {
            return width / 2;
        }

        @Override
        public int getScrollbarPosition() {
            return getRowRight() + 24;
        }

        @Override
        public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
            if (mouseX > getScrollbarPosition() + 6) return false;
            return super.mouseScrolled(mouseX, mouseY, delta);
        }

        @Override
        public void renderSelection(GuiGraphics guiGraphics, int top, int width, int height, int outerColor, int innerColor) {
            int i = this.x0 + (this.width - width) / 2;
            int j = this.x0 + (this.width + width) / 2;
            guiGraphics.fill(i, top - 2, j, top + height + 2, outerColor);
            guiGraphics.fill(i + 1, top - 1, j - 1, top + height + 1, innerColor);
        }

        @Override
        public int getRowLeft() {
            return 24;
        }

        class Entry extends ObjectSelectionList.Entry<Entry> {

            private final ActivityRecord record;
            private final String displayText;
            private final List<Component> infoTexts;

            public Entry(ActivityRecord record) {
                this.record = record;
                this.displayText = createDisplayText(record);
                this.infoTexts = createInfoTexts(record);
            }

            private String createDisplayText(ActivityRecord record) {
                return ActivityRecord.formatTime(record.getFinishTime()) + " >>> " + Timer.formatTime(record.getRuntime());
            }

            private List<Component> createInfoTexts(ActivityRecord record) {
                boolean interrupted = record.isInterrupted();
                String initiator = record.getInitiator();

                List<Component> infoTexts = new ArrayList<>();
                infoTexts.add(screenComponent("initiator", initiator != null ? initiator : I18n.get("area.moddev.owner.unknown")));
                if (interrupted) {
                    infoTexts.add(screenComponent("unrestored"));
                    infoTexts.add(screenComponent("unrestored_blocks", String.valueOf(record.getUnrestoredBlockProgress())));
                    infoTexts.add(screenComponent("unrestored_entities", String.valueOf(record.getUnrestoredEntityProgress())));
                }
                infoTexts.add(screenComponent("startTime").append(" ").append(Component.literal(ActivityRecord.formatTime(record.getStartTime()))));
                infoTexts.add(screenComponent("finishTime").append(" ").append(Component.literal(ActivityRecord.formatTime(record.getFinishTime()))));
                infoTexts.add(screenComponent("runtime", Timer.formatTime(record.getRuntime())));
                if (interrupted) addLastPlacingTimes(infoTexts, record);
                infoTexts.add(screenComponent("players"));
                return List.copyOf(infoTexts);
            }

            private void addLastPlacingTimes(List<Component> infoTexts, ActivityRecord record) {
                long startTime = record.getStartTime();

                Long lastPlacingBlockTime = record.getLastPlacingBlockTime();
                if (lastPlacingBlockTime != null) {
                    lastPlacingBlockTime -= startTime;
                    infoTexts.add(screenComponent("last_placing_block_time").append(" ").append(Component.literal(Timer.formatTime(lastPlacingBlockTime))));
                }

                Long lastPlacingEntityTime = record.getLastPlacingEntityTime();
                if (lastPlacingEntityTime != null) {
                    lastPlacingEntityTime -= startTime;
                    infoTexts.add(screenComponent("last_placing_entity_time").append(" ").append(Component.literal(Timer.formatTime(lastPlacingEntityTime))));
                }
            }

            @Override
            public void render(GuiGraphics guiGraphics, int index, int top, int left, int width, int height, int mouseX, int mouseY, boolean hovering, float partialTick) {
                guiGraphics.drawCenteredString(font, displayText, left + width / 2, top + (height - font.lineHeight) / 2 + 1, record.isRestored() ? 0x00FF00 : 0xFF0000);
            }

            @Override
            public boolean mouseClicked(double mouseX, double mouseY, int button) {
                if (button == 0) {
                    infoYOffset = 0;
                    return true;
                }
                return super.mouseClicked(mouseX, mouseY, button);
            }

            @Override
            public Component getNarration() {
                return Component.literal(displayText);
            }

            public ActivityRecord getRecord() {
                return record;
            }
        }
    }
}
