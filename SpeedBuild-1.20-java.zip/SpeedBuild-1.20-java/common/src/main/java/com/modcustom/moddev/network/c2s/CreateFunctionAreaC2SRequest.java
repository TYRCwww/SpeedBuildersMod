package com.modcustom.moddev.network.c2s;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.game.area.FunctionArea;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.utils.TranslationUtil;
import dev.architectury.networking.NetworkManager;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;

import java.util.function.Supplier;

public class CreateFunctionAreaC2SRequest implements NetworkPacket {

    private final BlockPos minPos;
    private final BlockPos maxPos;

    public CreateFunctionAreaC2SRequest(FriendlyByteBuf buf) {
        this(buf.readBlockPos(), buf.readBlockPos());
    }

    public CreateFunctionAreaC2SRequest(BlockPos minPos, BlockPos maxPos) {
        this.minPos = minPos;
        this.maxPos = maxPos;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeBlockPos(minPos);
        buf.writeBlockPos(maxPos);
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        if (contextSupplier.get().getPlayer() instanceof ServerPlayer player) {
            int id = GameData.getGameData(player).getNextFunctionAreaId();
            boolean isAreaAdded = FunctionArea.add(player.serverLevel(), new FunctionArea(id, minPos, maxPos));

            String messageKey = isAreaAdded ? "create_function_area" : "function_area_intersected";
            player.sendSystemMessage(TranslationUtil.messageComponent(messageKey));
        }
    }
}
