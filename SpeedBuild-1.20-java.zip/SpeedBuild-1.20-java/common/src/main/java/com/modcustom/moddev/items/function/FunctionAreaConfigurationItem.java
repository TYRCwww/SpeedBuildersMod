package com.modcustom.moddev.items.function;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.events.ClientEventHandler;
import com.modcustom.moddev.game.area.Area;
import com.modcustom.moddev.game.area.FunctionArea;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.items.AreaVisibleItem;
import com.modcustom.moddev.network.Network;
import com.modcustom.moddev.utils.PlayerUtil;
import com.modcustom.moddev.utils.TranslationUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public class FunctionAreaConfigurationItem extends AreaVisibleItem {

    public FunctionAreaConfigurationItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext useOnContext) {
        Level level = useOnContext.getLevel();
        Direction face = useOnContext.getClickedFace();
        BlockPos pos = useOnContext.getClickedPos();
        Player player = useOnContext.getPlayer();
        if (level instanceof ServerLevel serverLevel) {
            if (player instanceof ServerPlayer serverPlayer && player.isDescending()) {
                boolean removed = FunctionArea.remove(serverLevel, pos) || FunctionArea.remove(serverLevel, pos.relative(face));
                if (removed) {
                    serverPlayer.sendSystemMessage(TranslationUtil.messageComponent("function_area.delete"), true);
                }
                return InteractionResult.sidedSuccess(level.isClientSide());
            }
        } else if (player != null && !player.isDescending()) {
            ClientGameManager manager = ClientGameManager.getInstance();
            FunctionArea area = manager.getFunctionArea(level, pos, face);
            if (area != null) {
                ClientEventHandler.openFunctionSelectionScreen(area, pos);
                return InteractionResult.sidedSuccess(level.isClientSide());
            }
        }
        return super.useOn(useOnContext);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide() && !player.isDescending()) {
            return handleAirRightClick(player, hand);
        } else if (level instanceof ServerLevel serverLevel && player.isDescending()) {
            FunctionArea area = PlayerUtil.findFirstFunctionArea(player, 5);
            if (area != null) {
                MinecraftServer server = serverLevel.getServer();
                boolean removed = GameData.getGameData(server).getFunctionAreas(level).remove(area);
                if (removed && player instanceof ServerPlayer serverPlayer) {
                    Network.updateFunctionAreas(server);
                    serverPlayer.sendSystemMessage(TranslationUtil.messageComponent("function_area.delete"), true);
                }
            }
        }
        return InteractionResultHolder.pass(player.getItemInHand(hand));
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    private InteractionResultHolder<ItemStack> handleAirRightClick(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        InteractionResultHolder<ItemStack> pass = InteractionResultHolder.pass(stack);
        if (hand != InteractionHand.MAIN_HAND) return pass;
        FunctionArea area = PlayerUtil.findFirstFunctionArea(player, 5);
        if (area != null) {
            ClientEventHandler.openFunctionSelectionScreen(area);
            return InteractionResultHolder.success(stack);
        }
        return pass;
    }

    @Override
    public boolean isVisible(Area.Type type) {
        return type == Area.Type.FUNCTION;
    }
}
