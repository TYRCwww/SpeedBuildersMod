package com.modcustom.moddev.network.s2c;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.area.ProtectedArea;
import dev.architectury.networking.NetworkManager;
import dev.architectury.utils.Env;
import net.minecraft.network.FriendlyByteBuf;

import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public class UpdateProtectedAreasS2CPacket implements NetworkPacket {

    private final Map<String, List<ProtectedArea>> areas;
    private final boolean replace;

    public UpdateProtectedAreasS2CPacket(FriendlyByteBuf buf) {
        this(buf.readMap(FriendlyByteBuf::readUtf, byteBuf -> byteBuf.readList(buf1 -> ProtectedArea.fromNbt(buf1.readAnySizeNbt()))), buf.readBoolean());
    }

    public UpdateProtectedAreasS2CPacket(Map<String, List<ProtectedArea>> areas, boolean replace) {
        this.areas = areas;
        this.replace = replace;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeMap(areas, FriendlyByteBuf::writeUtf, (byteBuf, list) -> byteBuf.writeCollection(list, (byteBuf1, area) -> byteBuf1.writeNbt(area.toNbt())));
        buf.writeBoolean(replace);
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        NetworkManager.PacketContext context = contextSupplier.get();
        if (context.getEnvironment() == Env.CLIENT) {
            ClientGameManager manager = ClientGameManager.getInstance();
            if (replace) {
                manager.setProtectedAreas(areas);
            } else {
                manager.addProtectedAreas(areas);
            }
        }
    }
}
