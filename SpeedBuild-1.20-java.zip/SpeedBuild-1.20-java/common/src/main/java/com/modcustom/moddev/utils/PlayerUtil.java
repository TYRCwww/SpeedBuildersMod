package com.modcustom.moddev.utils;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.AreaFinder;
import com.modcustom.moddev.game.SoundSetting;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.area.FunctionArea;
import com.modcustom.moddev.game.area.ProtectedArea;
import com.modcustom.moddev.game.data.ClientCachedData;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.game.data.PlayerData;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Position;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Stream;

public class PlayerUtil {

    public static int getExtraJump(ServerPlayer player) {
        return ClientCachedData.get(player).getExtraJump();
    }

    public static void setExtraJump(ServerPlayer player, int value) {
        ClientCachedData.get(player).setExtraJump(value);
    }

    public static int getJumpCount(ServerPlayer player) {
        return PlayerData.get(player).getJumpCount();
    }

    public static void setJumpCount(ServerPlayer player, int value) {
        PlayerData.get(player).setJumpCount(value);
    }

    public static double getExtraJumpPower(ServerPlayer player) {
        return ClientCachedData.get(player).getExtraJumpPower();
    }

    public static void setExtraJumpPower(ServerPlayer player, double value) {
        ClientCachedData.get(player).setExtraJumpPower(value);
    }

    public static SoundSetting getJumpSound(ServerPlayer player) {
        return ClientCachedData.get(player).getJumpSound();
    }

    public static void setJumpSound(ServerPlayer player, SoundSetting value) {
        ClientCachedData.get(player).getJumpSound().copyFrom(value);
    }

    public static boolean isExtraJumpEnabled(ServerPlayer player) {
        return ClientCachedData.get(player).isExtraJumpEnabled();
    }

    public static void setExtraJumpEnabled(ServerPlayer player, boolean value) {
        ClientCachedData.get(player).setExtraJumpEnabled(value);
    }

    public static void setTestMode(ServerPlayer player, boolean value) {
        ClientCachedData.get(player).setTestMode(value);
    }

    public static AreaFinder getAreaFinder(ServerPlayer player) {
        return ClientCachedData.get(player).getAreaFinder();
    }

    public static void setAreaFinder(ServerPlayer player, AreaFinder value) {
        ClientCachedData.get(player).setAreaFinder(value);
    }

    public static boolean isOverlappingProtectedAreas(ServerPlayer player) {
        return ClientCachedData.get(player).isOverlappingProtectedAreas();
    }

    public static void setOverlappingProtectedAreas(ServerPlayer player, boolean value) {
        ClientCachedData.get(player).setOverlappingProtectedAreas(value);
    }

    public static boolean isJumpMovementLimit(ServerPlayer player) {
        return ClientCachedData.get(player).isJumpMovementLimit();
    }

    public static void setJumpMovementLimit(ServerPlayer player, boolean value) {
        ClientCachedData.get(player).setJumpMovementLimit(value);
    }

    public static boolean hasJumpingParticles(ServerPlayer player) {
        return ClientCachedData.get(player).hasJumpingParticles();
    }

    public static void setJumpingParticles(ServerPlayer player, boolean value) {
        ClientCachedData.get(player).setJumpingParticles(value);
    }

    @Nullable
    public static ActivityArea findFirstActivityArea(Player player, int distance) {
        Level level = player.level();
        Function<HitResult, ActivityArea> getter = level instanceof ServerLevel serverLevel ? hitResult -> {
            Position position = hitResult.getLocation();
            return GameData.getGameData(serverLevel).getActivityArea(level, BlockPos.containing(position));
        } : hitResult -> {
            Position position = hitResult.getLocation();
            List<ActivityArea> list = ClientGameManager.getInstance().getActivityAreas(level, BlockPos.containing(position));
            return list.isEmpty() ? null : list.get(0);
        };

        return findFirst(player, distance, getter);
    }

    @Nullable
    private static <T> T findFirst(Player player, int distance, Function<HitResult, T> getter) {
        return Stream.iterate(0.0, i -> i + 1).limit(distance + 1).map(i -> player.pick(i, 1f, false)).map(getter).filter(Objects::nonNull).findFirst().orElse(null);
    }

    @Nullable
    public static ProtectedArea findFirstProtectedArea(ServerPlayer player, int distance) {
        Level level = player.level();
        Function<HitResult, ProtectedArea> getter = hitResult -> GameData.getGameData(player).getProtectedAreas(level).stream().filter(area -> {
            Position position = hitResult.getLocation();
            return area.contains(BlockPos.containing(position));
        }).findFirst().orElse(null);

        return findFirst(player, distance, getter);
    }

    public static FunctionArea findFirstFunctionArea(Player player, int distance) {
        Level level = player.level();
        Function<HitResult, FunctionArea> getter = level instanceof ServerLevel serverLevel ? hitResult -> {
            Position position = hitResult.getLocation();
            return GameData.getGameData(serverLevel).getFunctionArea(level, BlockPos.containing(position));
        } : hitResult -> {
            Position position = hitResult.getLocation();
            return ClientGameManager.getInstance().getFunctionArea(level, BlockPos.containing(position));
        };

        return findFirst(player, distance, getter);
    }

    @Nullable
    public static GameType getGameMode(Player player) {
        if (player instanceof ServerPlayer serverPlayer) {
            return serverPlayer.gameMode.getGameModeForPlayer();
        } else {
            ClientPacketListener connection = Minecraft.getInstance().getConnection();
            if (connection == null) return null;
            PlayerInfo info = connection.getPlayerInfo(player.getUUID());
            if (info == null) return null;
            return info.getGameMode();
        }
    }

    public static void jump(Player player, double power) {
        Vec3 vec3 = player.getDeltaMovement();
        boolean movementLimit;
        if (player instanceof ServerPlayer serverPlayer) {
            movementLimit = ClientCachedData.get(serverPlayer).isJumpMovementLimit();
        } else {
            movementLimit = ClientGameManager.getInstance().getCachedData().isJumpMovementLimit();
        }
        player.setDeltaMovement(movementLimit ? 0 : vec3.x, power, movementLimit ? 0 : vec3.z);
        if (player.isSprinting() && !movementLimit) {
            float f = player.getYRot() * (float) (Math.PI / 180);
            player.setDeltaMovement(player.getDeltaMovement().add((-Mth.sin(f) * 0.2f), 0.0, (Mth.cos(f) * 0.2f)));
        }
        player.hasImpulse = true;
        player.awardStat(Stats.JUMP);
        if (player.isSprinting()) {
            player.causeFoodExhaustion(0.2f);
        } else {
            player.causeFoodExhaustion(0.05f);
        }
        sendTestMessage(player, "额外跳跃");
    }

    public static void sendTestMessage(Player player, String message) {
        String time = new SimpleDateFormat("ss.SSS").format(new Date());
        if (player instanceof ServerPlayer serverPlayer && isTestMode(serverPlayer)) {
            player.sendSystemMessage(Component.literal(time + " 服务端: " + message).withStyle(ChatFormatting.RED));
        } else if (player.level().isClientSide && ClientGameManager.getInstance().getCachedData().isTestMode()) {
            player.sendSystemMessage(Component.literal(time + " 客户端: " + message).withStyle(ChatFormatting.AQUA));
        }
    }

    public static boolean isTestMode(ServerPlayer player) {
        return ClientCachedData.get(player).isTestMode();
    }
}
