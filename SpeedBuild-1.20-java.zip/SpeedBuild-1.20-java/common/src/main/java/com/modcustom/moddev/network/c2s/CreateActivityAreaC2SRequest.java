package com.modcustom.moddev.network.c2s;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.area.Area;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.network.Network;
import com.modcustom.moddev.utils.TranslationUtil;
import dev.architectury.networking.NetworkManager;
import net.minecraft.core.Vec3i;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;

import java.util.Objects;
import java.util.function.Supplier;

public class CreateActivityAreaC2SRequest implements NetworkPacket {

    private final Area constructionArea;
    private final Area targetArea;

    public CreateActivityAreaC2SRequest(FriendlyByteBuf buf) {
        this(Area.fromNbt(Objects.requireNonNull(buf.readAnySizeNbt())), Area.fromNbt(Objects.requireNonNull(buf.readAnySizeNbt())));
    }

    public CreateActivityAreaC2SRequest(Area constructionArea, Area targetArea) {
        this.constructionArea = constructionArea;
        this.targetArea = targetArea;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeNbt(constructionArea.toNbt());
        buf.writeNbt(targetArea.toNbt());
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        if (contextSupplier.get().getPlayer() instanceof ServerPlayer player) {
            GameData gameData = GameData.getGameData(player);
            ActivityArea area = ActivityArea.create(gameData.getNextActivityAreaId(), player.getUUID(), player.level().dimension().location().toString(), constructionArea, targetArea, null);

            if (area != null) {
                if (!gameData.canCreateActivityArea(player)) {
                    player.sendSystemMessage(TranslationUtil.messageComponent("create_area.quantity_limit_exceeded"), true);
                    return;
                }

                Vec3i sizeLimit = gameData.getSizeLimit(player);
                if (sizeLimit.getX() < area.getBoundingBox().getXSpan() || sizeLimit.getY() < area.getBoundingBox().getYSpan() || sizeLimit.getZ() < area.getBoundingBox().getZSpan()) {
                    player.sendSystemMessage(TranslationUtil.messageComponent("create_area.size_limit_exceeded", sizeLimit.getX() + "×" + sizeLimit.getY() + "×" + sizeLimit.getZ()), true);
                    return;
                }

                area.updateName(player.getDisplayName().getString());
                player.sendSystemMessage(TranslationUtil.messageComponent("create_area"));
                gameData.addActivityArea(area);
                Network.updateActivityAreasForAll(player.server);
            } else {
                player.sendSystemMessage(TranslationUtil.messageComponent("create_area.failed"), true);
            }
        }
    }
}
