package com.modcustom.moddev.mixin;

import com.modcustom.moddev.api.SpawnerProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorStandItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.function.Consumer;

@Mixin(ArmorStandItem.class)
public class ArmorStandItemMixin {

    @Inject(method = "useOn", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;addFreshEntityWithPassengers(Lnet/minecraft/world/entity/Entity;)V"), locals = LocalCapture.CAPTURE_FAILSOFT)
    private void speed_build$useOn(UseOnContext context, CallbackInfoReturnable<InteractionResult> cir, Direction direction, Level level, BlockPlaceContext blockPlaceContext, BlockPos blockPos, ItemStack itemStack, Vec3 vec3, AABB aABB, ServerLevel serverLevel, Consumer consumer, ArmorStand armorStand, float f) {
        Player player = context.getPlayer();
        if (player != null && armorStand instanceof SpawnerProvider provider) {
            provider.setSpawner(player.getUUID());
        }
    }
}
