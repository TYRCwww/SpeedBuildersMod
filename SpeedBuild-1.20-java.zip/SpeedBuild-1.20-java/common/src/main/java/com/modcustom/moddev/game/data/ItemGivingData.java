package com.modcustom.moddev.game.data;

import com.modcustom.moddev.api.SerializableData;
import com.modcustom.moddev.game.activity.Activity;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.mixin.ItemFrameInvoker;
import com.modcustom.moddev.utils.ItemStackLinkedMap;
import com.modcustom.moddev.utils.TranslationUtil;
import com.modcustom.moddev.utils.TraversalOrder;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.DataResult;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.GlobalPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemStackLinkedSet;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.piston.PistonHeadBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.material.FluidState;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.*;

public class ItemGivingData implements SerializableData<ItemGivingData> {

    private static final Logger LOGGER = LogUtils.getLogger();
    private final Map<ItemStack, Integer> items = ItemStackLinkedMap.createTypeAndTagMap();
    private final Map<GlobalPos, Integer> positions = new LinkedHashMap<>();
    private final TraversalOrder scanOrder = TraversalOrder.builder().build();
    private Mode mode = Mode.NONE;
    private TriggerCondition condition = TriggerCondition.START;
    private boolean clearInventory = false;
    private boolean clearHotbar = false;

    public ItemGivingData() {

    }

    public ItemGivingData(Mode mode, TriggerCondition condition, boolean clearInventory, boolean clearHotbar) {
        this.mode = mode;
        this.condition = condition;
        this.clearInventory = clearInventory;
        this.clearHotbar = clearHotbar;
    }

    public Mode getMode() {
        return mode;
    }

    public void setMode(Mode mode) {
        this.mode = mode;
    }

    public TriggerCondition getCondition() {
        return condition;
    }

    public void setCondition(TriggerCondition condition) {
        this.condition = condition;
    }

    public boolean isClearInventory() {
        return clearInventory;
    }

    public void setClearInventory(boolean clearInventory) {
        this.clearInventory = clearInventory;
    }

    public boolean isClearHotbar() {
        return clearHotbar;
    }

    public void setClearHotbar(boolean clearHotbar) {
        this.clearHotbar = clearHotbar;
    }

    public TraversalOrder getScanOrder() {
        return scanOrder;
    }

    public void setScanOrder(TraversalOrder order) {
        scanOrder.copyFrom(order);
    }

    public void addItem(ItemStack stack) {
        addItem(stack, 1);
    }

    public void addItem(ItemStack stack, int count) {
        ItemStack copy = stack.copyWithCount(1);
        items.put(copy, items.getOrDefault(copy, 0) + count);
        if (items.getOrDefault(copy, 0) <= 0) {
            items.remove(copy);
        }
    }

    public void removeItem(ItemStack stack) {
        removeItem(stack, null);
    }

    public void removeItem(ItemStack stack, @Nullable Integer count) {
        if (count == null) {
            items.remove(stack);
            return;
        }
        ItemStack copy = stack.copyWithCount(1);
        if (items.containsKey(copy)) {
            items.put(copy, items.get(copy) - count);
        }
        if (items.getOrDefault(copy, 0) <= 0) {
            items.remove(copy);
        }
    }

    public Map<ItemStack, Integer> getItems() {
        return new LinkedHashMap<>(items);
    }

    public void addPosition(GlobalPos pos, int count) {
        positions.put(pos, positions.getOrDefault(pos, 0) + count);
        if (positions.getOrDefault(pos, 0) <= 0) {
            positions.remove(pos);
        }
    }

    public void removePosition(GlobalPos pos) {
        removePosition(pos, null);
    }

    public void removePosition(GlobalPos pos, @Nullable Integer count) {
        if (count == null) {
            positions.remove(pos);
            return;
        }
        if (positions.containsKey(pos)) {
            positions.put(pos, positions.get(pos) - count);
        }
        if (positions.getOrDefault(pos, 0) <= 0) {
            positions.remove(pos);
        }
    }

    public Map<GlobalPos, Integer> getPositions() {
        return new LinkedHashMap<>(positions);
    }

    public void removeAll() {
        items.clear();
        positions.clear();
    }

    public boolean moveItem(int index, int offset) {
        int size = items.size();
        if (index < 0 || index >= size || index + offset < 0 || index + offset >= size) {
            return false;
        }
        List<Map.Entry<ItemStack, Integer>> entries = new ArrayList<>(items.entrySet());
        Map.Entry<ItemStack, Integer> entryToMove = entries.remove(index);
        entries.add(index + offset, entryToMove);
        items.clear();
        for (Map.Entry<ItemStack, Integer> entry : entries) {
            items.put(entry.getKey(), entry.getValue());
        }
        return true;
    }

    public boolean movePosition(int index, int offset) {
        int size = positions.size();
        if (index < 0 || index >= size || index + offset < 0 || index + offset >= size) {
            return false;
        }
        List<Map.Entry<GlobalPos, Integer>> entries = new ArrayList<>(positions.entrySet());
        Map.Entry<GlobalPos, Integer> entryToMove = entries.remove(index);
        entries.add(index + offset, entryToMove);
        positions.clear();
        for (Map.Entry<GlobalPos, Integer> entry : entries) {
            positions.put(entry.getKey(), entry.getValue());
        }
        return true;
    }

    public boolean modifyItemCount(ItemStack item, int count) {
        if (!items.containsKey(item)) {
            return false;
        }
        if (count <= 0) {
            items.remove(item);
        } else {
            items.put(item, count);
        }
        return true;
    }

    public boolean modifyPositionCount(GlobalPos pos, int count) {
        if (!positions.containsKey(pos)) {
            return false;
        }
        if (count <= 0) {
            positions.remove(pos);
        } else {
            positions.put(pos, count);
        }
        return true;
    }

    @Override
    public void save(CompoundTag tag) {
        tag.putInt("mode", mode.ordinal());
        tag.putInt("condition", condition.ordinal());
        tag.putBoolean("clearInventory", clearInventory);
        tag.putBoolean("clearHotbar", clearHotbar);
        tag.put("scanOrder", scanOrder.toNbt());

        ListTag itemList = new ListTag();
        for (Map.Entry<ItemStack, Integer> entry : items.entrySet()) {
            CompoundTag itemTag = new CompoundTag();
            itemTag.put("item", entry.getKey().save(new CompoundTag()));
            itemTag.putInt("count", entry.getValue());
            itemList.add(itemTag);
        }
        tag.put("items", itemList);

        ListTag positionList = new ListTag();
        for (Map.Entry<GlobalPos, Integer> entry : positions.entrySet()) {
            CompoundTag positionTag = new CompoundTag();
            GlobalPos.CODEC.encodeStart(NbtOps.INSTANCE, entry.getKey()).resultOrPartial(LOGGER::error).ifPresent(it -> {
                positionTag.put("location", it);
                positionTag.putInt("count", entry.getValue());
            });
            positionList.add(positionTag);
        }
        tag.put("positions", positionList);
    }

    @Override
    public void load(CompoundTag tag) {
        if (tag.contains("mode")) {
            int mode = tag.getInt("mode");
            if (mode >= 0 && mode < Mode.values().length) {
                this.mode = Mode.values()[mode];
            }
        }
        if (tag.contains("condition")) {
            int condition = tag.getInt("condition");
            if (condition >= 0 && condition < TriggerCondition.values().length) {
                this.condition = TriggerCondition.values()[condition];
            }
        }
        if (tag.contains("clearInventory")) {
            this.clearInventory = tag.getBoolean("clearInventory");
        }
        if (tag.contains("clearHotbar")) {
            this.clearHotbar = tag.getBoolean("clearHotbar");
        }
        if (tag.contains("scanOrder")) {
            TraversalOrder scanOrder = TraversalOrder.fromNbt(tag.getCompound("scanOrder"));
            this.scanOrder.copyFrom(scanOrder);
        }
        if (tag.contains("items")) {
            ListTag itemList = tag.getList("items", Tag.TAG_COMPOUND);
            for (Tag item : itemList) {
                CompoundTag itemTag = (CompoundTag) item;
                ItemStack stack = ItemStack.of(itemTag.getCompound("item"));
                this.items.put(stack, itemTag.getInt("count"));
            }
        }
        if (tag.contains("positions")) {
            ListTag itemList = tag.getList("positions", Tag.TAG_COMPOUND);
            for (Tag item : itemList) {
                CompoundTag itemTag = (CompoundTag) item;
                DataResult<GlobalPos> result = GlobalPos.CODEC.parse(NbtOps.INSTANCE, itemTag.get("location"));
                result.resultOrPartial(LOGGER::error).ifPresent(pos -> this.positions.put(pos, itemTag.getInt("count")));
            }
        }
    }

    @Override
    public void copyFrom(ItemGivingData data) {
        this.mode = data.mode;
        this.condition = data.condition;
        this.clearInventory = data.clearInventory;
        this.clearHotbar = data.clearHotbar;
        this.scanOrder.copyFrom(data.scanOrder);
        this.items.clear();
        this.items.putAll(data.items);
        this.positions.clear();
        this.positions.putAll(data.positions);
    }

    public void run(Activity activity) {
        if (clearInventory || clearHotbar) {
            for (Player player : activity.getPlayers()) {
                clearInventory(player);
            }
        }
        mode.run(activity);
    }

    public void clearInventory(Player player) {
        List<ItemStack> playerItems = player.getInventory().items;
        if (clearInventory) {
            for (int index = 0; index < playerItems.size(); index++) {
                if (!clearHotbar && Inventory.isHotbarSlot(index)) {
                    continue;
                }
                playerItems.set(index, ItemStack.EMPTY);
            }
        } else if (clearHotbar) {
            for (int i = 0; i < playerItems.size(); i++) {
                if (!Inventory.isHotbarSlot(i)) continue;
                playerItems.set(i, ItemStack.EMPTY);
            }
        }
    }

    public void run(ServerPlayer player, ActivityArea area) {
        Set<ServerPlayer> players = new HashSet<>(player.serverLevel().getEntitiesOfClass(ServerPlayer.class, area.getBox()));
        players.add(player);
        if (clearInventory || clearHotbar) {
            players.forEach(this::clearInventory);
        }
        mode.run(player.serverLevel(), area, players);
    }

    @Override
    public String toString() {
        return String.format(
                "ItemGivingData(mode=%s, " +
                "condition=%s, " +
                "clearInventory=%s, " +
                "clearHotbar=%s, " +
                "scanOrder=%s, " +
                "items=%s, " +
                "positions=%s)",
                mode,
                condition,
                clearInventory,
                clearHotbar,
                scanOrder,
                items,
                positions
        );
    }

    public static ItemGivingData fromNbt(CompoundTag tag) {
        return new ItemGivingData().readNbt(tag);
    }

    public enum TriggerCondition {
        START, CLEAR;

        public final MutableComponent component = TranslationUtil.screenComponent("item_giving.trigger_condition." + name().toLowerCase());
    }

    public enum Mode {
        CUSTOM {
            @Override
            public void run(ServerLevel level, ActivityArea area, Collection<ServerPlayer> players) {
                for (ServerPlayer player : players) {
                    ItemGivingData data = area.getConfig().getItemGivingData();
                    for (Map.Entry<ItemStack, Integer> entry : data.getItems().entrySet()) {
                        Integer count = entry.getValue();
                        ItemStack stack = entry.getKey().copyWithCount(count);
                        if (!stack.isEmpty()) {
                            giveItem(player, stack);
                        }
                    }
                    for (Map.Entry<GlobalPos, Integer> entry : data.getPositions().entrySet()) {
                        GlobalPos globalPos = entry.getKey();
                        ServerLevel level1 = level.getServer().getLevel(globalPos.dimension());
                        if (level1 != null) {
                            BlockPos pos = globalPos.pos();
                            BlockState state = level1.getBlockState(pos);
                            ItemStack stack = state.getBlock().getCloneItemStack(level1, pos, state);
                            if (!stack.isEmpty()) {
                                giveItem(player, stack.copyWithCount(entry.getValue()));
                            }
                            if (level1.getBlockEntity(pos) instanceof Container container) {
                                for (int i = 0; i < container.getContainerSize(); i++) {
                                    ItemStack itemStack = container.getItem(i);
                                    if (!itemStack.isEmpty()) {
                                        giveItem(player, itemStack);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }, SCANNING {
            @Override
            public void run(ServerLevel level, ActivityArea area, Collection<ServerPlayer> players) {
                BoundingBox box = area.getTarget().getBoundingBox();
                Set<ItemStack> stacks = ItemStackLinkedSet.createTypeAndTagSet();
                Set<BlockPos> ignorePositions = new HashSet<>();

                ItemGivingData data = area.getConfig().getItemGivingData();
                for (BlockPos pos : data.getScanOrder().toList(box)) {
                    if (ignorePositions.contains(pos)) continue;
                    BlockState state = level.getBlockState(pos);
                    if (state.isAir()) continue;

                    if (state.hasProperty(BlockStateProperties.DOUBLE_BLOCK_HALF)) {
                        ignorePositions.add(state.getValue(BlockStateProperties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.UPPER ? pos.below() : pos.above());
                    }

                    if (state.hasProperty(BlockStateProperties.EXTENDED) && state.hasProperty(BlockStateProperties.FACING)) {
                        if (state.getValue(BlockStateProperties.EXTENDED)) {
                            ignorePositions.add(pos.relative(state.getValue(BlockStateProperties.FACING)));
                        }
                    }

                    Block block = state.getBlock();
                    if (block instanceof BedBlock) {
                        Direction direction = BedBlock.getBedOrientation(level, pos);
                        if (direction != null) {
                            ignorePositions.add(pos.relative(state.getValue(BlockStateProperties.BED_PART) == BedPart.HEAD ? direction.getOpposite() : direction));
                        }
                    }

                    if (block instanceof PistonHeadBlock && state.hasProperty(BlockStateProperties.FACING)) {
                        ignorePositions.add(pos.relative(state.getValue(BlockStateProperties.FACING).getOpposite()));
                    }

                    FluidState fluidState = state.getFluidState();
                    if (!fluidState.isEmpty() && fluidState.isSource()) {
                        addItemStack(stacks, new ItemStack(fluidState.getType().getBucket()));
                    }

                    ItemStack stack = block.getCloneItemStack(level, pos, state);
                    if (!stack.isEmpty()) {
                        addItemStack(stacks, stack);
                    }

                    if (level.getBlockEntity(pos) instanceof Container container) {
                        for (int i = 0; i < container.getContainerSize(); i++) {
                            ItemStack itemStack = container.getItem(i);
                            if (!itemStack.isEmpty()) {
                                addItemStack(stacks, itemStack.copy());
                            }
                        }
                    }
                }

                area.getTargetAreaEntities(level).forEach(entity -> {
                    ItemStack pickResult = entity.getPickResult();
                    if (pickResult != null) {
                        addItemStack(stacks, pickResult.copy());
                    }

                    if (entity instanceof ItemFrame itemFrame) {
                        ItemStack item = itemFrame.getItem();
                        if (!item.isEmpty()) {
                            addItemStack(stacks, ((ItemFrameInvoker) itemFrame).invokeGetFrameItemStack());
                        }
                    } else if (entity instanceof ArmorStand armorStand) {
                        for (ItemStack stack : armorStand.getHandSlots()) {
                            if (!stack.isEmpty()) {
                                addItemStack(stacks, stack.copy());
                            }
                        }
                        for (ItemStack stack : armorStand.getArmorSlots()) {
                            if (!stack.isEmpty()) {
                                addItemStack(stacks, stack.copy());
                            }
                        }
                    }
                });

                for (ServerPlayer player : players) {
                    boolean limit = checkLimit(player, stacks);
                    if (limit && !PlayerData.get(player).isNoCreativeItemLimitedTip()) {
                        player.sendSystemMessage(TranslationUtil.messageComponent("count_limit").append(" ").append(TranslationUtil.messageComponent("click_to_hide").withStyle(style -> style.applyFormats(ChatFormatting.YELLOW, ChatFormatting.BOLD).withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/RBG-hide itemGiving true")))));
                    }
                    for (ItemStack stack : stacks) {
                        giveItem(player, limit ? stack.copyWithCount(Math.min(stack.getCount(), stack.getMaxStackSize())) : stack.copy());
                    }
                }
            }

            private static boolean checkLimit(ServerPlayer player, Set<ItemStack> stacks) {
                boolean limit = false;
                if (player.isCreative()) {
                    int stackSize = 0;
                    for (ItemStack stack : stacks) {
                        stackSize += stack.getCount() / stack.getMaxStackSize() + (stack.getCount() % stack.getMaxStackSize() != 0 ? 1 : 0);
                    }
                    int containerSize = player.getInventory().getContainerSize();
                    limit = stackSize > containerSize;
                }
                return limit;
            }

            private static void addItemStack(Set<ItemStack> stacks, ItemStack stack) {
                if (stacks.contains(stack)) {
                    stacks.stream().filter(existingStack -> ItemStack.isSameItemSameTags(existingStack, stack)).findFirst().ifPresent(existingStack -> existingStack.grow(stack.getCount()));
                } else {
                    stacks.add(stack.copy());
                }
            }
        }, NONE {
            @Override
            public void run(ServerLevel level, ActivityArea area, Collection<ServerPlayer> players) {
                // No operation
            }
        };

        public final MutableComponent component = TranslationUtil.screenComponent("item_giving.mode." + name().toLowerCase());

        public void run(Activity activity) {
            run(activity.getLevel(), activity.getArea(), activity.getPlayers());
        }

        public abstract void run(ServerLevel level, ActivityArea area, Collection<ServerPlayer> players);

        public void giveItem(ServerPlayer player, ItemStack stack) {
            if (player.addItem(stack) && stack.isEmpty()) {
                player.level().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 0.2f, ((player.getRandom().nextFloat() - player.getRandom().nextFloat()) * 0.7f + 1.0f) * 2.0f);
                player.inventoryMenu.broadcastChanges();
            } else {
                ItemEntity droppedItem = player.drop(stack, false);
                if (droppedItem != null) {
                    droppedItem.setNoPickUpDelay();
                    droppedItem.setTarget(player.getUUID());
                }
            }
        }
    }

}
