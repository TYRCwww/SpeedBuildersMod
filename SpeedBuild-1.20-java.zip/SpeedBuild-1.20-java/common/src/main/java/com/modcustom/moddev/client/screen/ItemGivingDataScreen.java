package com.modcustom.moddev.client.screen;

import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.area.AreaConfig;
import com.modcustom.moddev.game.data.ItemGivingData;
import com.modcustom.moddev.network.Network;
import com.modcustom.moddev.utils.NumberUtil;
import com.modcustom.moddev.utils.TranslationUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ItemGivingDataScreen extends SyncAreaScreen {

    private static final MutableComponent TITLE = TranslationUtil.screenComponent("item_giving_data.title");
    private ItemList itemList;
    private Button upButton;
    private Button downButton;
    private Button deleteButton;
    private EditBox countBox;
    private EditBox itemBox;
    private Button addItemButton;
    @Nullable
    private ItemList.DataEntry<?> selectedEntry = null;
    private int selectedIndex = -1;
    @Nullable
    private ItemStack nextUpdateSelection = null;

    public ItemGivingDataScreen(ActivityArea area) {
        this(area, null);
    }

    public ItemGivingDataScreen(ActivityArea area, @Nullable Screen parent) {
        super(TITLE, area, parent);
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.render(guiGraphics, mouseX, mouseY, partialTick);
        if (selectedEntry != null) {
            guiGraphics.drawCenteredString(font, selectedEntry.getInfo(), width / 2, height - 16 - font.lineHeight / 2, 0xFFFFFF);
        }
        BuiltInRegistries.ITEM.getOptional(ResourceLocation.tryParse(itemBox.getValue())).ifPresent(item -> {
            ItemStack stack = new ItemStack(item);
            int x = itemBox.getX() - 20;
            int y = itemBox.getY() + 2;
            guiGraphics.renderItem(stack, x, y);
            if (mouseX >= x && mouseX <= x + 16 && mouseY >= y && mouseY <= y + 16) {
                guiGraphics.renderTooltip(font, stack, mouseX, mouseY);
            }
        });
    }

    @Override
    public void update() {
        itemList.refresh();
        List<ItemList.DataEntry<?>> children = itemList.children();
        ItemStack stack = nextUpdateSelection;
        if (stack != null) {
            children.stream().filter(entry -> entry.data instanceof ItemStack itemStack && ItemStack.isSameItemSameTags(itemStack, stack)).findFirst().ifPresent(ItemList.DataEntry::select);
            nextUpdateSelection = null;
        } else {
            if (selectedIndex >= 0 && selectedIndex < children.size()) {
                children.get(selectedIndex).select();
            }
        }
    }

    @Override
    public void tick() {
        super.tick();
        countBox.tick();
        itemBox.tick();
    }

    private MutableComponent getDimensionComponent(ResourceKey<Level> dimension) {
        String key = dimension.location().toLanguageKey("dimension");
        return I18n.exists(key) ? Component.translatable(key) : Component.literal(dimension.location().toString());
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        boolean result = super.keyPressed(keyCode, scanCode, modifiers);
        setSelectedEntry(itemList.getSelected());
        selectedIndex = selectedEntry == null ? -1 : itemList.children().indexOf(selectedEntry);
        updateButtons();
        return result;
    }

    @Override
    public void init() {
        super.init();
        itemList = new ItemList(minecraft);
        int x = itemList.getScrollbarPosition() + 6 + 5;
        upButton = Button.builder(Component.literal("↑"), button -> moveEntry(-1)).bounds(x, 32, 20, 20).build();
        upButton.active = itemList.getMaxScroll() > 0;
        addRenderableWidget(upButton);

        downButton = Button.builder(Component.literal("↓"), button -> moveEntry(1)).bounds(x, 32 + 20 + 5, 20, 20).build();
        downButton.active = itemList.getMaxScroll() > 0;
        addRenderableWidget(downButton);

        deleteButton = Button.builder(Component.literal("-"), button -> {
            if (selectedEntry != null) {
                selectedEntry.remove();
                requestUpdate();
                itemList.refresh();
            }
        }).bounds(x, 32 + 20 + 5 + 20 + 5, 20, 20).build();
        deleteButton.active = selectedEntry != null;
        addRenderableWidget(deleteButton);

        countBox = new EditBox(font, x, 32 + 20 + 5 + 20 + 5 + 20 + 5, 30, 20, TranslationUtil.screenComponent("count"));
        countBox.active = selectedEntry != null;
        countBox.setValue(selectedEntry != null ? String.valueOf(selectedEntry.count) : "");
        countBox.setFilter(text -> NumberUtil.isIntBetweenOrEmpty(text, 1, Integer.MAX_VALUE));
        countBox.setResponder(text -> NumberUtil.getOptionalIntBetween(text, 1, Integer.MAX_VALUE).ifPresent(this::modifyEntryCount));
        addRenderableWidget(countBox);

        addItemButton = Button.builder(Component.literal("+"), button -> {
            Optional<Item> itemOptional = BuiltInRegistries.ITEM.getOptional(ResourceLocation.tryParse(itemBox.getValue()));
            itemOptional.ifPresent(item -> {
                if (item != Items.AIR) {
                    ItemStack stack = new ItemStack(item);
                    area.getConfig().getItemGivingData().addItem(stack);
                    nextUpdateSelection = stack.copy();
                    requestUpdate();
                    itemBox.setValue("");
                }
            });
        }).bounds(width - 30, height - 26, 20, 20).build();
        addItemButton.active = false;
        addRenderableWidget(addItemButton);

        itemBox = new EditBox(font, addItemButton.getX() - 110, addItemButton.getY(), 100, 20, TranslationUtil.screenComponent("item"));
        itemBox.setResponder(text -> {
            Optional<Item> itemOptional = BuiltInRegistries.ITEM.getOptional(ResourceLocation.tryParse(text));
            boolean active = itemOptional.isPresent() && itemOptional.get() != Items.AIR;
            addItemButton.active = active;
            addItemButton.setTooltip(active || text.isEmpty() ? null : Tooltip.create(TranslationUtil.screenComponent("unknown_item")));
        });
        addRenderableWidget(itemBox);

        addRenderableWidget(itemList);
    }

    private void moveEntry(int offset) {
        if (selectedEntry != null && selectedIndex >= 0) {
            ItemGivingData data = area.getConfig().getItemGivingData();
            int itemSize = data.getItems().size();
            if (selectedIndex < itemSize) {
                if (data.moveItem(selectedIndex, offset)) {
                    selectedIndex += offset;
                }
            } else if (data.movePosition(selectedIndex - itemSize, offset)) {
                selectedIndex += offset;
            }
            requestUpdate();
        }
    }

    private void requestUpdate() {
        Network.requestModifyAreaConfig(area.getId(), area.getConfig(), true, AreaConfig.Property.ITEM_GIVING_DATA);
    }

    private void modifyEntryCount(int count) {
        ItemList.DataEntry<?> entry = selectedEntry;
        if (entry != null) {
            ItemGivingData itemGivingData = area.getConfig().getItemGivingData();
            Object data = entry.data;
            if ((data instanceof ItemStack itemStack && itemGivingData.modifyItemCount(itemStack, count)) || (data instanceof GlobalPos globalPos && itemGivingData.modifyPositionCount(globalPos, count))) {
                entry.count = count;
                markModified(AreaConfig.Property.ITEM_GIVING_DATA);
            }
        }
    }

    protected void setSelectedEntry(@Nullable ItemList.DataEntry<?> value) {
        if (this.selectedEntry == value) return;
        this.selectedEntry = value;
        this.countBox.setValue(value != null ? String.valueOf(value.count) : "");
        this.countBox.active = value != null;
    }

    private boolean updateButtons() {
        boolean selected = selectedEntry != null;
        deleteButton.active = selected;
        int itemSize = area.getConfig().getItemGivingData().getItems().size();
        upButton.active = selected && selectedIndex > 0 && selectedIndex != itemSize;
        downButton.active = selected && selectedIndex >= 0 && selectedIndex != itemSize - 1 && selectedIndex < itemList.children().size() - 1;
        return selected;
    }

    public class ItemList extends ObjectSelectionList<ItemList.DataEntry<?>> {

        public ItemList(Minecraft minecraft) {
            super(minecraft, ItemGivingDataScreen.this.width, ItemGivingDataScreen.this.height, 32, ItemGivingDataScreen.this.height - 32, 22);
            setRenderBackground(false);
            setRenderTopAndBottom(false);
            refresh();
        }

        public void refresh() {
            List<DataEntry<?>> entries = new ArrayList<>();
            ItemGivingData data = area.getConfig().getItemGivingData();
            entries.addAll(data.getItems().entrySet().stream().map(entry -> new ItemEntry(entry.getKey(), entry.getValue())).toList());
            entries.addAll(data.getPositions().entrySet().stream().map(entry -> new PositionEntry(entry.getKey(), entry.getValue())).toList());
            replaceEntries(entries);
            if (ItemGivingDataScreen.this.upButton != null) {
                upButton.active = getMaxScroll() > 0;
            }
            if (ItemGivingDataScreen.this.downButton != null) {
                downButton.active = getMaxScroll() > 0;
            }
        }

        @Override
        public int getScrollbarPosition() {
            return super.getScrollbarPosition();
        }

        public abstract class DataEntry<T> extends Entry<DataEntry<?>> {

            protected T data;
            protected int count;

            public DataEntry(T data, int count) {
                this.data = data;
                this.count = count;
            }

            public abstract void remove();

            public abstract Component getInfo();

            @Override
            public boolean mouseClicked(double mouseX, double mouseY, int button) {
                if (button == 0) return select();
                return super.mouseClicked(mouseX, mouseY, button);
            }

            public boolean select() {
                if (selectedEntry == this) {
                    selectedIndex = -1;
                    ItemGivingDataScreen.this.setFocused(null);
                    setSelected(null);
                    setSelectedEntry(null);
                } else {
                    selectedIndex = children().indexOf(this);
                    ItemGivingDataScreen.this.setFocused(this);
                    setSelected(this);
                    ensureVisible(this);
                    setSelectedEntry(this);
                }
                return updateButtons();
            }
        }

        public class ItemEntry extends DataEntry<ItemStack> {

            public ItemEntry(ItemStack item, int count) {
                super(item, count);
            }

            @Override
            public void remove() {
                area.getConfig().getItemGivingData().removeItem(data);
            }

            @Override
            public Component getInfo() {
                return Component.empty();
            }

            @Override
            public void render(GuiGraphics guiGraphics, int index, int top, int left, int width, int height, int mouseX, int mouseY, boolean hovering, float partialTick) {
                int gap = (height - 16) / 2;
                int x = left + gap;
                guiGraphics.renderItem(data, x, top + gap);
                x += 16 + 1 + 5;
                Component name = data.getHoverName();
                int fontY = top + (height - font.lineHeight) / 2 + 1;
                guiGraphics.drawString(font, name, x, fontY, name.getStyle().getColor() != null ? name.getStyle().getColor().getValue() : 0xFFFFFF);
                x += font.width(name) + 5;
                Component countText = Component.literal(String.valueOf(count)).withStyle(name.getStyle());
                guiGraphics.drawString(font, countText, x, fontY, countText.getStyle().getColor() != null ? countText.getStyle().getColor().getValue() : 0xFFFFFF);
                x += font.width(countText) + 5;
                if (data.hasTag()) {
                    guiGraphics.drawString(font, TranslationUtil.screenComponent("has_nbt"), x, fontY, 0x55FF55);
                }

                if (mouseX >= left + gap && mouseX <= left + gap + 16 && mouseY >= top + gap && mouseY <= top + gap + 16) {
                    guiGraphics.renderTooltip(font, data, mouseX, mouseY);
                }
            }

            @Override
            public Component getNarration() {
                return data.getDisplayName();
            }
        }

        public class PositionEntry extends DataEntry<GlobalPos> {

            public PositionEntry(GlobalPos pos, int count) {
                super(pos, count);
            }

            @Override
            public void remove() {
                area.getConfig().getItemGivingData().removePosition(data);
            }

            @Override
            public Component getInfo() {
                return getDimensionComponent(data.dimension()).append(CommonComponents.space()).append(data.pos().toShortString());
            }

            @Override
            public void render(GuiGraphics guiGraphics, int index, int top, int left, int width, int height, int mouseX, int mouseY, boolean hovering, float partialTick) {
                int gap = (height - 16) / 2;
                int x = left + gap;
                Level level = minecraft.level;
                ItemStack stack = null;
                if (level != null && data.dimension() == level.dimension()) {
                    BlockState state = level.getBlockState(data.pos());
                    stack = new ItemStack(state.getBlock());
                    guiGraphics.renderItem(stack, x, top + gap);
                    x += 16 + 1 + 5;
                }
                int fontY = top + (height - font.lineHeight) / 2 + 1;
                if (stack != null) {
                    Component name = Component.literal("*").append(stack.getHoverName());
                    guiGraphics.drawString(font, name, x, fontY, name.getStyle().getColor() != null ? name.getStyle().getColor().getValue() : 0xFFFFFF);
                    x += font.width(name) + 5;
                } else {
                    Component text = TranslationUtil.screenComponent("unknown_position");
                    guiGraphics.drawString(font, text, x, fontY, 0xFFFFFF);
                    x += font.width(text) + 5;
                }
                String countText = String.valueOf(count);
                guiGraphics.drawString(font, Component.literal(countText), x, fontY, 0xFFFFFF);
                x += font.width(countText) + 5;
                Component dimensionText = getDimensionComponent(data.dimension());
                guiGraphics.drawString(font, dimensionText, x, fontY, 0xAAAAAA);
                x += font.width(dimensionText) + 5;
                String posText = data.pos().toShortString();
                guiGraphics.drawString(font, Component.literal(posText), x, fontY, 0xAAAAAA);

                if (stack != null && !stack.isEmpty() && mouseX >= left + gap && mouseX <= left + gap + 16 && mouseY >= top + gap && mouseY <= top + gap + 16) {
                    guiGraphics.renderTooltip(font, stack, mouseX, mouseY);
                }
            }

            @Override
            public Component getNarration() {
                return Component.literal(data.toString());
            }
        }
    }
}

