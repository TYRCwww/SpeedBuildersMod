package com.modcustom.moddev.events;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.network.Network;
import com.modcustom.moddev.utils.PlayerUtil;
import dev.architectury.event.events.common.PlayerEvent;
import dev.architectury.event.events.common.TickEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

public class PlayerEventHandler {

    public static void register() {
        PlayerEvent.PLAYER_JOIN.register(Network::updateActivityAreas);
        PlayerEvent.PLAYER_JOIN.register(Network::updateProtectedAreas);
        PlayerEvent.PLAYER_JOIN.register(Network::updateFunctionAreas);
        PlayerEvent.PLAYER_JOIN.register(Network::syncPlayerData);
        TickEvent.PLAYER_PRE.register(PlayerEventHandler::checkFlyingWithExtraJump);
    }

    private static void checkFlyingWithExtraJump(Player player) {
        if (!player.getAbilities().flying) return;
        if (player instanceof ServerPlayer serverPlayer && PlayerUtil.isExtraJumpEnabled(serverPlayer) || ClientGameManager.getInstance().getCachedData().isExtraJumpEnabled()) {
            player.getAbilities().flying = false;
        }
    }
}
