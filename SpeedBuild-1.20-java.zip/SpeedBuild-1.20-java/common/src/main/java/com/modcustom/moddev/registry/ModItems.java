package com.modcustom.moddev.registry;

import com.modcustom.moddev.items.activity.AreaConfigurationItem;
import com.modcustom.moddev.items.activity.ConstructionAreaSelectionItem;
import com.modcustom.moddev.items.activity.TargetAreaSelectionItem;
import com.modcustom.moddev.items.function.FunctionAreaConfigurationItem;
import com.modcustom.moddev.items.function.FunctionAreaSelectionItem;
import com.modcustom.moddev.items.protect.ProtectedAreaConfigurationItem;
import com.modcustom.moddev.items.protect.ProtectedAreaSelectionItem;
import dev.architectury.registry.CreativeTabRegistry;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import static com.modcustom.moddev.SpeedBuild.MOD_ID;

public class ModItems {

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(MOD_ID, Registries.ITEM);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(MOD_ID, Registries.CREATIVE_MODE_TAB);

    public static final RegistrySupplier<Item> TARGET_AREA_SELECTION = ITEMS.register("target_area_selection", () -> new TargetAreaSelectionItem(createProperties()));
    public static final RegistrySupplier<Item> CONSTRUCTION_AREA_SELECTION = ITEMS.register("construction_area_selection", () -> new ConstructionAreaSelectionItem(createProperties()));
    public static final RegistrySupplier<Item> AREA_CONFIGURATION = ITEMS.register("area_configuration", () -> new AreaConfigurationItem(createProperties()));
    public static final RegistrySupplier<Item> PROTECTED_AREA_SELECTION = ITEMS.register("protected_area_selection", () -> new ProtectedAreaSelectionItem(createProperties()));
    public static final RegistrySupplier<Item> PROTECTED_AREA_CONFIGURATION = ITEMS.register("protected_area_configuration", () -> new ProtectedAreaConfigurationItem(createProperties()));
    public static final RegistrySupplier<Item> FUNCTION_AREA_SELECTION = ITEMS.register("function_area_selection", () -> new FunctionAreaSelectionItem(createProperties()));
    public static final RegistrySupplier<Item> FUNCTION_AREA_CONFIGURATION = ITEMS.register("function_area_configuration", () -> new FunctionAreaConfigurationItem(createProperties()));

    public static final RegistrySupplier<CreativeModeTab> ITEMS_TAB = TABS.register("items_tab", () -> CreativeTabRegistry.create(Component.translatable("itemGroup." + MOD_ID + ".items_tab"), () -> new ItemStack(AREA_CONFIGURATION.orElse(Items.STICK))));

    private static Item.Properties createProperties() {
        return new Item.Properties().arch$tab(ITEMS_TAB).stacksTo(1);
    }

    public static void register() {
        TABS.register();
        ITEMS.register();
    }
}
