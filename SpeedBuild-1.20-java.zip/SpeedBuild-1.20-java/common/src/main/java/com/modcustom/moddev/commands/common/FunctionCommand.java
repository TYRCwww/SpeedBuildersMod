package com.modcustom.moddev.commands.common;

import com.modcustom.moddev.arguments.AreaFunctionArgument;
import com.modcustom.moddev.functions.AreaFunction;
import com.modcustom.moddev.game.area.FunctionArea;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.utils.ActionResult;
import com.modcustom.moddev.utils.TranslationUtil;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

public class FunctionCommand extends CommonCommand {

    public FunctionCommand() {
        super("function");
    }

    @Override
    public LiteralArgumentBuilder<CommandSourceStack> build(LiteralArgumentBuilder<CommandSourceStack> builder, CommandBuildContext context) {
        return builder.then(executeSelect()).then(executeArea());
    }

    private LiteralArgumentBuilder<CommandSourceStack> executeSelect() {
        return Commands.literal("select")
                       .then(Commands.argument("function", AreaFunctionArgument.functionWithArea())
                                     .then(Commands.argument("area", IntegerArgumentType.integer(0))
                                                   .executes(context -> {
                                                                 AreaFunction function = getFunction(context);
                                                                 int areaId = IntegerArgumentType.getInteger(context, "area");
                                                                 function.setAreaId(areaId);
                                                                 CommandSourceStack source = context.getSource();
                                                                 ActionResult result = executeFunction(source, function);
                                                                 return result.isSuccess() ? 1 : 0;
                                                             }
                                                   )
                                     )
                                     .then(Commands.literal("nearby")
                                                   .executes(context -> {
                                                                 AreaFunction function = getFunction(context);
                                                                 function.setAreaId(-1);
                                                                 CommandSourceStack source = context.getSource();
                                                                 ActionResult result = executeFunction(source, function);
                                                                 return result.isSuccess() ? 1 : 0;
                                                             }
                                                   )
                                     )
                       );
    }

    private static ActionResult executeFunction(CommandSourceStack source, AreaFunction function) {
        ServerLevel level = source.getLevel();
        ActionResult result;
        if (source.isPlayer()) {
            result = function.execute(level, null, source.getPlayer(), null);
        } else {
            result = function.execute(level, BlockPos.containing(source.getPosition()));
        }
        return result;
    }

    private AreaFunction getFunction(CommandContext<CommandSourceStack> context) {
        return AreaFunctionArgument.getFunction(context, "function");
    }

    private LiteralArgumentBuilder<CommandSourceStack> executeArea() {
        return Commands.literal("area")
                       .then(Commands.argument("area", IntegerArgumentType.integer(0))
                                     .executes(context -> {
                                                   int areaId = IntegerArgumentType.getInteger(context, "area");
                                                   FunctionArea area = GameData.getGameData(context).getFunctionArea(areaId);
                                                   if (area != null) {
                                                       CommandSourceStack source = context.getSource();
                                                       executeFunctionArea(source, area);
                                                       return 1;
                                                   } else {
                                                       sendFailureWithNoAreaFound(context);
                                                       return 0;
                                                   }
                                               }
                                     )
                       )
                       .then(Commands.literal("nearby")
                                     .executes(context -> {
                                                   CommandSourceStack source = context.getSource();
                                                   ServerLevel level = source.getLevel();
                                                   Vec3 position = source.getPosition();
                                                   FunctionArea area = GameData.getGameData(context).getNearestFunctionArea(level, position, 15);
                                                   if (area != null) {
                                                       executeFunctionArea(source, area);
                                                       return 1;
                                                   } else {
                                                       sendFailureWithNoAreaFound(context);
                                                       return 0;
                                                   }
                                               }
                                     )
                       );
    }

    private static void executeFunctionArea(CommandSourceStack source, FunctionArea area) {
        ServerLevel level = source.getLevel();
        if (source.isPlayer()) {
            area.executeByPlayer(level, null, source.getPlayer(), null);
        } else {
            area.executeWithoutPlayer(level, BlockPos.containing(source.getPosition()), component -> source.sendSuccess(() -> component, true));
        }
    }

    private static void sendFailureWithNoAreaFound(CommandContext<CommandSourceStack> context) {
        context.getSource().sendFailure(TranslationUtil.messageComponent("function_area.not_found"));
    }
}
