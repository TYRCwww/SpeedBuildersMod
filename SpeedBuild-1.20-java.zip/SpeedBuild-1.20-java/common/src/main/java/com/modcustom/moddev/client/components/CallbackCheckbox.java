package com.modcustom.moddev.client.components;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Checkbox;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

@Environment(EnvType.CLIENT)
public class CallbackCheckbox extends Checkbox {

    private static final ResourceLocation TEXTURE = new ResourceLocation("textures/gui/checkbox.png");
    private final Font font;
    private final OnPress onPress;
    private final boolean showLabel;
    private boolean setting = false;
    private boolean leftComponent = false;

    public CallbackCheckbox(Font font, Component message, boolean selected) {
        this(font, message, selected, b -> true);
    }

    public CallbackCheckbox(Font font, Component message, boolean selected, OnPress onPress) {
        this(font, 0, 0, message, selected, true, onPress);
    }

    public CallbackCheckbox(Font font, int x, int y, Component message, boolean selected, boolean showLabel, OnPress onPress) {
        super(x, y, !showLabel ? 20 : 24 + font.width(message), 20, message, selected, showLabel);
        this.font = font;
        this.onPress = onPress;
        this.showLabel = showLabel;
    }

    public void setSelected(boolean selected) {
        if (this.selected() != selected) {
            setting = true;
            this.onPress();
        }
    }

    @Override
    public void onPress() {
        if (setting || onPress.onPress(!this.selected())) {
            super.onPress();
            setting = false;
        }
    }

    @Override
    public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (!leftComponent) {
            super.renderWidget(guiGraphics, mouseX, mouseY, partialTick);
        } else {
            RenderSystem.enableDepthTest();
            guiGraphics.setColor(1.0f, 1.0f, 1.0f, this.alpha);
            RenderSystem.enableBlend();
            guiGraphics.blit(TEXTURE, this.getX() + this.width - 20, this.getY(), this.isFocused() ? 20.0f : 0.0f, this.selected() ? 20.0f : 0.0f, 20, this.height, 64, 64);
            guiGraphics.setColor(1.0f, 1.0f, 1.0f, 1.0f);
            if (this.showLabel) {
                guiGraphics.drawString(font, this.getMessage(), this.getX(), this.getY() + (this.height - 8) / 2, 0xE0E0E0 | Mth.ceil(this.alpha * 255.0f) << 24);
            }
        }
    }

    public boolean isLeftComponent() {
        return leftComponent;
    }

    public void setLeftComponent(boolean leftComponent) {
        this.leftComponent = leftComponent;
    }

    public CallbackCheckbox leftComponent() {
        setLeftComponent(true);
        return this;
    }

    public interface OnPress {

        boolean onPress(boolean selected);
    }
}
