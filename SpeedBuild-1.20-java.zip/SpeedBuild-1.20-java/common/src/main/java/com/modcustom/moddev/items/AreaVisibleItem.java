package com.modcustom.moddev.items;

import com.modcustom.moddev.api.AreaVisible;
import com.modcustom.moddev.game.area.Area;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public abstract class AreaVisibleItem extends Item implements AreaVisible {

    public AreaVisibleItem(Properties properties) {
        super(properties);
    }

    @Override
    public boolean isVisible(@Nullable Area.Type type) {
        return type == Area.Type.ACTIVITY;
    }

    @Override
    public void appendHoverText(ItemStack itemStack, @Nullable Level level, List<Component> list, TooltipFlag tooltipFlag) {
        super.appendHoverText(itemStack, level, list, tooltipFlag);
        String key = itemStack.getDescriptionId() + ".tooltip";
        list.add(Component.translatable(key).withStyle(ChatFormatting.GRAY));
    }
}
