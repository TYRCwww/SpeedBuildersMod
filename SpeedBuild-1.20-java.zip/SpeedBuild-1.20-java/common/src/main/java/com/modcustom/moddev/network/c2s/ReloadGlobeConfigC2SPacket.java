package com.modcustom.moddev.network.c2s;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.config.GlobeConfig;
import com.modcustom.moddev.utils.TranslationUtil;
import dev.architectury.networking.NetworkManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.function.Supplier;

public class ReloadGlobeConfigC2SPacket implements NetworkPacket {

    @Override
    public void encode(FriendlyByteBuf buf) {

    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        if (contextSupplier.get().getPlayer() instanceof ServerPlayer player) {
            if (player.hasPermissions(2)) {
                GlobeConfig.load();
                player.sendSystemMessage(TranslationUtil.messageComponent("reload"));
            } else {
                player.sendSystemMessage(Component.translatable("commands.help.failed").withStyle(ChatFormatting.RED));
            }
        }
    }
}
