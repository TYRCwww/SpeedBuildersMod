package com.modcustom.moddev.commands.client;

import com.modcustom.moddev.config.Config;
import com.modcustom.moddev.config.SneakTweakConfig;
import com.modcustom.moddev.network.Network;
import com.modcustom.moddev.utils.TranslationUtil;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.architectury.event.events.client.ClientCommandRegistrationEvent;
import dev.architectury.event.events.client.ClientCommandRegistrationEvent.ClientCommandSourceStack;
import net.minecraft.commands.CommandBuildContext;

public class ReloadCommand extends ClientCommand {

    public ReloadCommand() {
        super("reload");
    }

    @Override
    public LiteralArgumentBuilder<ClientCommandSourceStack> build(LiteralArgumentBuilder<ClientCommandSourceStack> builder, CommandBuildContext context) {
        return builder.then(executeClient()).then(executeGlobe());
    }

    private LiteralArgumentBuilder<ClientCommandSourceStack> executeClient() {
        return ClientCommandRegistrationEvent.literal("client").executes(context -> {
            Config.load();
            SneakTweakConfig.load();
            context.getSource().arch$sendSuccess(() -> TranslationUtil.messageComponent("reload"), false);
            return 1;
        });
    }

    private LiteralArgumentBuilder<ClientCommandSourceStack> executeGlobe() {
        return ClientCommandRegistrationEvent.literal("globe").requires(source -> source.hasPermission(2)).executes(context -> {
            Network.requestReloadGlobeConfig();
            return 1;
        });
    }
}
