package com.modcustom.moddev.game;

import com.modcustom.moddev.config.GlobeConfig;
import com.modcustom.moddev.utils.TranslationUtil;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;

import java.util.Set;

public enum EntityDetectionMode {
    NONE {
        @Override
        public boolean compare(Entity first, Entity second) {
            return true;
        }
    }, ATTRIBUTES {
        @Override
        public boolean compare(Entity first, Entity second) {
            if (second.getType() != first.getType()) {
                return false;
            }
            CompoundTag tag = new CompoundTag();
            CompoundTag tag1 = new CompoundTag();
            second.saveWithoutId(tag);
            first.saveWithoutId(tag1);
            Set<String> except = GlobeConfig.getInstance().getExceptAttributes("entity", EntityType.getKey(first.getType()));
            except.forEach(tag::remove);
            except.forEach(tag1::remove);
            tag.remove("ItemSpawnOwner");
            tag1.remove("ItemSpawnOwner");
            return tag.equals(tag1);
        }
    }, ONLY_NAME {
        @Override
        public boolean compare(Entity first, Entity second) {
            return first.getDisplayName().getString().equals(second.getDisplayName().getString()) && first.getYRot() == second.getYRot() && first.getXRot() == second.getXRot();
        }
    };

    public MutableComponent getComponent() {
        return TranslationUtil.screenComponent("entity_detection_mode." + name().toLowerCase());
    }

    public boolean isActive() {
        return this != NONE;
    }

    public abstract boolean compare(Entity first, Entity second);
}
