package com.modcustom.moddev.functions;

import com.modcustom.moddev.api.Function;
import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.AreaFinder;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.utils.ActionResult;
import com.modcustom.moddev.utils.TranslationUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import static com.modcustom.moddev.utils.TranslationUtil.messageComponent;

public abstract class AreaFunction implements Function {

    protected boolean enabled = false;
    protected int areaId = -1;

    @Override
    public CompoundTag writeNbt(CompoundTag tag) {
        Function.super.writeNbt(tag);
        tag.putBoolean("enabled", enabled);
        tag.putInt("areaId", areaId);
        return tag;
    }

    @Override
    public void readNbt(CompoundTag tag) {
        Function.super.readNbt(tag);
        if (tag.contains("enabled")) {
            enabled = tag.getBoolean("enabled");
        }
        if (tag.contains("areaId")) {
            areaId = tag.getInt("areaId");
        }
    }

    public Component failComponent() {
        return TranslationUtil.failComponent(messageComponent("area_not_found"));
    }

    public Component successComponent() {
        return getDisplayName();
    }

    protected ActionResult executeWithArea(Level level, BlockPos pos, AreaTask task) {
        ActivityArea area = getArea(level, pos);
        return ActionResult.of(area != null && task.execute(area));
    }

    @Nullable
    public ActivityArea getArea(Level level, BlockPos pos) {
        int id = getAreaId();
        if (id == -1) {
            return AreaFinder.NEAREST.find(level, pos);
        }
        if (level instanceof ServerLevel serverLevel) {
            return GameData.getGameData(serverLevel).getActivityArea(id);
        }
        return ClientGameManager.getInstance().getActivityAreas(id);
    }

    public int getAreaId() {
        return requiresAreaId() ? areaId : -1;
    }

    public void setAreaId(int areaId) {
        this.areaId = areaId;
    }

    public boolean requiresAreaId() {
        return true;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public interface AreaTask {

        boolean execute(ActivityArea area);
    }
}
