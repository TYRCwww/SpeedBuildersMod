package com.modcustom.moddev.game.activity;

import com.modcustom.moddev.api.SavableData;
import com.modcustom.moddev.game.data.ClientCachedData;
import com.modcustom.moddev.utils.Timer;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import org.jetbrains.annotations.Nullable;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ActivityRecord implements SavableData {

    private final int id;
    @Nullable
    private final String initiator;
    private final Map<String, ClientCachedData> players;
    private final long startTime;
    private final long runtime;
    private final long finishTime;
    private final boolean interrupted;
    private final boolean restored;
    @Nullable
    private final Long lastPlacingBlockTime;
    @Nullable
    private final Long lastPlacingEntityTime;
    private final int unrestoredBlockProgress;
    private final int unrestoredEntityProgress;

    private ActivityRecord(int id, @Nullable String initiator, Map<String, ClientCachedData> players, long startTime, long runtime) {
        this.interrupted = false;

        this.id = id;
        this.initiator = initiator;
        this.players = players;
        this.startTime = startTime;
        this.runtime = runtime;
        this.finishTime = startTime + runtime;
        this.restored = true;
        this.lastPlacingBlockTime = null;
        this.lastPlacingEntityTime = null;
        this.unrestoredBlockProgress = 0;
        this.unrestoredEntityProgress = 0;
    }

    private ActivityRecord(int id, @Nullable String initiator, Map<String, ClientCachedData> players, long startTime, long runtime, boolean restored, @Nullable Long lastPlacingBlockTime, @Nullable Long lastPlacingEntityTime, int unrestoredBlockProgress, int unrestoredEntityProgress) {
        this.interrupted = true;

        this.id = id;
        this.initiator = initiator;
        this.players = players;
        this.startTime = startTime;
        this.runtime = runtime;
        this.finishTime = startTime + runtime;
        this.restored = restored;
        this.lastPlacingBlockTime = lastPlacingBlockTime;
        this.lastPlacingEntityTime = lastPlacingEntityTime;
        this.unrestoredBlockProgress = unrestoredBlockProgress;
        this.unrestoredEntityProgress = unrestoredEntityProgress;
    }

    @Override
    public void save(CompoundTag tag) {
        tag.putInt("id", this.id);
        if (initiator != null) {
            tag.putString("initiator", initiator);
        }
        tag.putLong("startTime", startTime);
        tag.putLong("runtime", runtime);
        CompoundTag playersTag = new CompoundTag();
        players.forEach((key, value) -> playersTag.put(key, value.toNbt()));
        tag.put("players", playersTag);
        tag.putBoolean("interrupted", interrupted);
        tag.putBoolean("restored", restored);
        if (lastPlacingBlockTime != null) {
            tag.putLong("lastPlacingBlockTime", lastPlacingBlockTime);
        }
        if (lastPlacingEntityTime != null) {
            tag.putLong("lastPlacingEntityTime", lastPlacingEntityTime);
        }
        tag.putInt("unrestoredBlockProgress", unrestoredBlockProgress);
        tag.putInt("unrestoredEntityProgress", unrestoredEntityProgress);
    }

    @Override
    public String toString() {
        return String.format(
                "ActivityRecord(id: %d, " +
                "initiator: %s, " +
                "startTime: %s, " +
                "finishTime: %s, " +
                "runtime: %s, " +
                "players: %s, " +
                "interrupted: %b, " +
                "restored: %b, " +
                "lastPlacingBlockTime: %s, " +
                "lastPlacingEntityTime: %s, " +
                "unrestoredBlockProgress: %d, " +
                "unrestoredEntityProgress: %d)",
                id,
                initiator,
                formatTime(startTime),
                formatTime(finishTime),
                Timer.formatTime(runtime),
                players.entrySet().stream()
                       .map(entry -> entry.getKey() + ": " + entry.getValue())
                       .toList(),
                interrupted,
                restored,
                lastPlacingBlockTime != null ? Timer.formatTime(lastPlacingBlockTime - startTime) : "null",
                lastPlacingEntityTime != null ? Timer.formatTime(lastPlacingEntityTime - startTime) : "null",
                unrestoredBlockProgress,
                unrestoredEntityProgress
        );
    }

    public static String formatTime(long time) {
        return new SimpleDateFormat("yyyy/M/d HH:mm:ss.SSS").format(new Date(time));
    }

    public int getId() {
        return id;
    }

    @Nullable
    public String getInitiator() {
        return initiator;
    }

    public Map<String, ClientCachedData> getPlayers() {
        return players;
    }

    public long getStartTime() {
        return startTime;
    }

    public long getRuntime() {
        return runtime;
    }

    public long getFinishTime() {
        return finishTime;
    }

    public boolean isInterrupted() {
        return interrupted;
    }

    public boolean isRestored() {
        return restored;
    }

    @Nullable
    public Long getLastPlacingBlockTime() {
        return lastPlacingBlockTime;
    }

    @Nullable
    public Long getLastPlacingEntityTime() {
        return lastPlacingEntityTime;
    }

    public int getUnrestoredBlockProgress() {
        return unrestoredBlockProgress;
    }

    public int getUnrestoredEntityProgress() {
        return unrestoredEntityProgress;
    }

    public static ActivityRecord fromNbt(CompoundTag tag) {
        Map<String, ClientCachedData> playersMap = new HashMap<>();
        CompoundTag playersTag = tag.getCompound("players");
        for (String key : playersTag.getAllKeys()) {
            playersMap.put(key, new ClientCachedData().readNbt(playersTag.getCompound(key)));
        }

        int id = tag.getInt("id");
        String initiator = tag.contains("initiator") ? tag.getString("initiator") : null;
        long startTime = tag.getLong("startTime");
        long runtime = tag.getLong("runtime");

        boolean interrupted = tag.getBoolean("interrupted");
        if (interrupted) {
            boolean restored = tag.getBoolean("restored");
            Long lastPlacingBlockTime = tag.contains("lastPlacingBlockTime", Tag.TAG_LONG) ? tag.getLong("lastPlacingBlockTime") : null;
            Long lastPlacingEntityTime = tag.contains("lastPlacingEntityTime", Tag.TAG_LONG) ? tag.getLong("lastPlacingEntityTime") : null;
            int unrestoredBlockProgress = tag.getInt("unrestoredBlockProgress");
            int unrestoredEntityProgress = tag.getInt("unrestoredEntityProgress");
            return createInterruptedRecord(id, initiator, playersMap, startTime, runtime, restored, lastPlacingBlockTime, lastPlacingEntityTime, unrestoredBlockProgress, unrestoredEntityProgress);
        }
        return createFinishedRecord(id, initiator, playersMap, startTime, runtime);
    }

    public static ActivityRecord createFinishedRecord(int id, @Nullable String initiator, Map<String, ClientCachedData> players, long startTime, long runtime) {
        return new ActivityRecord(id, initiator, players, startTime, runtime);
    }

    public static ActivityRecord createInterruptedRecord(int id, @Nullable String initiator, Map<String, ClientCachedData> players, long startTime, long runtime, boolean restored, @Nullable Long lastPlacingBlockTime, @Nullable Long lastPlacingEntityTime, int unrestoredBlockProgress, int unrestoredEntityProgress) {
        return new ActivityRecord(id, initiator, players, startTime, runtime, restored, lastPlacingBlockTime, lastPlacingEntityTime, unrestoredBlockProgress, unrestoredEntityProgress);
    }
}
