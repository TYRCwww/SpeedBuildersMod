package com.modcustom.moddev.commands.common;

import com.modcustom.moddev.game.data.PlayerData;
import com.modcustom.moddev.utils.TranslationUtil;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.function.BiConsumer;
import java.util.function.Function;

public class HideCommand extends CommonCommand {

    public HideCommand() {
        super("hide");
    }

    @Override
    public LiteralArgumentBuilder<CommandSourceStack> build(LiteralArgumentBuilder<CommandSourceStack> builder, CommandBuildContext context) {
        return builder.requires(stack -> stack.isPlayer() && stack.hasPermission(2)).then(executeItemGiving());
    }

    private LiteralArgumentBuilder<CommandSourceStack> executeItemGiving() {
        return execute("itemGiving", (player, hide) -> PlayerData.get(player).setNoCreativeItemLimitedTip(hide), player -> PlayerData.get(player).isNoCreativeItemLimitedTip());
    }

    protected LiteralArgumentBuilder<CommandSourceStack> execute(String name, BiConsumer<ServerPlayer, Boolean> setter, Function<ServerPlayer, Boolean> getter) {
        return Commands.literal(name)
                       .then(Commands.argument("hide", BoolArgumentType.bool()).executes(ctx -> {
                           ServerPlayer player = ctx.getSource().getPlayer();
                           if (player != null) {
                               boolean hide = BoolArgumentType.getBool(ctx, "hide");
                               setter.accept(player, hide);
                               ctx.getSource().sendSuccess(TranslationUtil::successComponent, true);
                               return 1;
                           }
                           return 0;
                       }))
                       .executes(ctx -> {
                           ServerPlayer player = ctx.getSource().getPlayer();
                           if (player != null) {
                               boolean onOff = getter.apply(player);
                               player.sendSystemMessage(Component.literal(name + ": ").append(TranslationUtil.screenComponent(onOff ? "on" : "off")));
                               return 1;
                           }
                           return 0;
                       });
    }
}
