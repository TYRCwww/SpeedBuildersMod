package com.modcustom.moddev.game.area;

import com.modcustom.moddev.config.Config;
import com.modcustom.moddev.config.GlobeConfig;
import com.modcustom.moddev.game.BaseSetting;
import com.modcustom.moddev.game.EntityDetectionMode;
import com.modcustom.moddev.game.activity.Activity;
import com.modcustom.moddev.game.activity.ActivityRecord;
import com.modcustom.moddev.network.Network;
import com.modcustom.moddev.utils.RenderUtil;
import com.modcustom.moddev.utils.Util;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.datafixers.util.Pair;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class ActivityArea extends Area {

    private final int id;
    private final UUID owner;
    private final String dimension;
    private final Area construction;
    private final Area target;
    private final AreaConfig config;
    private final List<ActivityRecord> history;
    private String nameCache;
    private boolean isCopying;
    private boolean isResettingConstructionArea;
    private boolean isResettingTargetArea;

    protected ActivityArea(int id, UUID owner, String dimension, Area construction, Area target, AreaConfig config) {
        super(construction.combine(target).getBoundingBox());
        this.id = id;
        this.owner = owner;
        this.dimension = dimension;
        this.construction = construction;
        this.target = target;
        this.config = config != null ? config : new AreaConfig();
        this.history = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public UUID getOwner() {
        return owner;
    }

    public String getDimension() {
        return dimension;
    }

    public Area getConstruction() {
        return construction;
    }

    public Area getTarget() {
        return target;
    }

    public AreaConfig getConfig() {
        return config;
    }

    public String getNameCache() {
        return nameCache;
    }

    public void setNameCache(String nameCache) {
        this.nameCache = nameCache;
    }

    public List<ActivityRecord> getLimitedHistory() {
        return limitAndSortRecords(history, config.getHistoryLimit());
    }

    public void addHistory(ActivityRecord... records) {
        if (records == null || records.length == 0) return;
        addHistory(Arrays.asList(records));
    }

    public void addHistory(Collection<ActivityRecord> records) {
        if (records == null || records.isEmpty()) return;
        history.addAll(records);
        sortHistory();
    }

    public void clearHistory() {
        history.clear();
    }

    @Override
    public void save(CompoundTag tag) {
        super.save(tag);
        tag.putInt("id", id);
        if (owner != null) {
            tag.putUUID("owner", owner);
        }
        tag.putString("dimension", dimension);
        tag.put("construction", construction.toNbt());
        tag.put("target", target.toNbt());
        tag.put("config", config.toNbt());
        if (nameCache != null) {
            tag.putString("name", nameCache);
        }
        ListTag historyTag = new ListTag();
        for (ActivityRecord record : getSortedHistory()) {
            historyTag.add(record.toNbt());
        }
        if (!historyTag.isEmpty()) {
            tag.put("history", historyTag);
        }
    }

    public List<ActivityRecord> getSortedHistory() {
        sortHistory();
        return getHistory();
    }

    public List<ActivityRecord> getHistory() {
        return List.copyOf(history);
    }

    public void setHistory(Collection<ActivityRecord> records) {
        this.history.clear();
        if (records == null || records.isEmpty()) return;
        this.history.addAll(records);
        sortHistory();
    }

    public void sortHistory() {
        List<ActivityRecord> sortedHistory = limitAndSortRecords(history, -1);
        history.clear();
        history.addAll(sortedHistory);
    }

    public void limitAndSortHistory() {
        List<ActivityRecord> list = limitAndSortRecords(history, config.getHistoryLimit());
        history.clear();
        history.addAll(list);
    }

    private List<ActivityRecord> limitAndSortRecords(Collection<ActivityRecord> records, int limit) {
        return records.stream()
                      .sorted(Comparator.comparingLong(ActivityRecord::getFinishTime).reversed())
                      .limit(limit > 0 ? limit : records.size())
                      .toList();
    }

    @Override
    public ActivityArea copy() {
        ActivityArea copy = new ActivityArea(id, owner, dimension, construction.copy(), target.copy(), new AreaConfig().copy(config));
        copy.setNameCache(nameCache);
        return copy;
    }

    @Override
    public void render(PoseStack stack, int color) {
        super.render(stack, color);
        construction.render(stack, Config.getInstance().getConstructionAreaColor());
        target.render(stack, Config.getInstance().getTargetAreaColor());
    }

    @Override
    public Type getType() {
        return Type.ACTIVITY;
    }

    @Override
    public String toString() {
        return String.format(
                "ActivityArea(id: %d, " +
                "owner: %s, " +
                "name: %s, " +
                "dimension: %s, " +
                "construction: %s, target: %s, " +
                "config: %s, " +
                "history: %s)",
                id,
                owner,
                nameCache,
                dimension,
                construction,
                target,
                config,
                history
        );
    }

    public void startCopyTargetTask(ServerLevel level) {
        if (isCopying || isResettingConstructionArea) return;
        isCopying = true;
        level.getServer().execute(() -> {
            copyTargetArea(level);
            isCopying = false;
        });
    }

    private void copyTargetArea(ServerLevel level) {
        copyArea(level, target.getBoundingBox(), construction.getBoundingBox());
    }

    public void startCopyConstructionTask(ServerLevel level) {
        if (isCopying || isResettingConstructionArea) return;
        isCopying = true;
        level.getServer().execute(() -> {
            copyConstructionArea(level);
            isCopying = false;
        });
    }

    private void copyConstructionArea(ServerLevel level) {
        copyArea(level, construction.getBoundingBox(), target.getBoundingBox());
    }

    private void copyArea(ServerLevel level, BoundingBox from, BoundingBox to) {
        if (!level.dimension().location().toString().equals(dimension)) return;
        BlockPos targetMinPos = new BlockPos(from.minX(), from.minY(), from.minZ());
        BlockPos constructionMinPos = new BlockPos(to.minX(), to.minY(), to.minZ());
        cloneBlocks(level, from, constructionMinPos);
        getConstructionAreaEntities(level).forEach(Entity::discard);
        getTargetAreaEntities(level).forEach(entity -> {
            Vec3 offsetPos = entity.position().subtract(targetMinPos.getX(), targetMinPos.getY(), targetMinPos.getZ()).add(constructionMinPos.getX(), constructionMinPos.getY(), constructionMinPos.getZ());
            entity.getType().spawn(level, null, newEntity -> {
                CompoundTag tag = entity.saveWithoutId(new CompoundTag());
                tag.remove("Pos");
                tag.remove("UUID");
                tag.remove("TileX");
                tag.remove("TileY");
                tag.remove("TileZ");
                newEntity.load(tag);
                newEntity.setPos(offsetPos);
                newEntity.setXRot(entity.getXRot());
                newEntity.setYRot(entity.getYRot());
                if (newEntity instanceof Mob mob) {
                    mob.setNoAi(true);
                }
            }, BlockPos.containing(offsetPos), MobSpawnType.EVENT, false, false);
        });
    }

    public List<Entity> getConstructionAreaEntities(Level level) {
        return getConstructionAreaEntities(level, null, entity -> !(entity instanceof Player));
    }

    public List<Entity> getConstructionAreaEntities(Level level, Entity except, Predicate<Entity> predicate) {
        return level.getEntities(except, construction.getBox(), predicate);
    }

    public List<Entity> getTargetAreaEntities(Level level) {
        return getTargetAreaEntities(level, null, entity -> !(entity instanceof Player));
    }

    public List<Entity> getTargetAreaEntities(Level level, Entity except, Predicate<Entity> predicate) {
        return level.getEntities(except, target.getBox(), predicate);
    }

    private static void cloneBlocks(ServerLevel level, BoundingBox box, BlockPos startMinPos) {
        BlockPos targetMinPos = new BlockPos(box.minX(), box.minY(), box.minZ());
        for (BlockPos pos : Util.toBlockPosList(box)) {
            BlockPos offsetPos = pos.subtract(targetMinPos).offset(startMinPos);
            level.setBlock(offsetPos, level.getBlockState(pos), Block.UPDATE_CLIENTS);
            BlockEntity oldEntity = level.getBlockEntity(pos);
            if (oldEntity != null) {
                BlockEntity newEntity = level.getBlockEntity(offsetPos);
                if (newEntity != null) {
                    newEntity.load(oldEntity.saveWithoutMetadata());
                }
            }
        }
    }

    public void startCloneBaseTask(ServerLevel level) {
        if (isCopying || isResettingConstructionArea) return;
        isCopying = true;
        level.getServer().execute(() -> {
            cloneBaseOfConstructionArea(level);
            isCopying = false;
        });
    }

    private void cloneBaseOfConstructionArea(ServerLevel level) {
        if (!level.dimension().location().toString().equals(dimension)) return;
        BoundingBox box = construction.getBoundingBox();
        int y = box.minY();
        BoundingBox baseBox = new BoundingBox(box.minX(), y, box.minZ(), box.maxX(), y, box.maxZ());
        BaseSetting baseSetting = config.getBaseSetting();

        Map<BlockPos, BlockPos> map = Util.toBlockPosList(baseBox).stream().collect(Collectors.toMap(e -> e, e -> e.offset(0, -1, 0)));

        boolean ignoreProtectedArea = baseSetting.isIgnoreProtectedArea();
        Set<BlockPos> blocksToBeUpdated = new HashSet<>();
        Set<ProtectedArea> canceledAreas = new HashSet<>();
        boolean copyAir = baseSetting.isCopyAir();

        if (baseSetting.isAutoFill() && !copyAir) {
            Block fillBlock = baseSetting.getFillBlock();
            for (Map.Entry<BlockPos, BlockPos> entry : map.entrySet()) {
                BlockPos offsetPos = entry.getValue();
                if (fillBlock != null) {
                    if (isProtected(level, offsetPos, ignoreProtectedArea, canceledAreas)) continue;
                    level.setBlock(offsetPos, fillBlock.defaultBlockState(), Block.UPDATE_CLIENTS);
                    updateBlockToClient(offsetPos, blocksToBeUpdated, canceledAreas);
                }
            }
        }

        for (Map.Entry<BlockPos, BlockPos> entry : map.entrySet()) {
            BlockPos pos = entry.getKey();
            BlockPos offsetPos = entry.getValue();
            BlockState state = level.getBlockState(pos);

            if (!copyAir && state.isAir()) continue;

            if (isProtected(level, offsetPos, ignoreProtectedArea, canceledAreas)) continue;

            level.setBlock(offsetPos, state, Block.UPDATE_CLIENTS);
            BlockEntity oldEntity = level.getBlockEntity(pos);
            if (oldEntity != null) {
                BlockEntity newEntity = level.getBlockEntity(offsetPos);
                if (newEntity != null) {
                    newEntity.load(oldEntity.saveWithoutMetadata());
                }
            }

            updateBlockToClient(offsetPos, blocksToBeUpdated, canceledAreas);
        }

        for (ProtectedArea area : canceledAreas) {
            ProtectedArea.add(level, area, true, false);
        }

        Map<BlockPos, BlockState> updates = blocksToBeUpdated.stream().collect(Collectors.toMap(e -> e, level::getBlockState));
        Network.updateProtectedBlocks(level.players(), updates);
    }

    private void updateBlockToClient(BlockPos pos, Set<BlockPos> blocksToBeUpdated, Set<ProtectedArea> canceledAreas) {
        if (canceledAreas.stream().anyMatch(area -> area.contains(pos))) {
            blocksToBeUpdated.add(pos);
        }
    }

    private boolean isProtected(ServerLevel level, BlockPos pos, boolean ignoreProtectedArea, Set<ProtectedArea> canceledAreas) {
        if (ignoreProtectedArea) {
            ProtectedArea area = ProtectedArea.get(level, pos);
            if (area != null && area.isActive() && !canceledAreas.contains(area)) {
                ProtectedArea.remove(level, pos, false);
                canceledAreas.add(area);
            }
            return false;
        }
        return ProtectedArea.isProtected(level, pos);
    }

    public int compare(ServerLevel level, boolean once) {
        return compareBlocks(level, once) + compareEntities(level, once);
    }

    public int compareBlocks(ServerLevel level, boolean once) {
        GlobeConfig config = GlobeConfig.getInstance();
        BoundingBox targetBox = target.getBoundingBox();
        BlockPos targetMinPos = new BlockPos(targetBox.minX(), targetBox.minY(), targetBox.minZ());
        BoundingBox constructionBox = construction.getBoundingBox();
        BlockPos constructionMinPos = new BlockPos(constructionBox.minX(), constructionBox.minY(), constructionBox.minZ());

        int count = 0;
        start:
        for (BlockPos pos : getTargetAreaBlocks()) {
            if (once && count > 0) return 1;
            BlockPos offsetPos = pos.subtract(targetMinPos).offset(constructionMinPos);
            BlockState state = level.getBlockState(pos);
            BlockState state1 = level.getBlockState(offsetPos);
            if (!state.getBlock().equals(state1.getBlock())) {
                count++;
                continue;
            }
            for (Property<?> property : state.getProperties()) {
                if (config.getExceptAttributes("block", BuiltInRegistries.BLOCK.getKey(state.getBlock())).contains(property.getName())) {
                    count++;
                    continue start;
                }
                if (!state1.hasProperty(property)) {
                    count++;
                    continue start;
                }
                if (!state.getValue(property).equals(state1.getValue(property))) {
                    count++;
                    continue start;
                }
            }
            BlockEntity blockEntity = level.getBlockEntity(pos);
            if (blockEntity != null) {
                BlockEntity blockEntity1 = level.getBlockEntity(offsetPos);
                if (blockEntity1 == null) {
                    count++;
                    continue;
                }
                if (!blockEntity.getType().equals(blockEntity1.getType())) {
                    count++;
                    continue;
                }
                if (Activity.checkSpecialBlockEntity(blockEntity, blockEntity1)) {
                    count++;
                    continue;
                }
                Set<String> except = config.getExceptAttributes("storage", BuiltInRegistries.BLOCK_ENTITY_TYPE.getKey(blockEntity.getType()));
                CompoundTag tag = blockEntity.saveWithoutMetadata();
                except.forEach(tag::remove);
                CompoundTag tag1 = blockEntity1.saveWithoutMetadata();
                except.forEach(tag1::remove);
                if (!tag.equals(tag1)) {
                    count++;
                }
            }
        }
        return count;
    }

    public List<BlockPos> getTargetAreaBlocks() {
        return Util.toBlockPosList(target.getBoundingBox());
    }

    public int compareEntities(ServerLevel level, boolean once) {
        BoundingBox targetBox = target.getBoundingBox();
        BlockPos targetMinPos = new BlockPos(targetBox.minX(), targetBox.minY(), targetBox.minZ());
        BoundingBox constructionBox = construction.getBoundingBox();
        BlockPos constructionMinPos = new BlockPos(constructionBox.minX(), constructionBox.minY(), constructionBox.minZ());

        EntityDetectionMode detectionMode = config.getEntityDetection();
        if (!detectionMode.isActive()) return 0;
        List<Entity> targetEntities = getTargetAreaEntities(level);
        int count = 0;
        start:
        for (Entity entity : targetEntities) {
            if (once && count > 0) return 1;
            BlockPos offsetPos = entity.blockPosition().subtract(targetMinPos).offset(constructionMinPos);
            List<Entity> entities = level.getEntities(entity, new AABB(offsetPos), e -> !(e instanceof Player));
            if (entities.isEmpty()) {
                count++;
                continue;
            }
            for (Entity entity1 : entities) {
                if (!entity1.blockPosition().equals(offsetPos)) {
                    count++;
                    continue start;
                }
                if (!detectionMode.compare(entity, entity1)) {
                    count++;
                    continue start;
                }
            }
        }
        return count;
    }

    /**
     * @return First: differentBlocks, Second: extraBlocks
     */
    public Pair<Set<BlockPos>, Set<BlockPos>> getDifferentAndExtraBlocks(ServerLevel level) {
        GlobeConfig config = GlobeConfig.getInstance();
        BoundingBox targetBox = target.getBoundingBox();
        BlockPos targetMinPos = new BlockPos(targetBox.minX(), targetBox.minY(), targetBox.minZ());
        BoundingBox constructionBox = construction.getBoundingBox();
        BlockPos constructionMinPos = new BlockPos(constructionBox.minX(), constructionBox.minY(), constructionBox.minZ());

        Set<BlockPos> differentBlocks = new HashSet<>();
        Set<BlockPos> extraBlocks = new HashSet<>();

        start:
        for (BlockPos pos : getTargetAreaBlocks()) {
            BlockPos offsetPos = pos.subtract(targetMinPos).offset(constructionMinPos);
            BlockState state = level.getBlockState(pos);
            BlockState state1 = level.getBlockState(offsetPos);

            if (!state.getBlock().equals(state1.getBlock())) {
                if (state.isAir() && !state1.isAir()) {
                    extraBlocks.add(offsetPos);
                } else {
                    differentBlocks.add(offsetPos);
                }
                continue;
            }

            for (Property<?> property : state.getProperties()) {
                if (config.getExceptAttributes("block", BuiltInRegistries.BLOCK.getKey(state.getBlock())).contains(property.getName())) {
                    differentBlocks.add(offsetPos);
                    continue start;
                }
                if (!state1.hasProperty(property)) {
                    differentBlocks.add(offsetPos);
                    continue start;
                }
                if (!state.getValue(property).equals(state1.getValue(property))) {
                    differentBlocks.add(offsetPos);
                    continue start;
                }
            }

            BlockEntity blockEntity = level.getBlockEntity(pos);
            if (blockEntity != null) {
                BlockEntity blockEntity1 = level.getBlockEntity(offsetPos);
                if (blockEntity1 == null) {
                    differentBlocks.add(offsetPos);
                    continue;
                }
                if (!blockEntity.getType().equals(blockEntity1.getType())) {
                    differentBlocks.add(offsetPos);
                    continue;
                }
                if (Activity.checkSpecialBlockEntity(blockEntity, blockEntity1)) {
                    differentBlocks.add(offsetPos);
                    continue;
                }
                Set<String> except = config.getExceptAttributes("storage", BuiltInRegistries.BLOCK_ENTITY_TYPE.getKey(blockEntity.getType()));
                CompoundTag tag = blockEntity.saveWithoutMetadata();
                except.forEach(tag::remove);
                CompoundTag tag1 = blockEntity1.saveWithoutMetadata();
                except.forEach(tag1::remove);
                if (!tag.equals(tag1)) {
                    differentBlocks.add(offsetPos);
                }
            }
        }

        return Pair.of(differentBlocks, extraBlocks);
    }

    public void startResetConstructionAreaTask(ServerLevel level) {
        if (isResettingConstructionArea || isCopying) return;
        isResettingConstructionArea = true;
        level.getServer().execute(() -> {
            resetConstructionArea(level);
            isResettingConstructionArea = false;
        });
    }

    private void resetConstructionArea(ServerLevel level) {
        for (BlockPos pos : getConstructionAreaBlocks()) {
            level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
        }
        getConstructionAreaEntities(level).forEach(Entity::discard);
    }

    public List<BlockPos> getConstructionAreaBlocks() {
        return Util.toBlockPosList(construction.getBoundingBox());
    }

    public void startResetTargetAreaTask(ServerLevel level) {
        if (isResettingTargetArea || isCopying) return;
        isResettingTargetArea = true;
        level.getServer().execute(() -> {
            resetTargetArea(level);
            isResettingTargetArea = false;
        });
    }

    private void resetTargetArea(ServerLevel level) {
        for (BlockPos pos : getTargetAreaBlocks()) {
            level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
        }
        getTargetAreaEntities(level).forEach(Entity::discard);
    }

    public boolean isConstructionAreaEmpty(ServerLevel level) {
        return getConstructionAreaBlocks().stream().allMatch(pos -> level.getBlockState(pos).isAir());
    }

    public List<Entity> getConstructionAreaEntities(Level level, Entity except) {
        return getConstructionAreaEntities(level, except, entity -> !(entity instanceof Player));
    }

    public void sendInfo(Player player) {
        Level level = player.level();
        if (nameCache == null && owner != null) {
            Player ownerPlayer = level.getPlayerByUUID(owner);
            if (ownerPlayer != null) {
                updateName(ownerPlayer.getDisplayName().getString());
            }
        }
        Component ownerText = Component.translatable("area.moddev.owner", nameCache != null ? nameCache : Component.translatable("area.moddev.owner.unknown").getString()).withStyle(style -> {
            if (owner != null) {
                style.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal(owner.toString())));
            }
            return style;
        });
        player.sendSystemMessage(ownerText);
        player.sendSystemMessage(Component.translatable("area.moddev.id", id));
        player.sendSystemMessage(Component.translatable("area.moddev.size", String.format("%d×%d×%d", getBoundingBox().getXSpan(), getBoundingBox().getYSpan(), getBoundingBox().getZSpan())));
        player.sendSystemMessage(Component.translatable("area.moddev.simple_mode." + (config.isSimpleMode() ? "on" : "off")));
        player.sendSystemMessage(Component.translatable("area.moddev.render_border." + (config.isRenderBorder() ? "on" : "off")));
        player.sendSystemMessage(Component.translatable("area.moddev.countdown", config.getCountdown()));
        player.sendSystemMessage(Component.translatable("area.moddev.countdown.text"));

        Map<Integer, String> countdownText = config.getCountdownText();
        for (int i = config.getCountdown(); i >= 0; i--) {
            player.sendSystemMessage(Component.literal(" " + i + " -> " + countdownText.get(i)));
        }
        player.sendSystemMessage(Component.translatable("area.moddev.score.text", config.getScoreText()));
        List<String> forcedPlayers = config.getForcedPlayers().stream().toList();
        if (!forcedPlayers.isEmpty()) {
            player.sendSystemMessage(Component.translatable("area.moddev.forced_players"));
            for (int i = 0; i < forcedPlayers.size(); i++) {
                player.sendSystemMessage(Component.literal(" " + (i + 1) + ") " + forcedPlayers.get(i)));
            }
        }
    }

    public void updateName(String name) {
        if (!name.equals(nameCache)) {
            nameCache = name;
        }
    }

    public static void render(PoseStack stack, int color, Area construction, Area target) {
        RenderUtil.render(stack, color, construction.combine(target).getBox());
        construction.render(stack, Config.getInstance().getConstructionAreaColor());
        target.render(stack, Config.getInstance().getTargetAreaColor());
    }

    public static ActivityArea parseNbt(CompoundTag tag) {
        if (tag.contains("id") && tag.contains("dimension") && tag.contains("construction") && tag.contains("target")) {
            Area construction = Area.fromNbt(tag.getCompound("construction"));
            if (construction != null) {
                Area target = Area.fromNbt(tag.getCompound("target"));
                if (target != null) {
                    ActivityArea activityArea = create(tag.getInt("id"), tag.hasUUID("owner") ? tag.getUUID("owner") : null, tag.getString("dimension"), construction, target, tag.contains("config") ? AreaConfig.fromNbt(tag.getCompound("config")) : null);
                    if (activityArea != null) {
                        if (tag.contains("name")) {
                            activityArea.setNameCache(tag.getString("name"));
                        }
                        if (tag.contains("history")) {
                            ListTag historyTag = tag.getList("history", CompoundTag.TAG_COMPOUND);
                            for (int i = 0; i < historyTag.size(); i++) {
                                activityArea.history.add(ActivityRecord.fromNbt(historyTag.getCompound(i)));
                            }
                            activityArea.sortHistory();
                        }
                    }
                    return activityArea;
                }
            }
        }
        return null;
    }

    public static ActivityArea create(int id, UUID owner, String dimension, Area construction, Area target, AreaConfig config) {
        if (construction.intersects(target)) {
            return null;
        }
        return new ActivityArea(id, owner, dimension, construction.copy(), target.copy(), config != null ? config : new AreaConfig());
    }
}
