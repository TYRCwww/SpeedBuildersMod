package com.modcustom.moddev.items.function;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.AreaSelector;
import com.modcustom.moddev.game.area.Area;
import com.modcustom.moddev.items.AreaSelectionItem;
import com.modcustom.moddev.network.Network;

public class FunctionAreaSelectionItem extends AreaSelectionItem {

    public FunctionAreaSelectionItem(Properties properties) {
        super(properties);
    }

    @Override
    protected AreaSelector getAreaSelector() {
        return ClientGameManager.getInstance().getFunctionAreaSelector();
    }

    @Override
    protected void requestCreateArea(AreaSelector selector) {
        Network.requestCreateFunctionArea(selector.getStart(), selector.getEnd());
    }

    @Override
    public boolean isVisible(Area.Type type) {
        return type == Area.Type.FUNCTION;
    }
}
