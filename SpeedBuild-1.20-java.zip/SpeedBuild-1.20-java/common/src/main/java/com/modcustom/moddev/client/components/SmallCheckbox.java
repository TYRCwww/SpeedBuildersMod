package com.modcustom.moddev.client.components;

import com.modcustom.moddev.SpeedBuild;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.narration.NarratedElementType;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TextColor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

@Environment(EnvType.CLIENT)
public class SmallCheckbox extends AbstractButton {

    private static final ResourceLocation TEXTURE = SpeedBuild.id("textures/gui/small_checkbox.png");
    private static final int TEXTURE_SIZE = 13;
    private final Font font;
    private final boolean showLabel;
    private boolean checked;
    private OnPress onPress;

    public SmallCheckbox(Font font, int x, int y, Component message, boolean checked, OnPress onPress) {
        this(font, x, y, TEXTURE_SIZE + 3 + font.width(message), message, checked, onPress);
    }

    public SmallCheckbox(Font font, int x, int y, int width, Component message, boolean checked, OnPress onPress) {
        this(font, x, y, width, message, checked, true, onPress);
    }

    public SmallCheckbox(Font font, int x, int y, int width, Component message, boolean checked, boolean showLabel, OnPress onPress) {
        super(x, y, width, TEXTURE_SIZE, message);
        this.font = font;
        this.showLabel = showLabel;
        this.checked = checked;
        this.onPress = onPress;
    }

    public void setOnPress(OnPress onPress) {
        this.onPress = onPress;
    }

    @Override
    public void onPress() {
        this.checked = !this.checked;
        if (this.onPress != null) {
            this.onPress.onPress(this, this.checked);
        }
    }

    @Override
    public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        RenderSystem.enableDepthTest();
        guiGraphics.setColor(1.0f, 1.0f, 1.0f, this.alpha);
        RenderSystem.enableBlend();
        guiGraphics.blit(TEXTURE, this.getX(), this.getY(), 0f, 0f, TEXTURE_SIZE, TEXTURE_SIZE, 32, 16);
        if (this.isChecked()) {
            guiGraphics.blit(TEXTURE, this.getX(), this.getY(), 16f, 0f, TEXTURE_SIZE, TEXTURE_SIZE, 32, 16);
        }
        guiGraphics.setColor(1.0f, 1.0f, 1.0f, 1.0f);
        if (this.showLabel) {
            Component message = this.getMessage();
            TextColor textColor = message.getStyle().getColor();
            renderScrollingString(guiGraphics, font, message, this.getX() + TEXTURE_SIZE + 3, this.getY(), this.getX() + this.getWidth(), this.getY() + TEXTURE_SIZE, textColor != null ? textColor.getValue() : 0xE0E0E0 | Mth.ceil(this.alpha * 255.0f) << 24);
        }
    }

    public boolean isChecked() {
        return this.checked;
    }

    @Override
    public void updateWidgetNarration(NarrationElementOutput narrationElementOutput) {
        narrationElementOutput.add(NarratedElementType.TITLE, this.createNarrationMessage());
        if (this.active) {
            if (this.isFocused()) {
                narrationElementOutput.add(NarratedElementType.USAGE, Component.translatable("narration.checkbox.usage.focused"));
            } else {
                narrationElementOutput.add(NarratedElementType.USAGE, Component.translatable("narration.checkbox.usage.hovered"));
            }
        }
    }

    public interface OnPress {

        void onPress(SmallCheckbox widget, boolean checked);
    }
}
