package com.modcustom.moddev.utils;

import it.unimi.dsi.fastutil.Hash;
import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenCustomHashMap;
import net.minecraft.world.item.ItemStack;

public class ItemStackLinkedMap {

    public static final Hash.Strategy<ItemStack> TYPE_AND_TAG = new Hash.Strategy<>() {

        @Override
        public int hashCode(ItemStack stack) {
            return hashStackAndTag(stack);
        }

        @Override
        public boolean equals(ItemStack first, ItemStack second) {
            return first == second || (first != null && second != null && first.isEmpty() == second.isEmpty() && ItemStack.isSameItemSameTags(first, second));
        }
    };

    private static int hashStackAndTag(ItemStack stack) {
        if (stack != null) {
            int i = 31 + stack.getItem().hashCode();
            return 31 * i + (stack.getTag() != null ? stack.getTag().hashCode() : 0);
        }
        return 0;
    }

    public static <T> Object2ObjectLinkedOpenCustomHashMap<ItemStack, T> createTypeAndTagMap() {
        return new Object2ObjectLinkedOpenCustomHashMap<>(TYPE_AND_TAG);
    }
}
