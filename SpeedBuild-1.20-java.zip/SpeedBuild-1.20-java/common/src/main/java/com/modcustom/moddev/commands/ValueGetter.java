package com.modcustom.moddev.commands;

import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;

public interface ValueGetter<T> {

    T get(CommandContext<CommandSourceStack> context);
}
