package com.modcustom.moddev.items.activity;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.events.ClientEventHandler;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.items.AreaVisibleItem;
import com.modcustom.moddev.utils.PlayerUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public class AreaConfigurationItem extends AreaVisibleItem {

    public AreaConfigurationItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext useOnContext) {
        Level level = useOnContext.getLevel();
        if (level.isClientSide()) {
            Direction clickedFace = useOnContext.getClickedFace();
            BlockPos pos = useOnContext.getClickedPos();
            ActivityArea area = ClientGameManager.getInstance().getActivityArea(level, pos, clickedFace);
            if (area != null) {
                ClientEventHandler.openActivityAreaConfigScreen(area);
                return InteractionResult.SUCCESS;
            }
        }
        return super.useOn(useOnContext);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide()) {
            return handleAirRightClick(player, hand);
        }
        return InteractionResultHolder.pass(player.getItemInHand(hand));
    }

    @Override
    public boolean isFoil(ItemStack itemStack) {
        return true;
    }

    private InteractionResultHolder<ItemStack> handleAirRightClick(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        InteractionResultHolder<ItemStack> pass = InteractionResultHolder.pass(stack);
        if (hand != InteractionHand.MAIN_HAND) {
            return pass;
        }
        ActivityArea area = PlayerUtil.findFirstActivityArea(player, 5);
        if (area != null) {
            ClientEventHandler.openActivityAreaConfigScreen(area);
            return InteractionResultHolder.success(stack);
        }
        return pass;
    }
}
