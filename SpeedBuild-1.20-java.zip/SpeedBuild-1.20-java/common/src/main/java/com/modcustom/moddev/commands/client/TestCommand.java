package com.modcustom.moddev.commands.client;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.data.ClientCachedData;
import com.modcustom.moddev.network.Network;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.architectury.event.events.client.ClientCommandRegistrationEvent.ClientCommandSourceStack;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.network.chat.Component;

public class TestCommand extends ClientCommand {

    public TestCommand() {
        super("test");
    }

    @Override
    public LiteralArgumentBuilder<ClientCommandSourceStack> build(LiteralArgumentBuilder<ClientCommandSourceStack> builder, CommandBuildContext context) {
        return builder.executes(ctx -> {
            LocalPlayer player = ctx.getSource().arch$getPlayer();
            if (player == null) {
                return 0;
            }
            ClientCachedData data = ClientGameManager.getInstance().getCachedData();
            if (data.isTestMode()) {
                data.setTestMode(false);
                player.sendSystemMessage(Component.literal("已关闭测试模式"));
            } else {
                data.setTestMode(true);
                player.sendSystemMessage(Component.literal("已开启测试模式"));
            }
            Network.syncPlayerData(player);
            return 1;
        });
    }
}
