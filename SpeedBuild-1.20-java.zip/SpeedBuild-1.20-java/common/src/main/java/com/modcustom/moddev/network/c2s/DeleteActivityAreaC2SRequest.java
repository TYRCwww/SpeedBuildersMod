package com.modcustom.moddev.network.c2s;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.network.Network;
import dev.architectury.networking.NetworkManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;

import java.util.function.Supplier;

public class DeleteActivityAreaC2SRequest implements NetworkPacket {

    private final int id;

    public DeleteActivityAreaC2SRequest(FriendlyByteBuf buf) {
        this(buf.readInt());
    }

    public DeleteActivityAreaC2SRequest(int id) {
        this.id = id;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(id);
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        if (contextSupplier.get().getPlayer() instanceof ServerPlayer player) {
            GameData gameData = GameData.getGameData(player);
            gameData.removeActivityArea(id);
            Network.updateActivityAreasForAll(player.server);
        }
    }
}
