package com.modcustom.moddev.network.c2s;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.network.Network;
import dev.architectury.networking.NetworkManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;

import java.util.function.Supplier;

public class RequestSyncC2SPacket implements NetworkPacket {

    private final Type type;

    public RequestSyncC2SPacket(FriendlyByteBuf buf) {
        this(buf.readEnum(Type.class));
    }

    public RequestSyncC2SPacket(Type type) {
        this.type = type;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeEnum(type);
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        type.apply(contextSupplier);
    }

    public enum Type {
        ACTIVITY_AREAS {
            @Override
            public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
                if (contextSupplier.get().getPlayer() instanceof ServerPlayer player) {
                    Network.updateActivityAreas(player);
                }
            }
        },
        PROTECTED_AREAS {
            @Override
            public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
                if (contextSupplier.get().getPlayer() instanceof ServerPlayer player) {
                    Network.updateProtectedAreas(player);
                }
            }
        },
        FUNCTION_AREAS {
            @Override
            public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
                if (contextSupplier.get().getPlayer() instanceof ServerPlayer player) {
                    Network.updateFunctionAreas(player);
                }
            }
        },
        PLAYER_DATA {
            @Override
            public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
                if (contextSupplier.get().getPlayer() instanceof ServerPlayer player) {
                    Network.syncPlayerData(player);
                }
            }
        },
        ALL {
            @Override
            public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
                for (Type type : Type.values()) {
                    if (type != this) {
                        type.apply(contextSupplier);
                    }
                }
            }
        };

        public abstract void apply(Supplier<NetworkManager.PacketContext> contextSupplier);
    }
}
