package com.modcustom.moddev.mixin;

import net.minecraft.world.level.GameType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameType.class)
public class GameTypeMixin {

    @Inject(method = "isBlockPlacingRestricted", at = @At("HEAD"), cancellable = true)
    public void speed_build$isBlockPlacingRestricted(CallbackInfoReturnable<Boolean> cir) {
        GameType gameType = (GameType) (Object) this;
        if (gameType == GameType.ADVENTURE) {
            cir.setReturnValue(false);
        }
    }
}
