package com.modcustom.moddev.commands.common;

import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.network.Network;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.selector.EntitySelector;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.Set;
import java.util.stream.Collectors;

public class ZXCommand extends CommonCommand {

    public ZXCommand() {
        super("zx");
    }

    @Override
    public LiteralArgumentBuilder<CommandSourceStack> build(LiteralArgumentBuilder<CommandSourceStack> builder, CommandBuildContext context) {
        return builder.requires(source -> source.hasPermission(2)).then(Commands.literal("add").then(executeTargetSelector(true))).then(Commands.literal("remove").then(executeTargetSelector(false)));
    }

    private RequiredArgumentBuilder<CommandSourceStack, EntitySelector> executeTargetSelector(boolean add) {
        return Commands.argument("players", EntityArgument.players()).executes(context -> {
            Set<String> players = EntityArgument.getPlayers(context, "players").stream().map(Entity::getDisplayName).map(Component::getString).collect(Collectors.toSet());

            CommandSourceStack source = context.getSource();
            ServerLevel level = source.getLevel();
            Vec3 pos = source.getPosition();

            ActivityArea area = GameData.getGameData(context).getNearestActivityArea(level, pos, 15);

            if (area != null) {
                if (add) {
                    area.getConfig().getForcedPlayers().addAll(players);
                } else {
                    area.getConfig().getForcedPlayers().removeAll(players);
                }
                Network.updateAreaConfig(source.getServer(), area);
            }
            return 1;
        });
    }
}
