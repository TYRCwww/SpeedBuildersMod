package com.modcustom.moddev.commands.common;

import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.utils.TranslationUtil;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.selector.EntitySelector;
import net.minecraft.core.Vec3i;
import net.minecraft.server.level.ServerPlayer;

import java.util.Collection;

public class DXCommand extends CommonCommand {

    public DXCommand() {
        super("dx");
    }

    @Override
    public LiteralArgumentBuilder<CommandSourceStack> build(LiteralArgumentBuilder<CommandSourceStack> builder, CommandBuildContext context) {
        return builder.requires(source -> source.hasPermission(2)).then(executeSetDefaultSizeLimit()).then(executeSetSizeLimit());
    }

    private RequiredArgumentBuilder<CommandSourceStack, Integer> executeSetDefaultSizeLimit() {
        return Commands.argument("x", IntegerArgumentType.integer(0)).then(Commands.argument("y", IntegerArgumentType.integer(0)).then(Commands.argument("z", IntegerArgumentType.integer(0)).executes(context -> {
            int x = IntegerArgumentType.getInteger(context, "x");
            int y = IntegerArgumentType.getInteger(context, "y");
            int z = IntegerArgumentType.getInteger(context, "z");
            Vec3i size = new Vec3i(x, y, z);
            GameData.getGameData(context).setDefaultSizeLimit(size);
            context.getSource().getLevel().players().forEach(player -> {
                player.sendSystemMessage(TranslationUtil.messageComponent(String.format("%d×%d×%d", size.getX(), size.getY(), size.getZ())));
            });
            return 1;
        })));
    }

    private RequiredArgumentBuilder<CommandSourceStack, EntitySelector> executeSetSizeLimit() {
        return Commands.argument("players", EntityArgument.players()).then(Commands.argument("x", IntegerArgumentType.integer(0)).then(Commands.argument("y", IntegerArgumentType.integer(0)).then(Commands.argument("z", IntegerArgumentType.integer(0)).executes(context -> {
            Collection<ServerPlayer> players = EntityArgument.getPlayers(context, "players");
            int x = IntegerArgumentType.getInteger(context, "x");
            int y = IntegerArgumentType.getInteger(context, "y");
            int z = IntegerArgumentType.getInteger(context, "z");
            GameData gameData = GameData.getGameData(context);
            Vec3i size = new Vec3i(x, y, z);
            players.forEach(player -> {
                gameData.setSizeLimit(player, size);
                player.sendSystemMessage(TranslationUtil.messageComponent(String.format("%d×%d×%d", size.getX(), size.getY(), size.getZ())));
            });
            return 1;
        }))));
    }
}
