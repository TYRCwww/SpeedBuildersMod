package com.modcustom.moddev.game.data;

import com.modcustom.moddev.api.SerializableData;
import com.modcustom.moddev.game.AreaFinder;
import com.modcustom.moddev.game.SoundSetting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;

public class ClientCachedData implements SerializableData<ClientCachedData> {

    private final SoundSetting jumpSound = new SoundSetting(SoundEvents.BLAZE_SHOOT);
    private int extraJump = 1;
    private double extraJumpPower = 1.0;
    private boolean extraJumpEnabled = true;
    private boolean testMode = false;
    private AreaFinder areaFinder = AreaFinder.POSITION;
    private boolean overlappingProtectedAreas = false;
    private boolean jumpMovementLimit = true;
    private int timerErrorCorrection = 0;
    private boolean jumpingParticles = true;

    @Override
    public void save(CompoundTag tag) {
        tag.putInt("extraJump", extraJump);
        tag.putDouble("extraJumpPower", extraJumpPower);
        tag.put("jumpSound", jumpSound.toNbt());
        tag.putBoolean("extraJumpEnabled", extraJumpEnabled);
        tag.putBoolean("testMode", testMode);
        tag.putInt("areaFinder", areaFinder.ordinal());
        tag.putBoolean("overlappingProtectedAreas", overlappingProtectedAreas);
        tag.putBoolean("jumpMovementLimit", jumpMovementLimit);
        tag.putInt("timerErrorCorrection", timerErrorCorrection);
        tag.putBoolean("jumpingParticles", jumpingParticles);
    }

    @Override
    public void load(CompoundTag tag) {
        if (tag.contains("extraJump")) {
            setExtraJump(tag.getInt("extraJump"));
        }
        if (tag.contains("extraJumpPower")) {
            setExtraJumpPower(tag.getDouble("extraJumpPower"));
        }
        if (tag.contains("jumpSound")) {
            jumpSound.readNbt(tag.getCompound("jumpSound"));
        }
        if (tag.contains("extraJumpEnabled")) {
            setExtraJumpEnabled(tag.getBoolean("extraJumpEnabled"));
        }
        if (tag.contains("testMode")) {
            setTestMode(tag.getBoolean("testMode"));
        }
        if (tag.contains("areaFinder")) {
            int ordinal = tag.getInt("areaFinder");
            if (ordinal >= 0 && ordinal < AreaFinder.values().length) {
                setAreaFinder(AreaFinder.values()[ordinal]);
            }
        }
        if (tag.contains("overlappingProtectedAreas")) {
            setOverlappingProtectedAreas(tag.getBoolean("overlappingProtectedAreas"));
        }
        if (tag.contains("jumpMovementLimit")) {
            setJumpMovementLimit(tag.getBoolean("jumpMovementLimit"));
        }
        if (tag.contains("timerErrorCorrection")) {
            setTimerErrorCorrection(tag.getInt("timerErrorCorrection"));
        }
        if (tag.contains("jumpingParticles")) {
            setJumpingParticles(tag.getBoolean("jumpingParticles"));
        }
    }

    @Override
    public void copyFrom(ClientCachedData data) {
        this.extraJump = data.extraJump;
        this.extraJumpPower = data.extraJumpPower;
        this.jumpSound.copyFrom(data.jumpSound);
        this.extraJumpEnabled = data.extraJumpEnabled;
        this.testMode = data.testMode;
        this.areaFinder = data.areaFinder;
        this.overlappingProtectedAreas = data.overlappingProtectedAreas;
        this.jumpMovementLimit = data.jumpMovementLimit;
        this.timerErrorCorrection = data.timerErrorCorrection;
        this.jumpingParticles = data.jumpingParticles;
    }

    public int getExtraJump() {
        return extraJump;
    }

    public void setExtraJump(int extraJump) {
        this.extraJump = Math.max(extraJump, 0);
    }

    public double getExtraJumpPower() {
        return extraJumpPower;
    }

    public void setExtraJumpPower(double extraJumpPower) {
        this.extraJumpPower = Math.min(Math.max(extraJumpPower, 0.0), 2.0);
    }

    public SoundSetting getJumpSound() {
        return jumpSound;
    }

    public boolean isExtraJumpEnabled() {
        return extraJumpEnabled;
    }

    public void setExtraJumpEnabled(boolean extraJumpEnabled) {
        this.extraJumpEnabled = extraJumpEnabled;
    }

    public boolean isTestMode() {
        return testMode;
    }

    public void setTestMode(boolean testMode) {
        this.testMode = testMode;
    }

    public AreaFinder getAreaFinder() {
        return areaFinder;
    }

    public void setAreaFinder(AreaFinder areaFinder) {
        this.areaFinder = areaFinder;
    }

    public boolean isOverlappingProtectedAreas() {
        return overlappingProtectedAreas;
    }

    public void setOverlappingProtectedAreas(boolean overlappingProtectedAreas) {
        this.overlappingProtectedAreas = overlappingProtectedAreas;
    }

    public boolean isJumpMovementLimit() {
        return jumpMovementLimit;
    }

    public void setJumpMovementLimit(boolean jumpMovementLimit) {
        this.jumpMovementLimit = jumpMovementLimit;
    }

    public int getTimerErrorCorrection() {
        return timerErrorCorrection;
    }

    public void setTimerErrorCorrection(int timerErrorCorrection) {
        this.timerErrorCorrection = timerErrorCorrection;
    }

    public void setJumpingParticles(boolean jumpingParticles) {
        this.jumpingParticles = jumpingParticles;
    }

    public boolean hasJumpingParticles() {
        return jumpingParticles;
    }

    @Override
    public String toString() {
        return String.format(
                "ClientCachedData(" +
                "extraJump: %d, " +
                "extraJumpPower: %.2f, " +
                "jumpSound: %s, " +
                "extraJumpEnabled: %b, " +
                "testMode: %b, " +
                "areaFinder: %s, " +
                "overlappingProtectedAreas: %b, " +
                "jumpMovementLimit: %b, " +
                "timerErrorCorrection: %d)" +
                "jumpingParticles: %b",
                extraJump,
                extraJumpPower,
                jumpSound,
                extraJumpEnabled,
                testMode,
                areaFinder.getComponent().getString(),
                overlappingProtectedAreas,
                jumpMovementLimit,
                timerErrorCorrection,
                jumpingParticles
        );
    }

    public static ClientCachedData get(ServerPlayer player) {
        return PlayerData.get(player).getClientCachedData();
    }

    public static void set(ServerPlayer player, ClientCachedData value) {
        PlayerData.get(player).readData(value);
    }
}
