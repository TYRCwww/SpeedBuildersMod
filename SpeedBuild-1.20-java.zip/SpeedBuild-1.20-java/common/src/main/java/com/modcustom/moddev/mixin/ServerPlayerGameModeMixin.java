package com.modcustom.moddev.mixin;

import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.utils.TranslationUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerPlayerGameMode;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.SlabType;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ServerPlayerGameMode.class)
public abstract class ServerPlayerGameModeMixin {

    @Shadow
    protected ServerLevel level;
    @Shadow
    @Final
    protected ServerPlayer player;
    @Shadow
    private GameType gameModeForPlayer;
    @Unique
    private ItemStack speedBuild$cachedStack;

    @Inject(method = "handleBlockBreakAction", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayerGameMode;isCreative()Z"), cancellable = true)
    public void speed_build$handleBlockBreakAction(BlockPos blockPos, ServerboundPlayerActionPacket.Action action, Direction direction, int i, int j, CallbackInfo ci) {
        if (this.gameModeForPlayer == GameType.ADVENTURE && GameData.getGameData(level).getActivityArea(level, blockPos, area -> true) != null) {
            BlockState state = level.getBlockState(blockPos);
            speedBuild$cachedStack = state.getBlock().getCloneItemStack(level, blockPos, state);
            if (state.hasProperty(SlabBlock.TYPE) && state.getValue(SlabBlock.TYPE) == SlabType.DOUBLE) {
                speedBuild$cachedStack.grow(1);
            }
            this.destroyAndAck(blockPos, j, "adventure destroy in area");
            speedBuild$cachedStack = null;
            ci.cancel();
        }
    }

    @Shadow
    public abstract void destroyAndAck(BlockPos arg, int i, String string);

    @Inject(method = "destroyBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayerGameMode;isCreative()Z"), cancellable = true)
    public void speed_build$handleDestroyBlock(BlockPos blockPos, CallbackInfoReturnable<Boolean> cir) {
        if (this.gameModeForPlayer == GameType.ADVENTURE && GameData.getGameData(level).getActivityArea(level, blockPos, area -> true) != null) {
            BlockState state = level.getBlockState(blockPos);
            ItemStack stack = state.getBlock().getCloneItemStack(level, blockPos, state);
            if (stack.isEmpty() && speedBuild$cachedStack != null && !speedBuild$cachedStack.isEmpty()) {
                stack = speedBuild$cachedStack;
            }
            speed_build$removeBlock(blockPos);
            Item item = stack.getItem();
            level.getEntitiesOfClass(ItemEntity.class, new AABB(blockPos).deflate(3), entity -> entity.getItem().is(item) && entity.getAge() == 0).forEach(Entity::discard);
            if (!stack.isEmpty() && !player.getInventory().add(stack)) {
                player.sendSystemMessage(TranslationUtil.messageComponent("inventory_full"));
                Block.popResource(level, blockPos, stack);
            }
            cir.setReturnValue(true);
        }
    }

    @Unique
    private void speed_build$removeBlock(BlockPos blockPos) {
        BlockState state = level.getBlockState(blockPos);
        Block block = state.getBlock();
        block.playerWillDestroy(this.level, blockPos, state, this.player);
        boolean bl = this.level.removeBlock(blockPos, false);
        if (bl) {
            block.destroy(this.level, blockPos, state);
        }
    }
}
