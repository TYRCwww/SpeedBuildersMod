package com.modcustom.moddev.commands.common;

import com.modcustom.moddev.arguments.AxisOrderArgument;
import com.modcustom.moddev.commands.ValueGetter;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.game.data.ItemGivingData;
import com.modcustom.moddev.network.Network;
import com.modcustom.moddev.utils.AxisOrder;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.commands.arguments.item.ItemArgument;
import net.minecraft.core.Direction;
import net.minecraft.core.GlobalPos;
import net.minecraft.world.item.ItemStack;

import java.util.Arrays;

import static com.modcustom.moddev.utils.TranslationUtil.messageComponent;

public class GiveCommand extends CommonCommand {

    private static final String NEAREST_COMMAND = "nearby";

    public GiveCommand() {
        super("give");
    }

    @Override
    public LiteralArgumentBuilder<CommandSourceStack> build(LiteralArgumentBuilder<CommandSourceStack> builder, CommandBuildContext context) {
        return builder.then(executeAdd(context)).then(executeRemove(context)).then(executeOpen()).then(executeScanOrder());
    }

    private LiteralArgumentBuilder<CommandSourceStack> executeAdd(CommandBuildContext context) {
        return Commands.literal("add")
                       .then(Commands.argument("item", ItemArgument.item(context))
                                     .then(Commands.argument("count", IntegerArgumentType.integer(1))
                                                   .then(Commands.argument("area", IntegerArgumentType.integer(0))
                                                                 .executes(ctx -> executeAddItem(ctx, this::getItem, this::getArea, this::getCount))
                                                   )
                                                   .then(Commands.literal(NEAREST_COMMAND)
                                                                 .executes(ctx -> executeAddItem(ctx, this::getItem, this::getNearestArea, this::getCount))
                                                   )
                                     )
                       )
                       .then(Commands.argument("pos", BlockPosArgument.blockPos())
                                     .then(Commands.argument("count", IntegerArgumentType.integer(1))
                                                   .then(Commands.argument("area", IntegerArgumentType.integer(0))
                                                                 .executes(ctx -> executeAddPos(ctx, this::getPos, this::getArea, this::getCount))
                                                   )
                                                   .then(Commands.literal(NEAREST_COMMAND)
                                                                 .executes(ctx -> executeAddPos(ctx, this::getPos, this::getNearestArea, this::getCount))
                                                   )
                                     )
                       );
    }

    private int executeAddItem(CommandContext<CommandSourceStack> context, ValueGetter<ItemStack> itemGetter, ValueGetter<ActivityArea> areaGetter, ValueGetter<Integer> countGetter) {
        ItemStack item = itemGetter.get(context);
        Integer count = countGetter.get(context);
        CommandSourceStack source = context.getSource();
        ActivityArea area = areaGetter.get(context);
        if (area != null) {
            area.getConfig().getItemGivingData().addItem(item, count != null ? count : 1);
            Network.updateAreaConfig(source.getServer(), area);
            source.sendSuccess(() -> messageComponent("add_item", count != null ? count : 1, item.getHoverName().getString()), true);
            return 1;
        } else {
            sendFailureWithNoAreaFound(source);
            return 0;
        }
    }

    private LiteralArgumentBuilder<CommandSourceStack> executeRemove(CommandBuildContext context) {
        return Commands.literal("remove")
                       .then(Commands.argument("item", ItemArgument.item(context))
                                     .then(Commands.argument("count", IntegerArgumentType.integer(1))
                                                   .then(Commands.argument("area", IntegerArgumentType.integer(0))
                                                                 .executes(ctx -> executeRemoveItem(ctx, this::getItem, this::getArea, this::getCount))
                                                   )
                                                   .then(Commands.literal(NEAREST_COMMAND)
                                                                 .executes(ctx -> executeRemoveItem(ctx, this::getItem, this::getNearestArea, this::getCount))
                                                   )
                                     )
                                     .then(Commands.argument("area", IntegerArgumentType.integer(0))
                                                   .executes(ctx -> executeRemoveItem(ctx, this::getItem, this::getArea, count -> null))
                                     )
                                     .then(Commands.literal(NEAREST_COMMAND)
                                                   .executes(ctx -> executeRemoveItem(ctx, this::getItem, this::getNearestArea, count -> null))
                                     )
                       )
                       .then(Commands.argument("pos", BlockPosArgument.blockPos())
                                     .then(Commands.argument("count", IntegerArgumentType.integer(1))
                                                   .then(Commands.argument("area", IntegerArgumentType.integer(0))
                                                                 .executes(ctx -> executeRemovePos(ctx, this::getPos, this::getArea, this::getCount))
                                                   )
                                                   .then(Commands.literal(NEAREST_COMMAND)
                                                                 .executes(ctx -> executeRemovePos(ctx, this::getPos, this::getNearestArea, this::getCount))
                                                   )
                                     )
                                     .then(Commands.argument("area", IntegerArgumentType.integer(0))
                                                   .executes(ctx -> executeRemovePos(ctx, this::getPos, this::getArea, count -> null))
                                     )
                                     .then(Commands.literal(NEAREST_COMMAND)
                                                   .executes(ctx -> executeRemovePos(ctx, this::getPos, this::getNearestArea, count -> null))
                                     )
                       )
                       .then(Commands.literal("all")
                                     .then(Commands.argument("area", IntegerArgumentType.integer(0))
                                                   .executes(ctx -> executeRemoveAll(ctx, this::getArea))
                                     )
                                     .then(Commands.literal(NEAREST_COMMAND)
                                                   .executes(ctx -> executeRemoveAll(ctx, this::getNearestArea))
                                     )
                       );
    }

    private ItemStack getItem(CommandContext<CommandSourceStack> context) {
        try {
            return ItemArgument.getItem(context, "item").createItemStack(1, false);
        } catch (CommandSyntaxException e) {
            throw new RuntimeException(e);
        }
    }

    private ActivityArea getArea(CommandContext<CommandSourceStack> context) {
        return GameData.getGameData(context).getActivityArea(IntegerArgumentType.getInteger(context, "area"));
    }

    private Integer getCount(CommandContext<CommandSourceStack> context) {
        return IntegerArgumentType.getInteger(context, "count");
    }

    private ActivityArea getNearestArea(CommandContext<CommandSourceStack> context) {
        return GameData.getGameData(context).getNearestActivityArea(context.getSource().getLevel(), context.getSource().getPosition(), 15);
    }

    private int executeAddPos(CommandContext<CommandSourceStack> context, ValueGetter<GlobalPos> posGetter, ValueGetter<ActivityArea> areaGetter, ValueGetter<Integer> countGetter) {
        GlobalPos pos = posGetter.get(context);
        Integer count = countGetter.get(context);
        CommandSourceStack source = context.getSource();
        ActivityArea area = areaGetter.get(context);
        if (area != null) {
            area.getConfig().getItemGivingData().addPosition(pos, count != null ? count : 1);
            Network.updateAreaConfig(source.getServer(), area);
            source.sendSuccess(() -> messageComponent("add_pos", pos.pos().toShortString(), count != null ? count : 1), true);
            return 1;
        } else {
            sendFailureWithNoAreaFound(source);
            return 0;
        }
    }

    private GlobalPos getPos(CommandContext<CommandSourceStack> context) {
        return GlobalPos.of(context.getSource().getLevel().dimension(), BlockPosArgument.getBlockPos(context, "pos"));
    }

    private LiteralArgumentBuilder<CommandSourceStack> executeOpen() {
        return Commands.literal("open")
                       .then(Commands.argument("area", IntegerArgumentType.integer(0))
                                     .then(Commands.literal("custom")
                                                   .executes(context -> executeSetMode(context, this::getArea, ItemGivingData.Mode.CUSTOM))
                                     )
                                     .then(Commands.literal("scanning")
                                                   .executes(context -> executeSetMode(context, this::getArea, ItemGivingData.Mode.SCANNING))
                                     )
                       )
                       .then(Commands.literal(NEAREST_COMMAND)
                                     .then(Commands.literal("custom")
                                                   .executes(context -> executeSetMode(context, this::getNearestArea, ItemGivingData.Mode.CUSTOM))
                                     )
                                     .then(Commands.literal("scanning")
                                                   .executes(context -> executeSetMode(context, this::getNearestArea, ItemGivingData.Mode.SCANNING))
                                     )
                       );
    }

    private int executeRemoveItem(CommandContext<CommandSourceStack> context, ValueGetter<ItemStack> itemGetter, ValueGetter<ActivityArea> areaGetter, ValueGetter<Integer> countGetter) {
        ItemStack item = itemGetter.get(context);
        Integer count = countGetter.get(context);
        CommandSourceStack source = context.getSource();
        ActivityArea area = areaGetter.get(context);
        if (area != null) {
            area.getConfig().getItemGivingData().removeItem(item, count);
            Network.updateAreaConfig(source.getServer(), area);
            if (count != null) {
                source.sendSuccess(() -> messageComponent("remove_item", count, item.getHoverName().getString()), true);
            } else {
                source.sendSuccess(() -> messageComponent("remove_all_item", item.getHoverName().getString()), true);
            }
            return 1;
        } else {
            sendFailureWithNoAreaFound(source);
            return 0;
        }
    }

    private int executeRemovePos(CommandContext<CommandSourceStack> context, ValueGetter<GlobalPos> posGetter, ValueGetter<ActivityArea> areaGetter, ValueGetter<Integer> countGetter) {
        GlobalPos pos = posGetter.get(context);
        Integer count = countGetter.get(context);
        CommandSourceStack source = context.getSource();
        ActivityArea area = areaGetter.get(context);
        if (area != null) {
            area.getConfig().getItemGivingData().removePosition(pos, count);
            Network.updateAreaConfig(source.getServer(), area);
            if (count != null) {
                source.sendSuccess(() -> messageComponent("remove_pos", count, pos.pos().toShortString()), true);
            } else {
                source.sendSuccess(() -> messageComponent("remove_all_pos", pos.pos().toShortString()), true);
            }
            return 1;
        } else {
            sendFailureWithNoAreaFound(source);
            return 0;
        }
    }

    private int executeRemoveAll(CommandContext<CommandSourceStack> context, ValueGetter<ActivityArea> areaGetter) {
        CommandSourceStack source = context.getSource();
        ActivityArea area = areaGetter.get(context);
        if (area != null) {
            area.getConfig().getItemGivingData().removeAll();
            Network.updateAreaConfig(source.getServer(), area);
            source.sendSuccess(() -> messageComponent("remove_all"), true);
            return 1;
        } else {
            sendFailureWithNoAreaFound(source);
            return 0;
        }
    }

    private LiteralArgumentBuilder<CommandSourceStack> executeScanOrder() {
        return Commands.literal("order")
                       .then(Commands.argument("area", IntegerArgumentType.integer(0))
                                     .then(Commands.argument("order", AxisOrderArgument.order())
                                                   .suggests((context, builder) -> SharedSuggestionProvider.suggest(Arrays.stream(AxisOrder.values()).map(AxisOrder::toString), builder))
                                                   .executes(context -> executeSetScanOrder(context, this::getArea, this::getOrder))
                                     )
                                     .then(Commands.literal("x")
                                                   .then(Commands.literal("descending")
                                                                 .executes(context -> executeSetAxisOrder(context, this::getArea, Direction.Axis.X, true))
                                                   )
                                                   .then(Commands.literal("ascending")
                                                                 .executes(context -> executeSetAxisOrder(context, this::getArea, Direction.Axis.X, false))
                                                   )
                                     )
                                     .then(Commands.literal("y")
                                                   .then(Commands.literal("descending")
                                                                 .executes(context -> executeSetAxisOrder(context, this::getArea, Direction.Axis.Y, true))
                                                   )
                                                   .then(Commands.literal("ascending")
                                                                 .executes(context -> executeSetAxisOrder(context, this::getArea, Direction.Axis.Y, false))
                                                   )
                                     )
                                     .then(Commands.literal("z")
                                                   .then(Commands.literal("descending")
                                                                 .executes(context -> executeSetAxisOrder(context, this::getArea, Direction.Axis.Z, true))
                                                   )
                                                   .then(Commands.literal("ascending")
                                                                 .executes(context -> executeSetAxisOrder(context, this::getArea, Direction.Axis.Z, false))
                                                   )
                                     )
                       )
                       .then(Commands.literal(NEAREST_COMMAND)
                                     .then(Commands.argument("order", AxisOrderArgument.order())
                                                   .suggests((context, builder) -> SharedSuggestionProvider.suggest(Arrays.stream(AxisOrder.values()).map(AxisOrder::toString), builder))
                                                   .executes(context -> executeSetScanOrder(context, this::getNearestArea, this::getOrder))
                                     )
                                     .then(Commands.literal("x")
                                                   .then(Commands.literal("descending")
                                                                 .executes(context -> executeSetAxisOrder(context, this::getNearestArea, Direction.Axis.X, true))
                                                   )
                                                   .then(Commands.literal("ascending")
                                                                 .executes(context -> executeSetAxisOrder(context, this::getNearestArea, Direction.Axis.X, false))
                                                   )
                                     )
                                     .then(Commands.literal("y")
                                                   .then(Commands.literal("descending")
                                                                 .executes(context -> executeSetAxisOrder(context, this::getNearestArea, Direction.Axis.Y, true))
                                                   )
                                                   .then(Commands.literal("ascending")
                                                                 .executes(context -> executeSetAxisOrder(context, this::getNearestArea, Direction.Axis.Y, false))
                                                   )
                                     )
                                     .then(Commands.literal("z")
                                                   .then(Commands.literal("descending")
                                                                 .executes(context -> executeSetAxisOrder(context, this::getNearestArea, Direction.Axis.Z, true))
                                                   )
                                                   .then(Commands.literal("ascending")
                                                                 .executes(context -> executeSetAxisOrder(context, this::getNearestArea, Direction.Axis.Z, false))
                                                   )
                                     )
                       );
    }

    private int executeSetMode(CommandContext<CommandSourceStack> context, ValueGetter<ActivityArea> areaGetter, ItemGivingData.Mode mode) {
        CommandSourceStack source = context.getSource();
        ActivityArea area = areaGetter.get(context);
        if (area != null) {
            area.getConfig().getItemGivingData().setMode(mode);
            Network.updateAreaConfig(source.getServer(), area);
            source.sendSuccess(() -> messageComponent("item_giving.set_mode", mode.component.getString()), true);
            return 1;
        } else {
            sendFailureWithNoAreaFound(source);
            return 0;
        }
    }

    private AxisOrder getOrder(CommandContext<CommandSourceStack> ctx) {
        return AxisOrderArgument.getOrder(ctx, "order");
    }

    private static void sendFailureWithNoAreaFound(CommandSourceStack source) {
        source.sendFailure(messageComponent("area_not_found"));
    }

    private int executeSetScanOrder(CommandContext<CommandSourceStack> context, ValueGetter<ActivityArea> areaGetter, ValueGetter<AxisOrder> orderGetter) {
        CommandSourceStack source = context.getSource();
        ActivityArea area = areaGetter.get(context);
        if (area != null) {
            AxisOrder order = orderGetter.get(context);
            if (order == null) {
                source.sendFailure(messageComponent("unknown_order"));
                return 0;
            }
            area.getConfig().getItemGivingData().getScanOrder().setOrder(order);
            Network.updateAreaConfig(source.getServer(), area);
            source.sendSuccess(() -> messageComponent("item_giving.set_scan_order", order.toString()), true);
            return 1;
        } else {
            sendFailureWithNoAreaFound(source);
            return 0;
        }
    }

    private int executeSetAxisOrder(CommandContext<CommandSourceStack> context, ValueGetter<ActivityArea> areaGetter, Direction.Axis axis, boolean descending) {
        CommandSourceStack source = context.getSource();
        ActivityArea area = areaGetter.get(context);
        if (area != null) {
            area.getConfig().getItemGivingData().getScanOrder().setDescending(axis, descending);
            Network.updateAreaConfig(source.getServer(), area);
            source.sendSuccess(() -> messageComponent("item_giving.set_axis_order." + (descending ? "descending" : "ascending"), axis.name()), true);
            return 1;
        } else {
            sendFailureWithNoAreaFound(source);
            return 0;
        }
    }
}
