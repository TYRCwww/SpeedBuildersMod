package com.modcustom.moddev.events;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.commands.Command;
import com.modcustom.moddev.commands.client.ClientCommand;
import com.modcustom.moddev.game.activity.ActivityManager;

public class ModEventRegister {

    public static void register() {
        Command.register();
        InteractionEventHandler.register();
        PlayerEventHandler.register();
        JumpEventHandler.register();
        ActivityManager.register();
        BlockEventHandler.register();
        EntityEventHandler.register();
    }

    public static void registerClient() {
        ClientGameManager.register();
        ClientCommand.registerClient();
        ClientEventHandler.registerClient();
        ActivityManager.registerClient();
    }
}
