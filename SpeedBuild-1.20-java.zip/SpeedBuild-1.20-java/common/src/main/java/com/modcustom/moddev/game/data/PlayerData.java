package com.modcustom.moddev.game.data;

import com.modcustom.moddev.api.SerializableData;
import com.modcustom.moddev.game.area.ActivityArea;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.List;

public class PlayerData implements SerializableData<PlayerData> {

    private final List<ActivityArea> areas = new ArrayList<>();
    private final ClientCachedData clientCachedData = new ClientCachedData();
    private Vec3i sizeLimit;
    private boolean createLimit = true;
    private int jumpCount = 0;
    private boolean noCreativeItemLimitedTip = false;

    public PlayerData(Vec3i defaultSizeLimit) {
        this.sizeLimit = defaultSizeLimit;
    }

    @Override
    public void save(CompoundTag tag) {
        tag.put("sizeLimit", NbtUtils.writeBlockPos(new BlockPos(sizeLimit)));
        ListTag areasTag = new ListTag();
        for (ActivityArea area : areas) {
            areasTag.add(area.toNbt());
        }
        tag.put("areas", areasTag);
        tag.putBoolean("createLimit", createLimit);
        tag.putInt("jumpCount", jumpCount);
        tag.put("clientCachedData", clientCachedData.toNbt());
        tag.putBoolean("noCreativeItemLimitedTip", noCreativeItemLimitedTip);
    }

    @Override
    public void load(CompoundTag tag) {
        if (tag.contains("sizeLimit")) {
            this.sizeLimit = NbtUtils.readBlockPos(tag.getCompound("sizeLimit"));
        }
        if (tag.contains("areas")) {
            ListTag areasTag = tag.getList("areas", Tag.TAG_COMPOUND);
            for (int index = 0; index < areasTag.size(); index++) {
                ActivityArea area = ActivityArea.parseNbt(areasTag.getCompound(index));
                if (area != null) {
                    this.areas.add(area);
                }
            }
        }
        if (tag.contains("createLimit")) {
            this.createLimit = tag.getBoolean("createLimit");
        }
        if (tag.contains("jumpCount")) {
            this.jumpCount = tag.getInt("jumpCount");
        }
        if (tag.contains("clientCachedData")) {
            this.clientCachedData.load(tag.getCompound("clientCachedData"));
        } else {
            this.clientCachedData.load(tag);
        }
        if (tag.contains("noCreativeItemLimitedTip")) {
            this.noCreativeItemLimitedTip = tag.getBoolean("noCreativeItemLimitedTip");
        }
    }

    @Override
    public void copyFrom(PlayerData data) {
        this.areas.clear();
        this.areas.addAll(data.areas);
        this.clientCachedData.copyFrom(data.clientCachedData);
        this.sizeLimit = data.sizeLimit;
        this.createLimit = data.createLimit;
        this.jumpCount = data.jumpCount;
        this.noCreativeItemLimitedTip = data.noCreativeItemLimitedTip;
    }

    public void readData(ClientCachedData data) {
        clientCachedData.copyFrom(data);
    }

    @Override
    public String toString() {
        return String.format(
                "PlayerData(sizeLimit= %s, " +
                "areas= %s, " +
                "createLimit= %s, " +
                "jumpCount= %d, " +
                "clientCachedData= %s, " +
                "noCreativeItemLimitedTip= %b)",
                sizeLimit.toShortString(),
                areas,
                createLimit,
                jumpCount,
                clientCachedData,
                noCreativeItemLimitedTip
        );
    }


    public Vec3i getSizeLimit() {
        return sizeLimit;
    }

    public void setSizeLimit(Vec3i sizeLimit) {
        this.sizeLimit = sizeLimit;
    }

    public List<ActivityArea> getAreas() {
        return areas;
    }

    public boolean isCreateLimit() {
        return createLimit;
    }

    public void setCreateLimit(boolean createLimit) {
        this.createLimit = createLimit;
    }

    public int getJumpCount() {
        return jumpCount;
    }

    public void setJumpCount(int jumpCount) {
        this.jumpCount = jumpCount;
    }

    public ClientCachedData getClientCachedData() {
        return clientCachedData;
    }

    public boolean isNoCreativeItemLimitedTip() {
        return noCreativeItemLimitedTip;
    }

    public void setNoCreativeItemLimitedTip(boolean noCreativeItemLimitedTip) {
        this.noCreativeItemLimitedTip = noCreativeItemLimitedTip;
    }

    public static PlayerData get(ServerPlayer player) {
        return GameData.getGameData(player).getData(player.getUUID());
    }
}
