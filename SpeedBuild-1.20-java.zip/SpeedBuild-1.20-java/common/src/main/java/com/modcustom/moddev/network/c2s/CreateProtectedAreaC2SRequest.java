package com.modcustom.moddev.network.c2s;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.game.area.Area;
import com.modcustom.moddev.game.area.ProtectedArea;
import com.modcustom.moddev.game.data.ClientCachedData;
import com.modcustom.moddev.utils.TranslationUtil;
import dev.architectury.networking.NetworkManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;

import java.util.function.Supplier;

public class CreateProtectedAreaC2SRequest implements NetworkPacket {

    private final ProtectedArea area;

    public CreateProtectedAreaC2SRequest(Area area) {
        this(new ProtectedArea(area.getMinPos(), area.getMaxPos()));
    }

    public CreateProtectedAreaC2SRequest(ProtectedArea area) {
        this.area = area;
    }

    public CreateProtectedAreaC2SRequest(FriendlyByteBuf buf) {
        this(ProtectedArea.fromNbt(buf.readAnySizeNbt()));
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeNbt(area.toNbt());
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        if (contextSupplier.get().getPlayer() instanceof ServerPlayer player) {
            boolean isAreaAdded = ProtectedArea.add(player.serverLevel(), area, ClientCachedData.get(player).isOverlappingProtectedAreas(), true);

            String messageKey = isAreaAdded ? "create_protected_area" : "area_intersected";
            player.sendSystemMessage(TranslationUtil.messageComponent(messageKey));
        }
    }
}
