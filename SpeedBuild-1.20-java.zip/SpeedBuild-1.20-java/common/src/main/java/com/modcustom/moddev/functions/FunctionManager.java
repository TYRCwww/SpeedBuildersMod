package com.modcustom.moddev.functions;

import com.modcustom.moddev.api.Function;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public final class FunctionManager {

    private static final Map<ResourceLocation, Supplier<Function>> FUNCTION_FACTORIES = new LinkedHashMap<>();

    public static void register() {
        register(StartActivityFunction::new);
        register(CloneBaseFunction::new);
        register(ResetTargetAreaFunction::new);
        register(ResetConstructionAreaFunction::new);
        register(CopyTargetAreaFunction::new);
        register(CopyConstructionAreaFunction::new);
        register(CustomCommandFunction::new);
    }

    public static void register(Supplier<Function> functionSupplier) {
        Function function = functionSupplier.get();
        if (function == null) {
            throw new IllegalArgumentException("Function supplier returned null");
        }
        if (FUNCTION_FACTORIES.containsKey(function.getId())) {
            throw new IllegalArgumentException("Function with id " + function.getId() + " already registered");
        }
        FUNCTION_FACTORIES.put(function.getId(), functionSupplier);
    }

    public static void unregister(ResourceLocation id) {
        FUNCTION_FACTORIES.remove(id);
    }

    public static List<Function> getFunctions() {
        return FUNCTION_FACTORIES.values().stream().map(Supplier::get).toList();
    }

    public static <T extends Function> List<T> getFunctions(Class<T> type) {
        return FUNCTION_FACTORIES.values().stream().map(Supplier::get).filter(type::isInstance).map(type::cast).toList();
    }

    public static <T extends Function> LinkedHashMap<ResourceLocation, T> getFunctionMap(Class<T> type) {
        return FUNCTION_FACTORIES.entrySet().stream().filter(e -> type.isInstance(e.getValue().get())).collect(Collectors.toMap(Map.Entry::getKey, e -> type.cast(e.getValue().get()), (a, b) -> a, LinkedHashMap::new));
    }

    @Nullable
    public static Function create(ResourceLocation id) {
        Supplier<Function> factory = FUNCTION_FACTORIES.get(id);
        return factory != null ? factory.get() : null;
    }

    @Nullable
    public static <T extends Function> T tryParse(Class<T> type, CompoundTag tag) {
        if (tag == null) return null;

        String id = tag.getString("id");
        ResourceLocation location = ResourceLocation.tryParse(id);
        if (location == null) return null;

        Supplier<Function> factory = FUNCTION_FACTORIES.get(location);
        if (factory == null) return null;

        Function function = factory.get();
        if (!type.isInstance(function)) return null;

        function.readNbt(tag);
        return type.cast(function);
    }
}
