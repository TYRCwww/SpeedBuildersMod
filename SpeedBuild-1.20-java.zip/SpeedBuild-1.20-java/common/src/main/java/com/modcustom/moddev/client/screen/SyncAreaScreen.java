package com.modcustom.moddev.client.screen;

import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.area.AreaConfig;
import com.modcustom.moddev.network.Network;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public abstract class SyncAreaScreen extends SyncScreen {

    protected final int id;
    protected final ActivityArea area;
    private final Map<AreaConfig.Property, Long> lastModifyTime = new HashMap<>();

    protected SyncAreaScreen(Component title, ActivityArea area) {
        this(title, area, null);
    }

    protected SyncAreaScreen(Component title, ActivityArea area, @Nullable Screen parent) {
        super(title, parent);
        this.area = area;
        this.id = area.getId();
    }

    @Override
    public void tick() {
        long currentTime = System.currentTimeMillis();
        List<AreaConfig.Property> properties = lastModifyTime.entrySet().stream().filter(entry -> currentTime - entry.getValue() > 250).map(Map.Entry::getKey).collect(Collectors.toList());

        requestModifyAreaConfigs(properties);
        properties.forEach(lastModifyTime.keySet()::remove);
        super.tick();
    }

    protected void requestModifyAreaConfigs(List<AreaConfig.Property> properties) {
        requestModifyAreaConfigs(properties, false);
    }

    protected void requestModifyAreaConfigs(List<AreaConfig.Property> properties, boolean callback) {
        Network.requestModifyAreaConfig(id, area.getConfig(), callback, properties);
    }

    @Override
    public void onClose() {
        requestModifyAreaConfigs(new ArrayList<>(lastModifyTime.keySet()), true);
        super.onClose();
    }

    protected void markModified(AreaConfig.Property property) {
        lastModifyTime.put(property, System.currentTimeMillis());
    }

    protected void requestDelete() {
        Network.requestDeleteActivityArea(id);
    }
}
