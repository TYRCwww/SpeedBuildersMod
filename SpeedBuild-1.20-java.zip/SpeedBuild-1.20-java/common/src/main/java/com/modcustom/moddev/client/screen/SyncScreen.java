package com.modcustom.moddev.client.screen;

import com.modcustom.moddev.utils.TranslationUtil;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.Comparator;

import static java.lang.Math.round;

public abstract class SyncScreen extends Screen {

    protected static final int BUTTON_SPACE_WIDTH = 24;
    protected final Screen parent;
    protected int titleY = 12;

    protected SyncScreen(Component title) {
        this(title, null);
    }

    protected SyncScreen(Component title, @Nullable Screen parent) {
        super(title);
        this.parent = parent;
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(guiGraphics);
        super.render(guiGraphics, mouseX, mouseY, partialTick);
        renderTitle(guiGraphics);
    }

    @Override
    public void onClose() {
        if (this.minecraft != null) {
            this.minecraft.setScreen(this.parent);
        }
    }

    @Override
    public void renderBackground(GuiGraphics guiGraphics) {
        guiGraphics.fillGradient(0, 0, this.width, this.height, -1072689136, -804253680);
    }

    protected void renderTitle(GuiGraphics guiGraphics) {
        guiGraphics.drawCenteredString(this.font, this.title, this.width / 2, this.titleY, 0xFFFFFF);
    }

    protected StringWidget createStringWidget(Component component) {
        return createStringWidget(component, null);
    }

    protected StringWidget createStringWidget(Component component, Integer width) {
        if (width == null) {
            return new StringWidget(component, this.font).alignCenter();
        } else {
            return new StringWidget(width, this.font.lineHeight, component, this.font).alignCenter();
        }
    }

    protected void addWidgets(int startX, int y, int gap, AbstractWidget... widgets) {
        int x = startX;
        int maxHeight = Arrays.stream(widgets).max(Comparator.comparingInt(AbstractWidget::getHeight)).get().getHeight();
        for (AbstractWidget widget : widgets) {
            widget.setX(x);
            if (widget instanceof StringWidget) {
                widget.setY(y + (int) round((maxHeight - this.font.lineHeight) / 2.0));
            } else {
                widget.setY(y);
            }
            this.addRenderableWidget(widget);
            x += widget.getWidth() + gap;
        }
    }

    public abstract void update();

    protected Button createResetButton(Button.OnPress onPress) {
        return Button.builder(TranslationUtil.screenComponent("reset_button"), onPress).size(50, 20).build();
    }

    protected Button createButton(Component component, Button.OnPress onPress) {
        return Button.builder(component, onPress).bounds(0, 0, 20, 20).build();
    }

    protected Button createAdaptiveButton(Component component, Button.OnPress onPress) {
        return Button.builder(component, onPress).bounds(0, 0, TranslationUtil.calculateButtonWidth(font, component), 20).build();
    }
}
