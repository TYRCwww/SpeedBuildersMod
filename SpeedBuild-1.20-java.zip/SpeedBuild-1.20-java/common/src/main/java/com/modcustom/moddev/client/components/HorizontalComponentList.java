package com.modcustom.moddev.client.components;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.ContainerObjectSelectionList;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarratableEntry;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

@Environment(EnvType.CLIENT)
public class HorizontalComponentList extends ContainerObjectSelectionList<HorizontalComponentList.Entry> {

    public HorizontalComponentList(Minecraft minecraft, int width, int height, int y0, int y1, int itemHeight) {
        super(minecraft, width, height, y0, y1, itemHeight);
        this.setRenderBackground(false);
        this.setRenderTopAndBottom(false);
    }

    @Override
    public int getRowWidth() {
        return width;
    }

    @Override
    public int addEntry(Entry entry) {
        return super.addEntry(entry);
    }

    @Override
    public void addEntryToTop(Entry entry) {
        super.addEntryToTop(entry);
    }

    @Override
    protected int getScrollbarPosition() {
        return width - 6;
    }

    @Override
    public int getRowLeft() {
        return 0;
    }

    public void tick() {
        for (Entry entry : this.children()) {
            entry.tick();
        }
    }

    public static class Entry extends ContainerObjectSelectionList.Entry<Entry> {

        private final int startX;
        private final int gap;
        private final List<AbstractWidget> widgets = new ArrayList<>();
        private int firstStringWidgetYOffset;

        public Entry(int startX, int gap, AbstractWidget... widgets) {
            this.startX = startX;
            this.gap = gap;
            this.widgets.addAll(Arrays.asList(widgets));
        }

        public Entry(int startX, int gap, Collection<AbstractWidget> widgets) {
            this.startX = startX;
            this.gap = gap;
            this.widgets.addAll(widgets);
        }

        @Override
        public void render(GuiGraphics guiGraphics, int index, int top, int left, int width, int height, int mouseX, int mouseY, boolean hovering, float partialTick) {
            int x = startX;
            int maxHeight = widgets.stream().mapToInt(AbstractWidget::getHeight).max().orElse(0);
            int fontHeight = Minecraft.getInstance().font.lineHeight;
            int stringWidgetY = Math.round((maxHeight - fontHeight) / 2.0f);

            boolean firstStringWidget = true;

            for (AbstractWidget widget : widgets) {
                widget.setX(x);
                if (widget instanceof StringWidget) {
                    if (firstStringWidget) {
                        widget.setY(top + stringWidgetY + firstStringWidgetYOffset);
                        firstStringWidget = false;
                    } else {
                        widget.setY(top + stringWidgetY);
                    }
                } else {
                    widget.setY(top);
                }
                x += widget.getWidth() + gap;
                widget.render(guiGraphics, mouseX, mouseY, partialTick);
            }
        }

        public int getFirstStringWidgetYOffset() {
            return firstStringWidgetYOffset;
        }

        public void setFirstStringWidgetYOffset(int offset) {
            this.firstStringWidgetYOffset = offset;
        }

        public void addWidgets(AbstractWidget... widgets) {
            this.widgets.addAll(Arrays.asList(widgets));
        }

        public void replaceWidget(int index, AbstractWidget widget) {
            widgets.set(index, widget);
        }

        @Nullable
        public AbstractWidget removeLastWidget() {
            return widgets.isEmpty() ? null : widgets.remove(widgets.size() - 1);
        }

        public int getWidth() {
            return widgets.stream().mapToInt(AbstractWidget::getWidth).sum() + gap * (widgets.size() - 1);
        }

        public int getHeight() {
            return widgets.stream().mapToInt(AbstractWidget::getHeight).max().orElse(0);
        }

        public void tick() {
            for (AbstractWidget widget : widgets) {
                if (widget instanceof EditBox editBox) {
                    editBox.tick();
                }
            }
        }

        @Override
        public List<? extends GuiEventListener> children() {
            return widgets;
        }

        @Override
        public List<? extends NarratableEntry> narratables() {
            return widgets;
        }
    }
}
