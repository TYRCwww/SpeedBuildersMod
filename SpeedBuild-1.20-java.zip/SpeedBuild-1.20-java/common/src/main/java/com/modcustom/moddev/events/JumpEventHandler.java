package com.modcustom.moddev.events;

import com.modcustom.moddev.api.LivingFallEvent;
import com.modcustom.moddev.utils.PlayerUtil;
import dev.architectury.event.EventResult;
import dev.architectury.event.events.common.EntityEvent;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;

public class JumpEventHandler {

    public static void register() {
        LivingFallEvent.EVENT.register(JumpEventHandler::handlePlayerFall);
        EntityEvent.LIVING_HURT.register(JumpEventHandler::handleFallDamage);
    }

    private static EventResult handleFallDamage(LivingEntity entity, DamageSource source, float amount) {
        if (entity instanceof ServerPlayer serverPlayer && PlayerUtil.isExtraJumpEnabled(serverPlayer) && source.is(DamageTypes.FALL)) {
            PlayerUtil.setJumpCount(serverPlayer, 0);
            return EventResult.interruptFalse();
        }
        return EventResult.pass();
    }

    public static void handlePlayerFall(LivingEntity entity, BlockState state, BlockPos pos) {
        if (!(entity instanceof Player player)) return;
        if (entity instanceof ServerPlayer serverPlayer && PlayerUtil.getJumpCount(serverPlayer) > 0) {
            PlayerUtil.setJumpCount(serverPlayer, 0);
            PlayerUtil.sendTestMessage(serverPlayer, String.format("落地重置 方块:%s 坐标:%s 玩家脚下方块:%s", state.getBlock().getName().getString(), pos.toShortString(), entity.blockPosition()));
        } else if (entity.level().isClientSide()) {
            ClientEventHandler.handleLocalPlayerFall(entity, state, pos, player);
        }
    }
}
