package com.modcustom.moddev.game.data;

import com.modcustom.moddev.SpeedBuild;
import com.modcustom.moddev.game.activity.ActivityManager;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.area.FunctionArea;
import com.modcustom.moddev.game.area.ProtectedArea;
import com.modcustom.moddev.network.Network;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Predicate;

public class GameData extends SavedData {

    private final Map<UUID, PlayerData> playerData = new HashMap<>();
    private final List<ActivityArea> ownerlessAreas = new ArrayList<>();
    private final Map<String, List<ProtectedArea>> protectedAreas = new HashMap<>();
    private final Map<String, List<FunctionArea>> functionAreas = new HashMap<>();
    private Vec3i defaultSizeLimit = new Vec3i(16, 16, 16);

    public int getNextActivityAreaId() {
        int id = 0;
        List<ActivityArea> areaList = getActivityAreas();
        while (true) {
            int finalId = id;
            if (areaList.stream().noneMatch(area -> area.getId() == finalId)) return id;
            id++;
        }
    }

    public List<ActivityArea> getActivityAreas() {
        List<ActivityArea> areas = new ArrayList<>();
        playerData.values().forEach(data -> areas.addAll(data.getAreas()));
        areas.addAll(ownerlessAreas);
        return areas;
    }

    public void addActivityArea(ActivityArea area) {
        UUID uuid = area.getOwner();
        if (uuid != null) {
            getData(uuid).getAreas().add(area);
        } else {
            ownerlessAreas.add(area);
        }
        setDirty();
    }

    public PlayerData getData(UUID uuid) {
        return playerData.computeIfAbsent(uuid, k -> new PlayerData(defaultSizeLimit));
    }

    public ActivityArea getActivityArea(Level level, BlockPos pos) {
        return getActivityArea(level, pos, activityArea -> true);
    }

    public ActivityArea getActivityArea(Level level, BlockPos pos, Predicate<ActivityArea> predicate) {
        String dimension = level.dimension().location().toString();
        return playerData.values().stream()
                         .flatMap(data -> data.getAreas().stream())
                         .filter(predicate)
                         .filter(area -> area.contains(pos) && area.getDimension().equals(dimension))
                         .findFirst()
                         .orElse(null);
    }

    public void removeActivityArea(int id) {
        ActivityArea area = getActivityArea(id);
        if (area != null) {
            List<ActivityArea> areas = area.getOwner() != null ? getData(area.getOwner()).getAreas() : ownerlessAreas;
            areas.removeIf(a -> {
                if (a.getId() == id) {
                    ActivityManager.removeActivity(a.getId());
                    return true;
                }
                return false;
            });
            setDirty();
        }
    }

    @Nullable
    public ActivityArea getActivityArea(int id) {
        return getActivityAreas().stream().filter(area -> area.getId() == id).findFirst().orElse(null);
    }

    public int clearActivityAreas() {
        int count = getActivityAreas().size();
        playerData.values().forEach(data -> {
            data.getAreas().forEach(area -> ActivityManager.removeActivity(area.getId()));
            data.getAreas().clear();
        });
        ownerlessAreas.forEach(area -> ActivityManager.removeActivity(area.getId()));
        ownerlessAreas.clear();
        setDirty();
        return count;
    }

    public Vec3i getSizeLimit(Player player) {
        return playerData.getOrDefault(player.getUUID(), new PlayerData(defaultSizeLimit)).getSizeLimit();
    }

    public void setSizeLimit(Player player, Vec3i sizeLimit) {
        getData(player.getUUID()).setSizeLimit(sizeLimit);
        setDirty();
    }

    public void setDefaultSizeLimit(Vec3i size) {
        defaultSizeLimit = size;
        playerData.values().forEach(data -> data.setSizeLimit(size));
        setDirty();
    }

    public void liftCreateLimit(Player player) {
        getData(player.getUUID()).setCreateLimit(false);
        setDirty();
    }

    public boolean canCreateActivityArea(Player player) {
        return !isLimited(player) || getActivityAreas().stream().noneMatch(area -> Objects.equals(area.getOwner(), player.getUUID()));
    }

    public boolean isLimited(Player player) {
        return getData(player.getUUID()).isCreateLimit();
    }

    public ActivityArea getNearestActivityArea(Level level, BlockPos pos, int inflate) {
        return getNearestActivityArea(level, pos, inflate, area -> true);
    }

    public ActivityArea getNearestActivityArea(Level level, BlockPos pos, int inflate, Predicate<ActivityArea> predicate) {
        String dimension = level.dimension().location().toString();
        return getActivityAreas().stream().filter(area -> area.getDimension().equals(dimension) && area.contains(pos, inflate) && predicate.test(area)).min(Comparator.comparingDouble(area -> area.distanceTo(pos))).orElse(null);
    }

    public ActivityArea getNearestActivityArea(Level level, Vec3 pos, int inflate) {
        return getNearestActivityArea(level, pos, inflate, area -> true);
    }

    public ActivityArea getNearestActivityArea(Level level, Vec3 pos, int inflate, Predicate<ActivityArea> predicate) {
        String dimension = level.dimension().location().toString();
        return getActivityAreas().stream().filter(area -> area.getDimension().equals(dimension) && area.getBoundingBox().inflatedBy(inflate).isInside((int) pos.x(), (int) pos.y(), (int) pos.z()) && predicate.test(area)).min(Comparator.comparingDouble(area -> area.distanceTo(pos))).orElse(null);
    }

    public Map<String, List<ProtectedArea>> getProtectedAreas() {
        return Map.copyOf(protectedAreas);
    }

    public boolean isProtected(Level level, BlockPos pos) {
        return !protectedAreas.isEmpty() && getProtectedAreas(level).stream().anyMatch(area -> area.contains(pos) && area.isActive());
    }

    public List<ProtectedArea> getProtectedAreas(Level level) {
        return getProtectedAreas(level.dimension().location().toString());
    }

    public List<ProtectedArea> getProtectedAreas(String dimension) {
        return protectedAreas.computeIfAbsent(dimension, k -> new ArrayList<>());
    }

    public Boolean toggleProtectedAreaActive(ServerLevel level, BlockPos pos) {
        for (ProtectedArea area : getProtectedAreas(level)) {
            if (area.contains(pos)) {
                area.setActive(!area.isActive());
                Network.updateProtectedAreas(level.getServer());
                return area.isActive();
            }
        }
        return null;
    }

    public Map<String, List<FunctionArea>> getFunctionAreas() {
        return Map.copyOf(functionAreas);
    }

    public void removeFunctionArea(int id) {
        functionAreas.values().forEach(list -> list.removeIf(area -> area.getId() == id));
        setDirty();
    }

    public boolean isLocked(Level level, BlockPos pos) {
        return !functionAreas.isEmpty() && getFunctionAreas(level).stream().anyMatch(area -> area.contains(pos) && area.isLocked());
    }

    public List<FunctionArea> getFunctionAreas(Level level) {
        return getFunctionAreas(level.dimension().location().toString());
    }

    public List<FunctionArea> getFunctionAreas(String dimension) {
        return functionAreas.computeIfAbsent(dimension, k -> new ArrayList<>());
    }

    public int getNextFunctionAreaId() {
        start:
        for (int id = 0; ; id++) {
            for (List<FunctionArea> list : functionAreas.values()) {
                for (FunctionArea area : list) {
                    if (area.getId() == id) {
                        continue start;
                    }
                }
            }
            return id;
        }
    }

    @Nullable
    public FunctionArea getFunctionArea(int id) {
        return functionAreas.values().stream().flatMap(Collection::stream).filter(area -> area.getId() == id).findFirst().orElse(null);
    }

    @Nullable
    public FunctionArea getFunctionArea(Level level, BlockPos pos) {
        return getFunctionAreas(level).stream().filter(area -> area.contains(pos)).findFirst().orElse(null);
    }

    @Nullable
    public FunctionArea getNearestFunctionArea(Level level, Vec3 pos, int inflate) {
        return getNearestFunctionArea(level, pos, inflate, area -> true);
    }

    @Nullable
    public FunctionArea getNearestFunctionArea(Level level, Vec3 pos, int inflate, Predicate<FunctionArea> predicate) {
        String dimension = level.dimension().location().toString();
        return getFunctionAreas(dimension).stream().filter(area -> area.getBoundingBox().inflatedBy(inflate).isInside((int) pos.x(), (int) pos.y(), (int) pos.z()) && predicate.test(area)).min(Comparator.comparingDouble(area -> area.distanceTo(pos))).orElse(null);
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag dataList = new ListTag();
        playerData.forEach((uuid, data) -> {
            CompoundTag compound = new CompoundTag();
            compound.putUUID("uuid", uuid);
            dataList.add(data.writeNbt(compound));
        });
        tag.put("Data", dataList);
        ListTag ownerlessList = new ListTag();
        ownerlessAreas.forEach(area -> ownerlessList.add(area.toNbt()));
        tag.put("OwnerlessAreas", ownerlessList);
        CompoundTag sizeTag = new CompoundTag();
        sizeTag.putInt("x", defaultSizeLimit.getX());
        sizeTag.putInt("y", defaultSizeLimit.getY());
        sizeTag.putInt("z", defaultSizeLimit.getZ());
        tag.put("DefaultSize", sizeTag);
        if (!protectedAreas.isEmpty()) {
            CompoundTag areaList = new CompoundTag();
            protectedAreas.forEach((dimension, areas) -> {
                ListTag list = new ListTag();
                areas.forEach(area -> list.add(area.toNbt()));
                areaList.put(dimension, list);
            });
            tag.put("ProtectedAreas", areaList);
        }
        if (!functionAreas.isEmpty()) {
            CompoundTag areaList = new CompoundTag();
            functionAreas.forEach((dimension, areas) -> {
                ListTag list = new ListTag();
                areas.forEach(area -> list.add(area.toNbt()));
                areaList.put(dimension, list);
            });
            tag.put("FunctionAreas", areaList);
        }
        return tag;
    }

    public static GameData getGameData(CommandContext<CommandSourceStack> context) {
        return getGameData(context.getSource().getServer());
    }

    public static GameData getGameData(MinecraftServer server) {
        GameData gameData = server.overworld().getDataStorage().computeIfAbsent(GameData::load, GameData::new, SpeedBuild.MOD_ID);
        gameData.setDirty();
        return gameData;
    }

    public static GameData load(CompoundTag tag) {
        GameData data = new GameData();
        if (tag.contains("DefaultSize")) {
            CompoundTag sizeTag = tag.getCompound("DefaultSize");
            data.defaultSizeLimit = new Vec3i(sizeTag.getInt("x"), sizeTag.getInt("y"), sizeTag.getInt("z"));
        }
        tag.getList("Data", Tag.TAG_COMPOUND).forEach(nbt -> {
            CompoundTag compound = (CompoundTag) nbt;
            if (compound.contains("uuid")) {
                UUID uuid = compound.getUUID("uuid");
                PlayerData playerData = new PlayerData(data.defaultSizeLimit);
                playerData.readNbt(compound);
                data.playerData.put(uuid, playerData);
            }
        });
        tag.getList("OwnerlessAreas", Tag.TAG_COMPOUND).forEach(nbt -> {
            CompoundTag compound = (CompoundTag) nbt;
            ActivityArea area = ActivityArea.parseNbt(compound);
            if (area != null) data.ownerlessAreas.add(area);
        });
        if (tag.contains("ProtectedAreas")) {
            CompoundTag protectedTag = tag.getCompound("ProtectedAreas");
            protectedTag.getAllKeys().forEach(dimension -> {
                ListTag list = protectedTag.getList(dimension, Tag.TAG_COMPOUND);
                list.forEach(nbtElement -> {
                    CompoundTag compound = (CompoundTag) nbtElement;
                    ProtectedArea area = ProtectedArea.fromNbt(compound);
                    if (area != null) data.getProtectedAreas(dimension).add(area);
                });
            });
        }
        if (tag.contains("FunctionAreas")) {
            CompoundTag functionTag = tag.getCompound("FunctionAreas");
            functionTag.getAllKeys().forEach(dimension -> {
                ListTag list = functionTag.getList(dimension, Tag.TAG_COMPOUND);
                list.forEach(nbtElement -> {
                    CompoundTag compound = (CompoundTag) nbtElement;
                    FunctionArea area = FunctionArea.fromNbt(compound);
                    if (area != null) data.getFunctionAreas(dimension).add(area);
                });
            });
        }
        return data;
    }

    public static GameData getGameData(ServerLevel level) {
        return getGameData(level.getServer());
    }

    public static GameData getGameData(ServerPlayer player) {
        return getGameData(player.server);
    }
}
