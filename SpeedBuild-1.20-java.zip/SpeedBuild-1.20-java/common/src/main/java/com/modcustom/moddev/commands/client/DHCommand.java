package com.modcustom.moddev.commands.client;

import com.modcustom.moddev.config.SneakTweakConfig;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.architectury.event.events.client.ClientCommandRegistrationEvent;
import net.minecraft.commands.CommandBuildContext;

import static dev.architectury.event.events.client.ClientCommandRegistrationEvent.ClientCommandSourceStack;

public class DHCommand extends ClientCommand {

    public DHCommand() {
        super("dh");
    }

    @Override
    public LiteralArgumentBuilder<ClientCommandSourceStack> build(LiteralArgumentBuilder<ClientCommandSourceStack> builder, CommandBuildContext context) {
        return builder.then(executeSetConfig(true)).then(executeSetConfig(false));
    }

    private LiteralArgumentBuilder<ClientCommandSourceStack> executeSetConfig(boolean old) {
        if (old) {
            return ClientCommandRegistrationEvent.literal("1.12").executes(context -> {
                SneakTweakConfig.getInstance().convertToOld();
                SneakTweakConfig.save();
                return 1;
            });
        } else {
            return ClientCommandRegistrationEvent.literal("1.20").executes(context -> {
                SneakTweakConfig.getInstance().reset();
                SneakTweakConfig.save();
                return 1;
            });
        }
    }
}
