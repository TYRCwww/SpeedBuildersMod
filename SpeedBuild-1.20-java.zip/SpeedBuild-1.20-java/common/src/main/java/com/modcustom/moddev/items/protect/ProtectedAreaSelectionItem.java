package com.modcustom.moddev.items.protect;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.AreaSelector;
import com.modcustom.moddev.game.area.Area;
import com.modcustom.moddev.items.AreaSelectionItem;
import com.modcustom.moddev.network.Network;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

public class ProtectedAreaSelectionItem extends AreaSelectionItem {

    public ProtectedAreaSelectionItem(Properties properties) {
        super(properties);
    }

    @Override
    protected AreaSelector getAreaSelector() {
        return ClientGameManager.getInstance().getProtectedAreaSelector();
    }

    @Override
    protected void requestCreateArea(AreaSelector selector) {
        Network.requestCreateProtectedArea(selector.getArea());
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public boolean isVisible(@Nullable Area.Type type) {
        return type == Area.Type.PROTECTED;
    }
}
