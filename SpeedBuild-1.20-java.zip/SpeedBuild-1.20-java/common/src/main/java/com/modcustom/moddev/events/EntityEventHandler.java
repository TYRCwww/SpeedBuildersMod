package com.modcustom.moddev.events;

import com.modcustom.moddev.api.SpawnerProvider;
import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.activity.Activity;
import com.modcustom.moddev.game.activity.ActivityManager;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.data.GameData;
import dev.architectury.event.EventResult;
import dev.architectury.event.events.common.EntityEvent;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import java.util.UUID;

public class EntityEventHandler {

    public static void register() {
        EntityEvent.ADD.register(EntityEventHandler::handleEntityAdd);
        EntityEvent.LIVING_HURT.register(EntityEventHandler::handleEntityHurt);
    }

    private static EventResult handleEntityAdd(Entity entity, Level level) {
        BlockPos pos = entity.blockPosition();
        if (entity instanceof Mob mob) {
            boolean freeze;
            if (level instanceof ServerLevel serverLevel) {
                ActivityArea area = GameData.getGameData(serverLevel).getActivityArea(serverLevel, pos);
                freeze = area != null && !area.getConfig().isEntityMove();
            } else {
                freeze = !ClientGameManager.getInstance().getActivityAreas(level, area -> area.contains(pos) && !area.getConfig().isEntityMove()).isEmpty();
            }

            if (freeze) {
                mob.setNoAi(true);
                mob.setYRot(0f);
                mob.setYBodyRot(0f);
                mob.setYHeadRot(0f);
            }
        }

        Entity spawner = null;
        if (entity instanceof ItemEntity itemEntity) {
            spawner = itemEntity.getOwner();
        }
        if (spawner == null) {
            UUID spawnerUuid = SpawnerProvider.getSpawner(entity);
            if (spawnerUuid != null) {
                if (level instanceof ServerLevel serverLevel) {
                    spawner = serverLevel.getEntity(spawnerUuid);
                } else {
                    spawner = ClientEventHandler.getSpawnerClient(level, spawnerUuid);
                }
            }
        }

        Activity.tryStartActivity(level, pos, spawner, entity);
        if (level instanceof ServerLevel serverLevel && spawner != null) {
            ActivityManager.getActivities(serverLevel, pos).forEach(Activity::markEntityPlaced);
        }
        return EventResult.pass();
    }

    public static EventResult handleEntityHurt(Entity entity, DamageSource source, float amount) {
        if (entity instanceof Player) return EventResult.pass();
        Level level = entity.level();
        if (level instanceof ServerLevel && source.getEntity() instanceof Player) {
            tryDiscardEntity(entity);
        }
        return EventResult.pass();
    }

    public static boolean tryDiscardEntity(Entity entity) {
        if (!(entity.level() instanceof ServerLevel level)) return false;

        ActivityArea area = GameData.getGameData(level).getActivityArea(level, entity.blockPosition(), a -> entity.getBoundingBox().intersects(a.getBox()) && a.getConfig().isEntityInstantKill());
        if (area != null) {
            entity.discard();
            return true;
        }
        return false;
    }
}
