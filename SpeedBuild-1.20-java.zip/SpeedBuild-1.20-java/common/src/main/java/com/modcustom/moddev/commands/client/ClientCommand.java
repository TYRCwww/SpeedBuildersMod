package com.modcustom.moddev.commands.client;

import com.modcustom.moddev.commands.Command;
import com.modcustom.moddev.utils.TranslationUtil;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.architectury.event.events.client.ClientCommandRegistrationEvent;
import dev.architectury.event.events.client.ClientCommandRegistrationEvent.ClientCommandSourceStack;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.arguments.ColorArgument;

import java.awt.*;
import java.util.function.BiFunction;
import java.util.function.Function;

import static dev.architectury.event.events.client.ClientCommandRegistrationEvent.argument;
import static dev.architectury.event.events.client.ClientCommandRegistrationEvent.literal;

public abstract class ClientCommand extends Command<ClientCommandSourceStack> {

    public ClientCommand(String root) {
        super(root);
    }

    @Override
    public void register(CommandDispatcher<ClientCommandSourceStack> dispatcher, CommandBuildContext context) {
        dispatcher.register(build(literal(value), context));
    }

    protected LiteralArgumentBuilder<ClientCommandSourceStack> executeSetPos(BiFunction<Float, Float, Integer> setter) {
        return literal("pos").then(argument("x", FloatArgumentType.floatArg()).then(argument("y", FloatArgumentType.floatArg()).executes(context -> {
            float x = FloatArgumentType.getFloat(context, "x");
            float y = FloatArgumentType.getFloat(context, "y");
            return setter.apply(x, y);
        })));
    }

    protected LiteralArgumentBuilder<ClientCommandSourceStack> executeSetSize(Function<Float, Integer> setter) {
        return literal("size").then(argument("size", FloatArgumentType.floatArg(0f)).executes(context -> {
            float size = FloatArgumentType.getFloat(context, "size");
            return setter.apply(size);
        }));
    }

    protected LiteralArgumentBuilder<ClientCommandSourceStack> executeSetColorRGBA(RGBA2IntFunction setter) {
        return literal("color").then(argument("r", IntegerArgumentType.integer(0, 255)).then(argument("g", IntegerArgumentType.integer(0, 255)).then(argument("b", IntegerArgumentType.integer(0, 255)).then(argument("a", IntegerArgumentType.integer(0, 255)).executes(context -> {
            int r = IntegerArgumentType.getInteger(context, "r");
            int g = IntegerArgumentType.getInteger(context, "g");
            int b = IntegerArgumentType.getInteger(context, "b");
            int a = IntegerArgumentType.getInteger(context, "a");
            return setter.apply(r, g, b, a);
        })))));
    }

    protected LiteralArgumentBuilder<ClientCommandSourceStack> executeSetColor(Function<Color, Integer> setter) {
        return literal("color").then(argument("rgb", StringArgumentType.word()).executes(context -> {
            String rgb = StringArgumentType.getString(context, "rgb");
            try {
                Color color = Color.decode(rgb);
                return setter.apply(color);
            } catch (NumberFormatException e) {
                context.getSource().arch$sendFailure(TranslationUtil.messageComponent("color.invalid", rgb));
                return 0;
            }
        }));
    }

    protected LiteralArgumentBuilder<ClientCommandSourceStack> executeSetColorFormatting(Function<ChatFormatting, Integer> setter) {
        return literal("color").then(argument("formatting", ColorArgument.color()).executes(context -> {
            ChatFormatting formatting = context.getArgument("formatting", ChatFormatting.class);
            return setter.apply(formatting);
        }));
    }

    public static void registerClient() {
        ClientCommandRegistrationEvent.EVENT.register((dispatcher, context) -> {
            registerCommands(dispatcher, context,
                             new JSTJCommand(),
                             new DJTJCommand(),
                             new ReloadCommand(),
                             new DHCommand(),
                             new TestCommand()
            );
        });
    }

    public interface RGBA2IntFunction {

        int apply(int r, int g, int b, int a);
    }
}
