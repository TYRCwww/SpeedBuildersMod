package com.modcustom.moddev;

import com.modcustom.moddev.config.Config;
import com.modcustom.moddev.config.SneakTweakConfig;
import com.modcustom.moddev.events.ModEventRegister;
import com.modcustom.moddev.registry.ModBlockEntityTypes;
import com.modcustom.moddev.registry.ModKeys;
import dev.architectury.event.events.client.ClientTickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

@Environment(EnvType.CLIENT)
public final class SpeedBuildClient {

    public static void init() {
        Config.load();
        initSneakTweak();
        ModKeys.registerKeys();
        ModBlockEntityTypes.registerRenderers();
        ModKeys.register();
        ModEventRegister.registerClient();
    }

    private static void initSneakTweak() {
        SneakTweakConfig.load();
        ClientTickEvent.CLIENT_LEVEL_POST.register(level -> {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player != null) {
                player.refreshDimensions();
            }
        });
    }
}
