package com.modcustom.moddev.commands.common;

import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.utils.TranslationUtil;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Position;
import net.minecraft.network.chat.Component;

public class MSTJCommand extends CommonCommand {

    public MSTJCommand() {
        super("mstj");
    }

    @Override
    public LiteralArgumentBuilder<CommandSourceStack> build(LiteralArgumentBuilder<CommandSourceStack> builder, CommandBuildContext context) {
        return builder.executes(this::executeToggleSimpleMode);
    }

    private int executeToggleSimpleMode(CommandContext<CommandSourceStack> context) {
        CommandSourceStack source = context.getSource();
        Position position = source.getPosition();
        BlockPos pos = BlockPos.containing(position);

        GameData gameData = GameData.getGameData(context);
        ActivityArea area = gameData.getActivityArea(source.getLevel(), pos);

        if (area != null) {
            boolean newMode = !area.getConfig().isSimpleMode();
            area.getConfig().setSimpleMode(newMode);

            Component component = TranslationUtil.messageComponent("simple_mode." + (newMode ? "on" : "off") + ".toggle");

            if (source.getPlayer() != null) {
                source.getPlayer().sendSystemMessage(component, true);
            } else {
                source.sendSuccess(() -> component, true);
            }
        }
        return 1;
    }
}
