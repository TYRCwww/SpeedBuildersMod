package com.modcustom.moddev.commands.common;

import com.modcustom.moddev.commands.Command;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;

public abstract class CommonCommand extends Command<CommandSourceStack> {

    public CommonCommand(String root) {
        super(root);
    }

    @Override
    public void register(CommandDispatcher<CommandSourceStack> dispatcher, CommandBuildContext context) {
        dispatcher.register(build(Commands.literal(value), context));
    }
}
