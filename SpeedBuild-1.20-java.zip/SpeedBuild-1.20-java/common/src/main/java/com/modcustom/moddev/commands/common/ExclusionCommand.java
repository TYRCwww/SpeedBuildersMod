package com.modcustom.moddev.commands.common;

import com.modcustom.moddev.config.GlobeConfig;
import com.modcustom.moddev.network.c2s.ModifyGlobeConfigC2SRequest.Action;
import com.modcustom.moddev.utils.TranslationUtil;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.ResourceArgument;
import net.minecraft.commands.synchronization.SuggestionProviders;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.properties.Property;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class ExclusionCommand extends CommonCommand {

    public ExclusionCommand() {
        super("exclusion");
    }

    @Override
    public LiteralArgumentBuilder<CommandSourceStack> build(LiteralArgumentBuilder<CommandSourceStack> builder, CommandBuildContext context) {
        return builder.then(executeAddAttribute(context)).then(executeRemoveAttribute());
    }

    private LiteralArgumentBuilder<CommandSourceStack> executeAddAttribute(CommandBuildContext context) {
        return Commands.literal("add").then(Commands.literal("entity").then(Commands.argument("attribute", StringArgumentType.string()).executes(ctx -> {
            String value = StringArgumentType.getString(ctx, "attribute");
            executeModify("entity", value, Action.ADD);
            sendSuccess(ctx);
            return 1;
        })).then(Commands.argument("id", ResourceArgument.resource(context, Registries.ENTITY_TYPE)).suggests(SuggestionProviders.SUMMONABLE_ENTITIES).then(Commands.argument("attribute", StringArgumentType.string()).suggests((commandContext, builder) -> {
            EntityType<?> type = ResourceArgument.getSummonableEntityType(commandContext, "id").value();
            CompoundTag compoundTag = new CompoundTag();
            Optional.ofNullable(type.create(commandContext.getSource().getLevel())).ifPresent(entity -> entity.saveWithoutId(compoundTag));
            compoundTag.getAllKeys().removeAll(GlobeConfig.getInstance().getExceptAttributes("entity", EntityType.getKey(type)));
            return SharedSuggestionProvider.suggest(compoundTag.getAllKeys(), builder);
        }).executes(ctx -> {
            EntityType<?> type = ResourceArgument.getSummonableEntityType(ctx, "id").value();
            String value = StringArgumentType.getString(ctx, "attribute");
            executeModify("entity:" + EntityType.getKey(type), value, Action.ADD);
            sendSuccess(ctx);
            return 1;
        })))).then(Commands.literal("block").then(Commands.argument("attribute", StringArgumentType.string()).executes(ctx -> {
            String value = StringArgumentType.getString(ctx, "attribute");
            executeModify("block", value, Action.ADD);
            sendSuccess(ctx);
            return 1;
        })).then(Commands.argument("id", ResourceArgument.resource(context, Registries.BLOCK)).suggests((ctx, builder) -> SharedSuggestionProvider.suggestResource(BuiltInRegistries.BLOCK.keySet(), builder)).then(Commands.argument("attribute", StringArgumentType.string()).suggests((commandContext, builder) -> {
            Block block = ResourceArgument.getResource(commandContext, "id", Registries.BLOCK).value();
            Set<String> attributes = block.defaultBlockState().getProperties().stream().map(Property::getName).collect(Collectors.toSet());
            attributes.removeAll(GlobeConfig.getInstance().getExceptAttributes("block", BuiltInRegistries.BLOCK.getKey(block)));
            return SharedSuggestionProvider.suggest(attributes, builder);
        }).executes(ctx -> {
            Block block = ResourceArgument.getResource(ctx, "id", Registries.BLOCK).value();
            String value = StringArgumentType.getString(ctx, "attribute");
            executeModify("block:" + BuiltInRegistries.BLOCK.getKey(block), value, Action.ADD);
            sendSuccess(ctx);
            return 1;
        })))).then(Commands.literal("storage").then(Commands.argument("attribute", StringArgumentType.string()).executes(ctx -> {
            String value = StringArgumentType.getString(ctx, "attribute");
            executeModify("storage", value, Action.ADD);
            sendSuccess(ctx);
            return 1;
        })).then(Commands.argument("id", ResourceArgument.resource(context, Registries.BLOCK_ENTITY_TYPE)).suggests((ctx, builder) -> SharedSuggestionProvider.suggestResource(BuiltInRegistries.BLOCK_ENTITY_TYPE.keySet(), builder)).then(Commands.argument("attribute", StringArgumentType.string()).suggests((commandContext, builder) -> {
            BlockEntityType<?> blockEntityType = ResourceArgument.getResource(commandContext, "id", Registries.BLOCK_ENTITY_TYPE).value();
            CompoundTag compoundTag = new CompoundTag();
            BlockEntity blockEntity = blockEntityType.create(BlockPos.ZERO, Blocks.AIR.defaultBlockState());
            if (blockEntity != null) {
                compoundTag = blockEntity.saveWithoutMetadata();
            }
            compoundTag.getAllKeys().removeAll(GlobeConfig.getInstance().getExceptAttributes("storage", BuiltInRegistries.BLOCK_ENTITY_TYPE.getKey(blockEntityType)));
            return SharedSuggestionProvider.suggest(compoundTag.getAllKeys(), builder);
        }).executes(ctx -> {
            BlockEntityType<?> blockEntityType = ResourceArgument.getResource(ctx, "id", Registries.BLOCK_ENTITY_TYPE).value();
            String value = StringArgumentType.getString(ctx, "attribute");
            executeModify("storage:" + BuiltInRegistries.BLOCK_ENTITY_TYPE.getKey(blockEntityType), value, Action.ADD);
            sendSuccess(ctx);
            return 1;
        }))));
    }

    private void executeModify(String key, String value, Action action) {
        if (action == Action.REMOVE && !GlobeConfig.getInstance().getExceptAttributes().containsKey(key)) {
            return;
        }
        Set<String> strings = GlobeConfig.getInstance().getExceptAttributes().computeIfAbsent(key, k -> new HashSet<>());
        if (action == Action.ADD) {
            strings.add(value);
        } else if (action == Action.REMOVE) {
            strings.remove(value);
        }
        if (strings.isEmpty() && !"entity".equals(key) && !"block".equals(key) && !"storage".equals(key)) {
            GlobeConfig.getInstance().getExceptAttributes().remove(key);
        }
        GlobeConfig.getInstance().save();
    }

    private void sendSuccess(CommandContext<CommandSourceStack> context) {
        context.getSource().sendSuccess(TranslationUtil::successComponent, true);
    }

    private LiteralArgumentBuilder<CommandSourceStack> executeRemoveAttribute() {
        return Commands.literal("remove").requires(source -> source.hasPermission(2)).then(Commands.argument("key", StringArgumentType.string()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(GlobeConfig.getInstance().getExceptAttributes().keySet().stream().map(key -> key.replace(":", ".")).collect(Collectors.toSet()), builder)).then(Commands.argument("attribute", StringArgumentType.string()).suggests((context, builder) -> SharedSuggestionProvider.suggest(GlobeConfig.getInstance().getExceptAttributes().get(StringArgumentType.getString(context, "key").replace(".", ":")), builder)).executes(context -> {
            String key = StringArgumentType.getString(context, "key").replace(".", ":");
            String value = StringArgumentType.getString(context, "attribute");
            executeModify(key, value, Action.REMOVE);
            sendSuccess(context);
            return 1;
        })));
    }
}
