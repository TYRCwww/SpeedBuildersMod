package com.modcustom.moddev.network.c2s;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.data.GameData;
import dev.architectury.networking.NetworkManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;

import java.util.function.Supplier;

public class CloneBaseC2SRequest implements NetworkPacket {

    private final int id;

    public CloneBaseC2SRequest(FriendlyByteBuf buf) {
        this(buf.readInt());
    }

    public CloneBaseC2SRequest(int id) {
        this.id = id;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(id);
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        NetworkManager.PacketContext context = contextSupplier.get();
        if (context.getPlayer() instanceof ServerPlayer player) {
            context.queue(() -> {
                ActivityArea area = GameData.getGameData(player).getActivityArea(id);
                if (area != null) {
                    area.startCloneBaseTask(player.serverLevel());
                }
            });
        }
    }
}
