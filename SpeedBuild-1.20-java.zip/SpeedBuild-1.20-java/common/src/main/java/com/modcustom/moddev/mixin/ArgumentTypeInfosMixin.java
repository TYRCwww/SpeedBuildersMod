package com.modcustom.moddev.mixin;

import com.modcustom.moddev.SpeedBuild;
import com.modcustom.moddev.arguments.AreaFunctionArgument;
import com.modcustom.moddev.arguments.AxisOrderArgument;
import com.mojang.brigadier.arguments.ArgumentType;
import net.minecraft.commands.synchronization.ArgumentTypeInfo;
import net.minecraft.commands.synchronization.ArgumentTypeInfos;
import net.minecraft.commands.synchronization.SingletonArgumentInfo;
import net.minecraft.core.Registry;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;

@Mixin(ArgumentTypeInfos.class)
public class ArgumentTypeInfosMixin {

    @Shadow
    @Final
    private static Map<Class<?>, ArgumentTypeInfo<?, ?>> BY_CLASS;

    @Inject(method = "bootstrap", at = @At("HEAD"))
    private static void register(Registry<ArgumentTypeInfo<?, ?>> registry, CallbackInfoReturnable<ArgumentTypeInfo<?, ?>> cir) {
        speedbuild$register(registry, "axis_order", AxisOrderArgument.class, SingletonArgumentInfo.contextFree(AxisOrderArgument::order));
        speedbuild$register(registry, "area_function", AreaFunctionArgument.class, new AreaFunctionArgument.Info());
    }

    @Unique
    private static <A extends ArgumentType<?>, T extends ArgumentTypeInfo.Template<A>> ArgumentTypeInfo<A, T> speedbuild$register(Registry<ArgumentTypeInfo<?, ?>> registry, String id, Class<? extends A> argumentClass, ArgumentTypeInfo<A, T> info) {
        BY_CLASS.put(argumentClass, info);
        return Registry.register(registry, SpeedBuild.id(id), info);
    }
}
