package com.modcustom.moddev.functions;

import com.modcustom.moddev.SpeedBuild;
import com.modcustom.moddev.events.ClientEventHandler;
import com.modcustom.moddev.utils.ActionResult;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.List;

public class CustomCommandFunction extends AreaFunction {

    private static final ResourceLocation ID = SpeedBuild.id("custom_command");
    private static final String PLACEHOLDER_AREA = "{area}";
    private final String[] commands = {"", "", ""};
    private boolean usePlaceholder = true;

    @Override
    public ResourceLocation getId() {
        return ID;
    }

    @Override
    public ActionResult execute(Level level, BlockPos executionPos, @Nullable BlockPos interactionPos, Player player, @Nullable InteractionHand hand) {
        if (!player.level().isClientSide) return ActionResult.PASS;
        if (Arrays.stream(commands).allMatch(String::isEmpty)) return ActionResult.PASS;
        if (usePlaceholder) {
            return executeWithArea(level, executionPos, area -> {
                for (String str : this.commands) {
                    if (str.isEmpty()) continue;
                    String command = str.replace(PLACEHOLDER_AREA, String.valueOf(area.getId()));
                    if (command.startsWith("/")) {
                        command = command.substring(1);
                    }
                    ClientEventHandler.sendCommand(player, command);
                }
                return true;
            });
        } else {
            for (String str : this.commands) {
                if (str.isEmpty()) continue;
                String command = str;
                if (command.startsWith("/")) {
                    command = command.substring(1);
                }
                ClientEventHandler.sendCommand(player, command);
            }
            return ActionResult.SUCCESS;
        }
    }

    @Override
    public CompoundTag writeNbt(CompoundTag tag) {
        super.writeNbt(tag);
        tag.putString("command1", commands[0]);
        tag.putString("command2", commands[1]);
        tag.putString("command3", commands[2]);
        tag.putBoolean("usePlaceholder", usePlaceholder);
        return tag;
    }

    @Override
    public void readNbt(CompoundTag tag) {
        super.readNbt(tag);
        if (tag.contains("command1")) {
            commands[0] = tag.getString("command1");
        } else if (tag.contains("command")) {
            commands[0] = tag.getString("command");
        }
        if (tag.contains("command2")) {
            commands[1] = tag.getString("command2");
        }
        if (tag.contains("command3")) {
            commands[2] = tag.getString("command3");
        }
        if (tag.contains("usePlaceholder")) {
            usePlaceholder = tag.getBoolean("usePlaceholder");
        }
    }

    @Override
    public Component successComponent() {
        List<String> commandList = Arrays.stream(this.commands).filter(s -> !s.isEmpty()).toList();
        String commands = String.join(", ", commandList);
        return super.successComponent().copy().append(": " + commands);
    }

    @Override
    public boolean requiresAreaId() {
        return false;
    }

    public String getCommand(int index) {
        if (index < 0 || index >= commands.length) return "";
        return commands[index];
    }

    public void setCommand(int index, String command) {
        if (index < 0 || index >= this.commands.length || command == null) return;
        this.commands[index] = command;
    }

    public boolean isUsePlaceholder() {
        return usePlaceholder;
    }

    public void setUsePlaceholder(boolean usePlaceholder) {
        this.usePlaceholder = usePlaceholder;
    }
}
