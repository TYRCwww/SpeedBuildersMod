package com.modcustom.moddev.functions;

import com.modcustom.moddev.SpeedBuild;
import com.modcustom.moddev.utils.ActionResult;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class ResetConstructionAreaFunction extends AreaFunction {

    private static final ResourceLocation ID = SpeedBuild.id("reset_construction_area");

    @Override
    public ResourceLocation getId() {
        return ID;
    }

    @Override
    public ActionResult execute(Level level, BlockPos executionPos, @Nullable BlockPos interactionPos, Player player, @Nullable InteractionHand hand) {
        if (!(level instanceof ServerLevel serverLevel)) return ActionResult.PASS;
        return executeWithArea(level, executionPos, area -> {
            area.startResetConstructionAreaTask(serverLevel);
            return true;
        });
    }
}
