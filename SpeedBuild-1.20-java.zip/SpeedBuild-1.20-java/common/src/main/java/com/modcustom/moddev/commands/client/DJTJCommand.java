package com.modcustom.moddev.commands.client;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.config.Config;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.area.AreaConfig;
import com.modcustom.moddev.network.Network;
import com.modcustom.moddev.utils.TranslationUtil;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Position;
import net.minecraft.world.phys.Vec2;

import java.awt.*;

import static dev.architectury.event.events.client.ClientCommandRegistrationEvent.*;

public class DJTJCommand extends ClientCommand {

    public DJTJCommand() {
        super("djtj");
    }

    @Override
    public LiteralArgumentBuilder<ClientCommandSourceStack> build(LiteralArgumentBuilder<ClientCommandSourceStack> builder, CommandBuildContext context) {
        return builder.then(countdownBuilder()).then(scoreBuilder());
    }

    private LiteralArgumentBuilder<ClientCommandSourceStack> countdownBuilder() {
        return literal("countdown").then(executeSetPos((x, y) -> {
            Config.getInstance().setCountdownPos(new Vec2(x, y));
            return 1;
        })).then(executeSetSize(size -> {
            Config.getInstance().setCountdownSize(size);
            return 1;
        })).then(executeSetColorRGBA((r, g, b, a) -> {
            Config.getInstance().setCountdownColor(new Color(r, g, b, a).getRGB());
            return 1;
        })).then(executeSetColorFormatting(formatting -> {
            Config.getInstance().setCountdownColor(formatting.getColor() != null ? formatting.getColor() : 0);
            return 1;
        })).then(executeSetColor(color -> {
            Config.getInstance().setCountdownColor(color.getRGB());
            return 1;
        })).then(executeSetTimeDisplayText());
    }

    private LiteralArgumentBuilder<ClientCommandSourceStack> executeSetTimeDisplayText() {
        return literal("display").then(argument("time", IntegerArgumentType.integer(0)).then(argument("text", StringArgumentType.greedyString()).executes(context -> {
            Position position = context.getSource().arch$getPosition();
            BlockPos pos = BlockPos.containing(position);
            ActivityArea area = ClientGameManager.getInstance().getActivityAreas(context.getSource().arch$getLevel(), pos).stream().findFirst().orElse(null);
            if (area != null) {
                int time = IntegerArgumentType.getInteger(context, "time");
                String text = StringArgumentType.getString(context, "text");
                area.getConfig().getCountdownText().put(time, text);
                Network.requestModifyAreaConfig(area.getId(), area.getConfig(), true, AreaConfig.Property.COUNTDOWN_TEXT);
                return 1;
            } else {
                context.getSource().arch$sendFailure(TranslationUtil.messageComponent("not_in_area"));
                return 0;
            }
        })));
    }

    private LiteralArgumentBuilder<ClientCommandSourceStack> scoreBuilder() {
        return literal("score").then(executeSetPos((x, y) -> {
            Config.getInstance().setScorePos(new Vec2(x, y));
            return 1;
        })).then(executeSetSize(size -> {
            Config.getInstance().setScoreSize(size);
            return 1;
        })).then(executeSetColorRGBA((r, g, b, a) -> {
            Config.getInstance().setScoreColor(new Color(r, g, b, a).getRGB());
            return 1;
        })).then(executeSetColorFormatting(formatting -> {
            Config.getInstance().setScoreColor(formatting.getColor() != null ? formatting.getColor() : 0);
            return 1;
        })).then(executeSetColor(color -> {
            Config.getInstance().setScoreColor(color.getRGB());
            return 1;
        })).then(executeSetScoreDisplayText());
    }

    private LiteralArgumentBuilder<ClientCommandSourceStack> executeSetScoreDisplayText() {
        return literal("display").then(argument("text", StringArgumentType.greedyString()).executes(context -> {
            Position position = context.getSource().arch$getPosition();
            BlockPos pos = BlockPos.containing(position);
            ActivityArea area = ClientGameManager.getInstance().getActivityAreas(context.getSource().arch$getLevel(), pos).stream().findFirst().orElse(null);
            if (area != null) {
                String text = StringArgumentType.getString(context, "text");
                area.getConfig().setScoreText(text);
                Network.requestModifyAreaConfig(area.getId(), area.getConfig(), true, AreaConfig.Property.SCORE_TEXT);
                return 1;
            } else {
                context.getSource().arch$sendFailure(TranslationUtil.messageComponent("not_in_area"));
                return 0;
            }
        }));
    }
}
