package com.modcustom.moddev.registry;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.client.screen.AreaConfigScreen;
import com.modcustom.moddev.client.screen.PlayerConfigScreen;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.network.Network;
import com.mojang.blaze3d.platform.InputConstants;
import dev.architectury.event.events.client.ClientTickEvent;
import dev.architectury.registry.client.keymappings.KeyMappingRegistry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

import java.util.HashMap;
import java.util.Map;

@Environment(EnvType.CLIENT)
public class ModKeys {

    private static final String CATEGORY = "category.moddev";

    public static final KeyMapping START = new KeyMapping("key.moddev.start", InputConstants.Type.KEYSYM, InputConstants.KEY_N, CATEGORY);
    public static final KeyMapping CLEAR = new KeyMapping("key.moddev.clear", InputConstants.Type.KEYSYM, InputConstants.KEY_L, CATEGORY);
    public static final KeyMapping TIMER = new KeyMapping("key.moddev.timer", InputConstants.Type.KEYSYM, InputConstants.KEY_M, CATEGORY);
    public static final KeyMapping GUI = new KeyMapping("key.moddev.gui", InputConstants.Type.KEYSYM, InputConstants.KEY_K, CATEGORY);
    public static final KeyMapping RUN = new KeyMapping("key.moddev.run", InputConstants.Type.KEYSYM, InputConstants.KEY_J, CATEGORY);
    public static final KeyMapping AIR_SELECTION = new KeyMapping("key.moddev.air_selection", InputConstants.Type.KEYSYM, InputConstants.KEY_LALT, CATEGORY);
    public static final KeyMapping CONFIGURE_AREA = new KeyMapping("key.moddev.configure_area", InputConstants.Type.KEYSYM, InputConstants.KEY_R, CATEGORY);

    private static final Map<KeyMapping, Boolean> KEY_STATES = new HashMap<>();

    public static void register() {
        ClientTickEvent.CLIENT_POST.register(ModKeys::handleKeys);
    }

    public static void handleKeys(Minecraft mc) {
        tryHandleKey(START, mc, ModKeys::handleStartKey);
        tryHandleKey(CLEAR, mc, ModKeys::handleClearKey);
        tryHandleKey(TIMER, mc, ModKeys::handleTimerKey);
        tryHandleKey(GUI, mc, ModKeys::handleGuiKey);
        tryHandleKey(RUN, mc, ModKeys::handleRunKey);
        tryHandleKey(CONFIGURE_AREA, mc, ModKeys::handleConfigurationKey);
    }

    private static void tryHandleKey(KeyMapping keyMapping, Minecraft mc, KeyAction action) {
        if (keyMapping.isDown()) {
            if (!KEY_STATES.getOrDefault(keyMapping, false)) {
                action.execute(mc);
                KEY_STATES.put(keyMapping, true);
            }
        } else {
            KEY_STATES.put(keyMapping, false);
        }
    }

    public static void handleStartKey(Minecraft mc) {
        Network.requestStartActivity();
    }

    public static void handleClearKey(Minecraft mc) {
        Network.requestResetConstructionArea();
    }

    public static void handleTimerKey(Minecraft mc) {
        ClientGameManager.getInstance().toggleTimerDisplay();
    }

    public static void handleGuiKey(Minecraft mc) {
        mc.setScreen(new PlayerConfigScreen());
    }

    public static void handleRunKey(Minecraft mc) {
        ClientGameManager.getInstance().toggleTimer();
    }

    public static void handleConfigurationKey(Minecraft mc) {
        LocalPlayer player = mc.player;
        if (player != null) {
            ActivityArea area = ClientGameManager.getInstance().getCachedData().getAreaFinder().find(mc.level, player.blockPosition());
            if (area != null) {
                mc.setScreen(new AreaConfigScreen(area));
            }
        }
    }

    public static void registerKeys() {
        KeyMappingRegistry.register(START);
        KeyMappingRegistry.register(CLEAR);
        KeyMappingRegistry.register(TIMER);
        KeyMappingRegistry.register(GUI);
        KeyMappingRegistry.register(RUN);
        KeyMappingRegistry.register(AIR_SELECTION);
        KeyMappingRegistry.register(CONFIGURE_AREA);
    }

    @FunctionalInterface
    private interface KeyAction {

        void execute(Minecraft mc);
    }
}
