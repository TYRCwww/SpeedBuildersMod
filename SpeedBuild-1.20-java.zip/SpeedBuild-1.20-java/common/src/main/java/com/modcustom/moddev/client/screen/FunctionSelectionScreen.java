package com.modcustom.moddev.client.screen;

import com.modcustom.moddev.SpeedBuild;
import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.client.components.CallbackCheckbox;
import com.modcustom.moddev.client.components.SmallCheckbox;
import com.modcustom.moddev.functions.AreaFunction;
import com.modcustom.moddev.functions.CustomCommandFunction;
import com.modcustom.moddev.game.area.FunctionArea;
import com.modcustom.moddev.network.Network;
import com.modcustom.moddev.utils.NumberUtil;
import com.modcustom.moddev.utils.TranslationUtil;
import com.modcustom.moddev.utils.Util;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class FunctionSelectionScreen extends SyncScreen {

    private static final ResourceLocation LOCATION = SpeedBuild.id("textures/gui/function_selection.png");
    private static final MutableComponent TITLE = TranslationUtil.screenComponent("function_selection.title").append(" ").append(Component.literal("?").withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.BOLD));
    private static final int TEXTURE_WIDTH = 512;
    private static final int TEXTURE_HEIGHT = 256;
    private static long lastClickTime = -1;
    private static int lastClickIndex = -1;
    private final int imageWidth = 276;
    private final int imageHeight = 166;
    @Nullable
    private final BlockPos areaPos;
    private final FunctionButton[] functionButtons = new FunctionButton[7];
    private long lastUpdateRequestTime = -1;
    private int id;
    private FunctionArea area;
    private int selectedIndex = -1;
    private int scrollOff;
    private boolean isDragging;
    private boolean initialized;

    private SmallCheckbox showResultBox;
    private SmallCheckbox swingHandBox;

    private CallbackCheckbox closestAreaBox;
    private CallbackCheckbox designatedAreaBox;
    private EditBox areaBox;

    private CallbackCheckbox commandPlaceholderBox;
    private EditBox commandBox1;
    private EditBox commandBox2;
    private EditBox commandBox3;

    public FunctionSelectionScreen(FunctionArea area) {
        this(area, null);
    }

    public FunctionSelectionScreen(FunctionArea area, @Nullable BlockPos areaPos) {
        this(area, areaPos, null);
    }

    public FunctionSelectionScreen(FunctionArea area, @Nullable BlockPos areaPos, @Nullable Screen parent) {
        super(TITLE, parent);
        this.area = area;
        this.id = area.getId();
        this.areaPos = areaPos;
    }

    private EditBox createCommandBox(int index, int x, int y, AreaFunction areaFunction) {
        EditBox box = new EditBox(this.font, x, y, 150, 20, TranslationUtil.screenComponent("command"));
        box.setMaxLength(32500);
        if (areaFunction instanceof CustomCommandFunction function) {
            box.setValue(function.getCommand(index));
        }
        box.setResponder(s -> this.setAndRequestUpdate(function -> {
            if (function instanceof CustomCommandFunction customCommandFunction) {
                customCommandFunction.setCommand(index, s);
            }
        }));
        return box;
    }

    protected void setAndRequestUpdate(Consumer<AreaFunction> setter) {
        if (!this.initialized) return;

        AreaFunction function = getSelectedFunction();
        if (function != null) {
            setter.accept(function);
            lastUpdateRequestTime = System.currentTimeMillis();
        }
    }

    private void forceUpdate() {
        if (!this.initialized) return;

        Network.requestModifyFunctionArea(id, area);

        lastUpdateRequestTime = -1;
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.render(guiGraphics, mouseX, mouseY, partialTick);
        List<AreaFunction> functions = this.getFunctions();
        if (!functions.isEmpty()) {
            int leftX = getLeftX();
            int topY = getTopY();
            int yOffset = topY + 16 + 2;
            int textXOffset = leftX + 9;

            this.renderScroller(guiGraphics, leftX, topY, functions);

            int visibleIndexCounter = 0;
            int size = functions.size();
            for (int index = 0; index < size; index++) {
                AreaFunction function = functions.get(index);
                if (shouldSkilFunction(size, visibleIndexCounter)) {
                    ++visibleIndexCounter;
                    continue;
                }

                int color;
                if (this.selectedIndex == index) {
                    if (function.isEnabled()) {
                        color = 0x00AAFF;
                    } else {
                        color = 0xFFFF00;
                    }
                } else {
                    if (function.isEnabled()) {
                        color = 0x00FFFF;
                    } else {
                        color = 0xFFFFFF;
                    }
                }
                FunctionButton.renderScrollingString(guiGraphics, font, function.getDisplayName(), textXOffset, yOffset, textXOffset + 80, yOffset + 20, color);
                yOffset += 20;
                ++visibleIndexCounter;
            }

            updateButtonVisibility();

            int hoveredIndex = getHoveredFunctionIndex();
            renderFunctionDescription(guiGraphics, hoveredIndex);
            renderFunctionName(guiGraphics);
        }

        renderLock(guiGraphics, mouseX, mouseY);
        renderTitleTooltip(guiGraphics, mouseX, mouseY);
    }

    @Override
    public void onClose() {
        forceUpdate();
        super.onClose();
    }

    @Override
    public void renderBackground(GuiGraphics guiGraphics) {
        guiGraphics.blit(LOCATION, getLeftX(), getTopY(), 0, 0.0f, 0.0f, this.imageWidth + 21, this.imageHeight, TEXTURE_WIDTH, TEXTURE_HEIGHT);
        guiGraphics.blit(LOCATION, getLockIconX(), getLockIconY(), 0, this.area.isLocked() ? 0f : 16f, 176f, 16, 16, TEXTURE_WIDTH, TEXTURE_HEIGHT);
    }

    @Override
    protected void renderTitle(GuiGraphics guiGraphics) {
        guiGraphics.drawString(font, String.valueOf(this.area.getId()), getLeftX() + 6, titleY + 1, 0x404040, false);
        guiGraphics.drawString(font, title, getTitleX(), titleY, 0x404040, false);
    }

    @Override
    public void update() {
        if (minecraft != null && areaPos != null) {
            area = ClientGameManager.getInstance().getFunctionArea(minecraft.level, areaPos);
        }
        if (area == null) {
            area = ClientGameManager.getInstance().getFunctionArea(id);
        }
        if (area == null) {
            onClose();
            return;
        }
        id = area.getId();
        updateFocused();
        updateWidgets();
    }

    protected void renderTitleTooltip(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        int titleX = getTitleX();
        if (mouseX >= titleX && mouseX <= titleX + font.width(title) && mouseY >= titleY && mouseY <= titleY + font.lineHeight) {
            ArrayList<Component> tooltips = new ArrayList<>();
            for (int i = 1; i <= 5; i++) {
                tooltips.add(TranslationUtil.screenComponent("function_selection.tooltip." + i).withStyle(ChatFormatting.GRAY));
            }
            guiGraphics.renderComponentTooltip(font, tooltips, mouseX, mouseY);
        }
    }

    public int getTitleX() {
        return getLeftX() + 5 - this.font.width(title) / 2 + 48;
    }

    protected void renderLock(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        int lockIconX = getLockIconX();
        int lockIconY = getLockIconY();
        if (mouseX >= lockIconX && mouseX <= lockIconX + 16 && mouseY >= lockIconY && mouseY <= lockIconY + 16) {
            guiGraphics.renderTooltip(font, TranslationUtil.screenComponent("lock_current_area"), mouseX, mouseY);
        }
    }

    public int getLockIconY() {
        return getTopY() + 5;
    }

    public int getLockIconX() {
        return getLeftX() + this.imageWidth + 1;
    }

    protected void renderFunctionDescription(GuiGraphics guiGraphics, int hoveredIndex) {
        int index = hoveredIndex >= 0 ? hoveredIndex : this.selectedIndex;
        if (index < 0) return;

        List<AreaFunction> functions = this.getFunctions();
        if (index >= functions.size()) return;

        AreaFunction areaFunction = functions.get(index);
        if (areaFunction == null) return;

        Component description = areaFunction.getDescription();
        if (description == null) return;

        Util.drawCenteredStringWithBackground(guiGraphics, description, this.width / 2, getTopY() + this.imageHeight + 6, 0xFFFFFF, 0x50000000);
    }

    public int getHoveredFunctionIndex() {
        int i = -1;
        for (FunctionButton button : this.functionButtons) {
            if (button.isHovered()) {
                i = button.getIndex() + this.scrollOff;
                break;
            }
        }
        return i;
    }

    public void updateButtonVisibility() {
        for (FunctionButton button : this.functionButtons) {
            button.visible = button.index < this.getFunctions().size();
        }
    }

    public boolean shouldSkilFunction(int size, int visibleIndexCounter) {
        return this.canScroll(size) && (visibleIndexCounter < this.scrollOff || visibleIndexCounter >= 7 + this.scrollOff);
    }

    protected void requestUpdate() {
        if (!this.initialized) return;

        lastUpdateRequestTime = System.currentTimeMillis();
    }

    protected void renderFunctionName(GuiGraphics guiGraphics) {
        int selectedIndex = this.selectedIndex;
        if (selectedIndex >= 0) {
            AreaFunction areaFunction = this.getFunctions().get(selectedIndex);
            Component name = areaFunction.getDisplayName();
            guiGraphics.drawString(this.font, name, getLeftX() + 49 + this.imageWidth / 2 - this.font.width(name) / 2, getTopY() + 6, 0x404040, false);
        }
    }

    public int getLeftX() {
        return (this.width - this.imageWidth) / 2;
    }

    public int getTopY() {
        return (this.height - this.imageHeight) / 2;
    }

    protected void renderScroller(GuiGraphics guiGraphics, int posX, int posY, List<AreaFunction> functions) {
        int i = functions.size() + 1 - 7;
        if (i > 1) {
            int j = 139 - (27 + (i - 1) * 139 / i);
            int k = 1 + j / i + 139 / i;
            int l = 113;
            int m = Math.min(l, this.scrollOff * k);
            if (this.scrollOff == i - 1) {
                m = 113;
            }
            guiGraphics.blit(LOCATION, posX + 94, posY + 18 + m, 0, 0.0f, 199.0f, 6, 27, TEXTURE_WIDTH, TEXTURE_HEIGHT);
        } else {
            guiGraphics.blit(LOCATION, posX + 94, posY + 18, 0, 6.0f, 199.0f, 6, 27, TEXTURE_WIDTH, TEXTURE_HEIGHT);
        }
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        int i = this.getFunctions().size();
        if (this.isDragging) {
            int j = this.getTopY() + 18;
            int k = j + 139;
            int l = i - 7;
            float f = ((float) mouseY - (float) j - 13.5f) / ((float) (k - j) - 27.0f);
            f = f * (float) l + 0.5f;
            this.scrollOff = Mth.clamp((int) f, 0, l);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        this.isDragging = false;
        int i = getLeftX();
        int j = getTopY();
        if (this.canScroll(this.getFunctions().size()) && mouseX > i + 94 && mouseX < i + 94 + 6 && mouseY > j + 18 && mouseY <= j + 18 + 139 + 1) {
            this.isDragging = true;
        }

        int lockIconX = this.getLockIconX();
        int lockIconY = this.getLockIconY();
        if (button == 0 && mouseX >= lockIconX && mouseX <= lockIconX + 16 && mouseY >= lockIconY && mouseY <= lockIconY + 16) {
            Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0f));
            boolean locked = this.area.isLocked();
            this.area.setLocked(!locked);
            this.requestUpdate();
            return true;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    public List<AreaFunction> getFunctions() {
        return this.area.getFunctions();
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        int size = this.getFunctions().size();
        if (this.canScroll(size)) {
            int j = size - 7;
            this.scrollOff = Mth.clamp((int) ((double) this.scrollOff - delta), 0, j);

            GuiEventListener focused = this.getFocused();
            if (!(focused instanceof FunctionButton)) {
                updateFocused();
            }
        }
        return true;
    }

    public boolean canScroll(int num) {
        return num > 7;
    }

    protected void updateFocused() {
        AreaFunction function = getSelectedFunction();
        if (function != null) {
            int indexOff = this.selectedIndex - this.scrollOff;
            if (indexOff >= 0 && indexOff < 7) {
                this.setFocused(this.functionButtons[indexOff]);
            }
        }
    }

    @Nullable
    private AreaFunction getSelectedFunction() {
        List<AreaFunction> functions = this.getFunctions();
        if (selectedIndex >= 0 && selectedIndex < functions.size()) {
            return functions.get(selectedIndex);
        }
        return null;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_UP || keyCode == GLFW.GLFW_KEY_DOWN) {
            boolean swapWithPrevious = keyCode == GLFW.GLFW_KEY_UP;
            boolean swapped = this.area.swap(this.selectedIndex, swapWithPrevious);
            if (swapped) {
                this.selectedIndex += swapWithPrevious ? -1 : 1;
                this.requestUpdate();
                this.updateWidgets();
            }
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    protected void updateWidgets() {
        AreaFunction function = getSelectedFunction();

        boolean requiresAreaId = function != null && function.requiresAreaId();
        boolean isCustomCommandFunction = function instanceof CustomCommandFunction;

        this.closestAreaBox.active = requiresAreaId;
        this.closestAreaBox.visible = requiresAreaId;
        this.designatedAreaBox.active = requiresAreaId;
        this.designatedAreaBox.visible = requiresAreaId;
        this.areaBox.active = requiresAreaId;
        this.areaBox.visible = requiresAreaId;

        this.commandPlaceholderBox.active = isCustomCommandFunction;
        this.commandPlaceholderBox.visible = isCustomCommandFunction;
        this.commandBox1.active = isCustomCommandFunction;
        this.commandBox1.visible = isCustomCommandFunction;
        this.commandBox2.active = isCustomCommandFunction;
        this.commandBox2.visible = isCustomCommandFunction;
        this.commandBox3.active = isCustomCommandFunction;
        this.commandBox3.visible = isCustomCommandFunction;

        if (requiresAreaId) {
            int areaId = function.getAreaId();
            this.closestAreaBox.setSelected(areaId == -1);
            this.designatedAreaBox.setSelected(areaId != -1);
            this.areaBox.setValue(String.valueOf(areaId));
        } else if (isCustomCommandFunction) {
            CustomCommandFunction commandFunction = (CustomCommandFunction) function;
            this.commandPlaceholderBox.setSelected(commandFunction.isUsePlaceholder());
            this.commandBox1.setValue(commandFunction.getCommand(0));
            this.commandBox2.setValue(commandFunction.getCommand(1));
            this.commandBox3.setValue(commandFunction.getCommand(2));
        }
    }

    @Override
    protected void init() {
        super.init();
        int leftX = getLeftX();
        int topY = getTopY();
        this.titleY = topY + 6;

        int buttonY = topY + 16 + 2;
        for (int l = 0; l < 7; ++l) {
            this.functionButtons[l] = this.addRenderableWidget(new FunctionButton(leftX + 5, buttonY, l, button -> {
                if (button instanceof FunctionButton functionButton) {
                    this.selectedIndex = functionButton.getIndex() + this.scrollOff;
                    this.updateWidgets();

                    if (this.selectedIndex != lastClickIndex) {
                        lastClickTime = -1;
                    }
                    if (System.currentTimeMillis() - lastClickTime < 250 || hasShiftDown()) {
                        lastClickIndex = -1;
                        AreaFunction function = this.getSelectedFunction();
                        if (function != null) {
                            function.setEnabled(!function.isEnabled());
                        }
                    } else {
                        lastClickIndex = this.selectedIndex;
                    }
                    lastClickTime = System.currentTimeMillis();
                }
            }));
            buttonY += 20;
        }
        updateFocused();

        int checkBoxY = topY + this.imageHeight - 20;
        MutableComponent component = TranslationUtil.screenComponent("show_result").withStyle(ChatFormatting.WHITE);
        this.showResultBox = new SmallCheckbox(font, leftX + 100 + 5, checkBoxY, component, this.area.isShowResult(), (button, checked) -> {
            this.area.setShowResult(checked);
            requestUpdate();
        });
        this.addRenderableWidget(this.showResultBox);

        this.swingHandBox = new SmallCheckbox(font, this.showResultBox.getX() + this.showResultBox.getWidth() + 5, checkBoxY, TranslationUtil.screenComponent("swing_hand_when_triggered").withStyle(ChatFormatting.WHITE), this.area.isSwingHand(), (button, checked) -> {
            this.area.setSwingHand(checked);
            requestUpdate();
        });
        this.addRenderableWidget(this.swingHandBox);

        int x = leftX + 100 + 10;
        int y = topY + 17 + 5;

        AreaFunction selectedFunction = getSelectedFunction();
        int areaId = selectedFunction != null ? selectedFunction.getAreaId() : -1;
        this.closestAreaBox = new CallbackCheckbox(font, x, y, TranslationUtil.screenComponent("nearest_area").withStyle(ChatFormatting.WHITE), areaId == -1, true, checked -> {
            if (checked) {
                this.designatedAreaBox.setSelected(false);
                setAndRequestUpdate(function -> function.setAreaId(-1));
                return true;
            }
            return false;
        });
        this.addRenderableWidget(this.closestAreaBox);
        y += 25;

        this.designatedAreaBox = new CallbackCheckbox(font, x, y, TranslationUtil.screenComponent("designated_area").withStyle(ChatFormatting.WHITE), areaId != -1, true, checked -> {
            if (checked) {
                this.closestAreaBox.setSelected(false);
                String value = this.areaBox.getValue();
                if (NumberUtil.isIntBetween(value, Integer.MIN_VALUE, 0)) {
                    this.areaBox.setValue("0");
                }
                setAndRequestUpdate(function -> NumberUtil.getOptionalInt(this.areaBox.getValue()).ifPresent(function::setAreaId));
                return true;
            }
            return false;
        });
        this.addRenderableWidget(this.designatedAreaBox);
        y += 25;

        this.areaBox = new EditBox(this.font, x, y, 100, 20, TranslationUtil.screenComponent("designated_area"));
        this.areaBox.setValue(String.valueOf(areaId));
        this.areaBox.setFilter(s -> NumberUtil.isIntBetweenOrEmpty(s, -1, Integer.MAX_VALUE));
        this.areaBox.setResponder(s -> this.setAndRequestUpdate(function -> NumberUtil.getOptionalInt(s).ifPresent(function::setAreaId)));
        this.addRenderableWidget(this.areaBox);

        y = topY + 17 + 5;
        this.commandPlaceholderBox = new CallbackCheckbox(font, x, y, TranslationUtil.screenComponent("command_placeholder").withStyle(ChatFormatting.WHITE), selectedFunction instanceof CustomCommandFunction function && function.isUsePlaceholder(), true, checked -> {
            this.setAndRequestUpdate(function -> {
                if (function instanceof CustomCommandFunction customCommandFunction) {
                    customCommandFunction.setUsePlaceholder(checked);
                }
            });
            return true;
        });
        y += 25;

        this.commandBox1 = createCommandBox(0, x, y, selectedFunction);
        y += 25;
        this.commandBox2 = createCommandBox(1, x, y, selectedFunction);
        y += 25;
        this.commandBox3 = createCommandBox(2, x, y, selectedFunction);

        this.updateWidgets();
        this.addRenderableWidget(this.commandPlaceholderBox);
        this.addRenderableWidget(this.commandBox1);
        this.addRenderableWidget(this.commandBox2);
        this.addRenderableWidget(this.commandBox3);

        this.initialized = true;
    }

    @Override
    public void tick() {
        super.tick();
        areaBox.tick();
        commandBox1.tick();
        commandBox2.tick();
        commandBox3.tick();
        checkForUpdate();
    }

    private void checkForUpdate() {
        if (!this.initialized || lastUpdateRequestTime == -1) return;

        if (System.currentTimeMillis() - lastUpdateRequestTime < 1500) return;

        Network.requestModifyFunctionArea(id, area);

        lastUpdateRequestTime = -1;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Environment(value = EnvType.CLIENT)
    public static class FunctionButton extends Button {

        private final int index;

        public FunctionButton(int x, int y, int index, OnPress onPress) {
            super(x, y, 88, 20, CommonComponents.EMPTY, onPress, DEFAULT_NARRATION);
            this.index = index;
            this.visible = false;
        }

        public int getIndex() {
            return this.index;
        }

        public static void renderScrollingString(GuiGraphics guiGraphics, Font font, Component text, int minX, int minY, int maxX, int maxY, int color) {
            AbstractButton.renderScrollingString(guiGraphics, font, text, minX, minY, maxX, maxY, color);
        }
    }
}
