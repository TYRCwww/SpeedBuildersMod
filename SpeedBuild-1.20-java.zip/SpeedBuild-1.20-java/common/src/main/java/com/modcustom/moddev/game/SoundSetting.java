package com.modcustom.moddev.game;

import com.modcustom.moddev.api.SerializableData;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class SoundSetting implements SerializableData<SoundSetting> {

    @Nullable
    private SoundEvent sound;
    private float volume;
    private float pitch;

    public SoundSetting(@Nullable SoundEvent sound) {
        this(sound, 1f, 1f);
    }

    public SoundSetting(@Nullable SoundEvent sound, float volume, float pitch) {
        this.sound = sound;
        this.volume = Math.max(volume, 0f);
        this.pitch = Math.min(Math.max(pitch, 0f), 2f);
    }

    @Nullable
    public SoundEvent getSound() {
        return sound;
    }

    public void setSound(@Nullable SoundEvent sound) {
        this.sound = sound;
    }

    public float getVolume() {
        return volume;
    }

    public void setVolume(float volume) {
        this.volume = Math.max(volume, 0f);
    }

    public float getPitch() {
        return pitch;
    }

    public void setPitch(float pitch) {
        this.pitch = Math.min(Math.max(pitch, 0f), 2f);
    }

    public void play(Player player) {
        if (sound != null) {
            player.playNotifySound(sound, SoundSource.VOICE, volume, pitch);
        }
    }

    public void play(Level level, BlockPos pos, @Nullable Player except) {
        if (sound != null) {
            level.playSound(except, pos, sound, SoundSource.VOICE, volume, pitch);
        }
    }

    @Override
    public void save(CompoundTag tag) {
        if (sound != null) {
            tag.putString("sound", sound.getLocation().toString());
        }
        tag.putFloat("volume", volume);
        tag.putFloat("pitch", pitch);
    }

    @Override
    public void load(CompoundTag tag) {
        if (tag.contains("sound")) {
            ResourceLocation location = ResourceLocation.tryParse(tag.getString("sound"));
            if (location != null) {
                this.sound = BuiltInRegistries.SOUND_EVENT.get(location);
            } else {
                this.sound = null;
            }
        }
        if (tag.contains("volume")) {
            this.volume = tag.getFloat("volume");
        }
        if (tag.contains("pitch")) {
            this.pitch = tag.getFloat("pitch");
        }
    }

    @Override
    public void copyFrom(SoundSetting data) {
        this.sound = data.sound;
        this.volume = data.volume;
        this.pitch = data.pitch;
    }

    @Override
    public String toString() {
        return String.format(
                "SoundSetting(sound: %s, " +
                "volume: %.2f, " +
                "pitch: %.2f)",
                sound != null ? sound.getLocation().toString() : "null",
                volume,
                pitch
        );
    }


    @Nullable
    public static SoundEvent tryParse(String sound) {
        ResourceLocation resourceLocation = ResourceLocation.tryParse(sound);
        return resourceLocation != null ? BuiltInRegistries.SOUND_EVENT.get(resourceLocation) : null;
    }
}
