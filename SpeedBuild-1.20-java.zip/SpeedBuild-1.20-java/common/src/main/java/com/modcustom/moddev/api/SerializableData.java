package com.modcustom.moddev.api;

import com.mojang.logging.LogUtils;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtIo;
import org.slf4j.Logger;

import java.io.File;
import java.io.IOException;

public interface SerializableData<T extends SerializableData<T>> extends SavableData {

    Logger LOGGER = LogUtils.getLogger();

    default T readNbt(CompoundTag tag) {
        load(tag);
        return (T) this;
    }

    void load(CompoundTag tag);

    default T copy(T data) {
        copyFrom(data);
        return (T) this;
    }

    default void copyFrom(T data) {
        copyByTag(data);
    }

    default void copyByTag(T data) {
        load(data.toNbt());
    }

    static CompoundTag load(File file) {
        try {
            return NbtIo.readCompressed(file);
        } catch (IOException e) {
            LOGGER.error("Could not load data from {}", file, e);
            return null;
        }
    }
}
