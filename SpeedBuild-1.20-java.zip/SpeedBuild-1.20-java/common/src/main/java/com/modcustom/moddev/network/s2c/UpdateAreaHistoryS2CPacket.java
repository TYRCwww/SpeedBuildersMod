package com.modcustom.moddev.network.s2c;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.activity.ActivityRecord;
import dev.architectury.networking.NetworkManager;
import dev.architectury.utils.Env;
import net.minecraft.network.FriendlyByteBuf;

import java.util.List;
import java.util.Objects;
import java.util.function.Supplier;

public class UpdateAreaHistoryS2CPacket implements NetworkPacket {

    private final int id;
    private final List<ActivityRecord> history;
    private final boolean replace;

    public UpdateAreaHistoryS2CPacket(FriendlyByteBuf buf) {
        this(buf.readInt(), buf.readList(byteBuf -> ActivityRecord.fromNbt(Objects.requireNonNull(byteBuf.readAnySizeNbt()))), buf.readBoolean());
    }

    public UpdateAreaHistoryS2CPacket(int id, List<ActivityRecord> history, boolean replace) {
        this.id = id;
        this.history = history;
        this.replace = replace;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(id);
        buf.writeCollection(history, (byteBuf, record) -> byteBuf.writeNbt(record.toNbt()));
        buf.writeBoolean(replace);
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        NetworkManager.PacketContext context = contextSupplier.get();
        if (context.getEnvironment() == Env.CLIENT) {
            ClientGameManager.getInstance().updateAreaHistory(id, history, replace);
        }
    }
}
