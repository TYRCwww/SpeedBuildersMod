package com.modcustom.moddev.commands.common;

import com.modcustom.moddev.game.area.ProtectedArea;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.utils.TranslationUtil;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Position;

import java.util.List;

public class FPHCommand extends CommonCommand {

    public FPHCommand() {
        super("fph");
    }

    @Override
    public LiteralArgumentBuilder<CommandSourceStack> build(LiteralArgumentBuilder<CommandSourceStack> builder, CommandBuildContext context) {
        return builder.requires(source -> source.hasPermission(2)).then(executeAdd()).then(executeRemove()).then(executeToggleActive());
    }

    private LiteralArgumentBuilder<CommandSourceStack> executeAdd() {
        return Commands.literal("add").then(Commands.argument("from", BlockPosArgument.blockPos()).then(Commands.argument("to", BlockPosArgument.blockPos()).executes(context -> {
            BlockPos from = BlockPosArgument.getBlockPos(context, "from");
            BlockPos to = BlockPosArgument.getBlockPos(context, "to");
            boolean success = ProtectedArea.add(context.getSource().getLevel(), new ProtectedArea(from, to), true, true);
            if (success) {
                context.getSource().sendSuccess(() -> TranslationUtil.messageComponent("create_protected_area"), true);
                return 1;
            } else {
                context.getSource().sendFailure(TranslationUtil.messageComponent("area_intersected"));
                return 0;
            }
        })));
    }

    private LiteralArgumentBuilder<CommandSourceStack> executeRemove() {
        return Commands.literal("remove").executes(context -> {
            CommandSourceStack source = context.getSource();
            Position position = source.getPosition();
            boolean success = ProtectedArea.remove(source.getLevel(), BlockPos.containing(position), true);
            if (success) {
                source.sendSuccess(() -> TranslationUtil.messageComponent("protected_area.delete"), true);
                return 1;
            } else {
                source.sendFailure(TranslationUtil.messageComponent("protected_area.not_found"));
                return 0;
            }
        }).then(Commands.argument("pos", BlockPosArgument.blockPos()).executes(context -> {
            BlockPos pos = BlockPosArgument.getBlockPos(context, "pos");
            boolean success = ProtectedArea.remove(context.getSource().getLevel(), pos, true);
            if (success) {
                context.getSource().sendSuccess(() -> TranslationUtil.messageComponent("protected_area.delete"), true);
                return 1;
            } else {
                context.getSource().sendFailure(TranslationUtil.messageComponent("protected_area.not_found"));
                return 0;
            }
        }));
    }

    private LiteralArgumentBuilder<CommandSourceStack> executeToggleActive() {
        return Commands.literal("toggle").executes(context -> {
            CommandSourceStack source = context.getSource();
            List<ProtectedArea> protectedAreas = GameData.getGameData(context).getProtectedAreas(source.getLevel());
            ProtectedArea area = protectedAreas.stream().filter(a -> {
                Position position = source.getPosition();
                return a.contains(BlockPos.containing(position));
            }).findFirst().orElse(null);
            if (area != null) {
                area.setActive(!area.isActive());
                source.sendSuccess(() -> TranslationUtil.messageComponent("protected_area." + (area.isActive() ? "active" : "deactivate")), true);
                return 1;
            } else {
                source.sendFailure(TranslationUtil.messageComponent("protected_area.not_found"));
                return 0;
            }
        });
    }
}
