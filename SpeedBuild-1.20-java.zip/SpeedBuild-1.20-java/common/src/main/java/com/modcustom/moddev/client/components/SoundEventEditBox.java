package com.modcustom.moddev.client.components;

import com.modcustom.moddev.game.SoundSetting;
import com.modcustom.moddev.utils.TranslationUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.FormattedCharSequence;
import org.jetbrains.annotations.Nullable;

import java.awt.*;
import java.util.function.Consumer;
import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class SoundEventEditBox extends EditBox {

    private final Font font;
    private final SoundSetting setting;
    private final String defaultValue;
    @Nullable
    private Runnable postResponder;
    private boolean autoSetting = true;

    public SoundEventEditBox(Font font, SoundSetting setting, Component message, String defaultValue, Consumer<String> suggestionSetter) {
        super(font, 0, 0, 200, 20, message);
        this.font = font;
        this.setting = setting;
        this.defaultValue = defaultValue;
        SoundEvent sound = setting.getSound();
        this.setMaxLength(256);
        this.setValue(sound != null ? sound.getLocation().toString() : "");
        this.setFormatter((t, i) -> {
            int color = (SoundSetting.tryParse(this.getValue()) != null) ? Color.GREEN.getRGB() : Color.WHITE.getRGB();
            return FormattedCharSequence.forward(t, Style.EMPTY.withColor(color));
        });
        setResponderWithSuggestion(suggestionSetter);
    }

    private void setResponderWithSuggestion(Consumer<String> suggestionSetter) {
        this.setResponder(s -> {
            SoundEvent soundEvent = SoundSetting.tryParse(s);
            if (this.isAutoSetting()) {
                this.setting.setSound(s.isEmpty() ? null : soundEvent);
            }
            if (this.postResponder != null) this.postResponder.run();
            String suggestion = s.isEmpty() || soundEvent != null ? null : BuiltInRegistries.SOUND_EVENT.stream().map(event -> event.getLocation().toString()).filter(name -> name.startsWith(s) && name.length() > s.length()).findFirst().map(name -> name.substring(s.length())).orElse(null);
            this.setSuggestion(suggestion);
            suggestionSetter.accept(suggestion);
        });
    }

    public AbstractWidget[] createRow() {
        return new AbstractWidget[]{new StringWidget(this.getMessage(), this.font).alignCenter(), this, createResetButton()};
    }

    public Button createResetButton() {
        return Button.builder(TranslationUtil.screenComponent("reset_button"), button -> this.setValue(defaultValue)).size(50, 20).build();
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers, Supplier<String> suggestionSupplier) {
        if (this.isFocused() && keyCode == 258) {
            String suggestion = suggestionSupplier.get();
            if (suggestion != null && this.getCursorPosition() == this.getValue().length()) {
                this.insertText(suggestion);
            }
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    public void setPostResponder(@Nullable Runnable postResponder) {
        this.postResponder = postResponder;
    }

    public boolean isAutoSetting() {
        return autoSetting;
    }

    public void setAutoSetting(boolean autoSetting) {
        this.autoSetting = autoSetting;
    }
}
