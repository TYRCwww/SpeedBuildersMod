package com.modcustom.moddev.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import dev.architectury.platform.Platform;
import net.minecraft.resources.ResourceLocation;
import org.slf4j.Logger;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.*;

import static com.modcustom.moddev.SpeedBuild.MOD_ID;

@SuppressWarnings("unused")
public class GlobeConfig {

    private static final Logger LOGGER = LogUtils.getLogger();
    private static final String CONFIG_NAME = MOD_ID + "-globe";
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static File file = null;
    private static GlobeConfig instance = new GlobeConfig();
    private Map<String, Set<String>> exceptAttributes = new HashMap<>() {{
        put("entity", new HashSet<>(List.of("Pos", "Motion", "Rotation", "UUID", "TileX", "TileY", "TileZ")));
        put("block", new HashSet<>());
        put("storage", new HashSet<>());
        put("entity:minecraft:example", new HashSet<>(List.of("Example")));
    }};
    private final String _exceptAttributes = "排除检测属性[entity(实体)/block(方块)/storage(方块实体)] 特例: 类型:ID(例如:entity:minecraft:cow 表示 实体牛)";
    private Map<String, Set<String>> strictAttributes = new HashMap<>() {{
        put("entity:minecraft:armor_stand", new HashSet<>(List.of("Rotation")));
    }};
    private final String _strictAttributes = "严格检测属性，将无视排除检测(例如:entity:minecraft:cow)";

    public Map<String, Set<String>> getExceptAttributes() {
        return exceptAttributes;
    }

    public void setExceptAttributes(Map<String, Set<String>> exceptAttributes) {
        this.exceptAttributes = exceptAttributes;
        save();
    }

    public static void load() {
        prepareConfigFile();
        if (!file.exists()) {
            save();
        } else {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                JsonElement jsonElement = JsonParser.parseReader(br);
                GlobeConfig config = fromJson(jsonElement.toString());
                if (config != null) {
                    instance = config;
                } else {
                    save();
                }
            } catch (Exception e) {
                LOGGER.error("Couldn't load file {}.json; reverting to defaults", CONFIG_NAME, e);
                save();
            }
        }
    }

    public static void save() {
        prepareConfigFile();
        try (FileWriter fileWriter = new FileWriter(file)) {
            fileWriter.write(instance.toJson());
        } catch (Exception e) {
            LOGGER.error("Couldn't save file {}.json", CONFIG_NAME, e);
        }
    }

    public String toJson() {
        return GSON.toJson(this);
    }

    public Map<String, Set<String>> getStrictAttributes() {
        return strictAttributes;
    }

    public void setStrictAttributes(Map<String, Set<String>> strictAttributes) {
        this.strictAttributes = strictAttributes;
        save();
    }

    public Set<String> getExceptAttributes(String type, ResourceLocation id) {
        Set<String> result = new HashSet<>();
        if (exceptAttributes.containsKey(type)) {
            result.addAll(exceptAttributes.get(type));
        }
        if (id != null) {
            String key = type + ":" + id.getNamespace() + ":" + id.getPath();
            if (exceptAttributes.containsKey(key)) {
                Set<String> strictSet = strictAttributes.getOrDefault(key, new HashSet<>());
                for (String attr : exceptAttributes.get(key)) {
                    if (!strictSet.contains(attr)) {
                        result.add(attr);
                    }
                }
            }
        }
        return result;
    }

    public static GlobeConfig getInstance() {
        return instance;
    }

    private static void prepareConfigFile() {
        if (file == null) {
            file = new File(Platform.getConfigFolder().toFile(), CONFIG_NAME + ".json");
        }
    }

    public static GlobeConfig fromJson(String json) {
        return GSON.fromJson(json, GlobeConfig.class);
    }
}
