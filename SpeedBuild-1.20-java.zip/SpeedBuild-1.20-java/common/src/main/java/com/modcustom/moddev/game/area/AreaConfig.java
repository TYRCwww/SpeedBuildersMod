package com.modcustom.moddev.game.area;

import com.modcustom.moddev.api.SerializableData;
import com.modcustom.moddev.game.BaseSetting;
import com.modcustom.moddev.game.EntityDetectionMode;
import com.modcustom.moddev.game.SoundSetting;
import com.modcustom.moddev.game.data.ItemGivingData;
import com.modcustom.moddev.utils.NumberUtil;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;

public class AreaConfig implements SerializableData<AreaConfig> {

    public static final String DEFAULT_SCORE_TEXT = "#Time";
    private static final String TIME_PLACEHOLDER = "#Time";
    private final Map<Integer, String> countdownText = new HashMap<>(Map.of(0, getDefaultStartText()));
    private final Set<String> forcedPlayers = new HashSet<>();
    private final ItemGivingData itemGivingData = new ItemGivingData();
    private final BaseSetting baseSetting = new BaseSetting();
    private final SoundSetting countdownSound = new SoundSetting(SoundEvents.NOTE_BLOCK_PLING.value());
    private final SoundSetting startSound = new SoundSetting(SoundEvents.NOTE_BLOCK_PLING.value(), 1f, 2f);
    private final SoundSetting finishSound = new SoundSetting(SoundEvents.PLAYER_LEVELUP);
    private int countdown = 3;
    private String scoreText = DEFAULT_SCORE_TEXT;
    private boolean simpleMode = false;
    private boolean renderBorder = true;
    private EntityDetectionMode entityDetection = EntityDetectionMode.ATTRIBUTES;
    private boolean entityMove = true;
    private int historyLimit = 10;
    private boolean entityInstantKill = false;

    public int getCountdown() {
        return countdown;
    }

    public void setCountdown(int countdown) {
        this.countdown = countdown;
    }

    public Map<Integer, String> getCountdownText() {
        return countdownText;
    }

    public void setCountdownText(Map<Integer, String> countdownText) {
        this.countdownText.clear();
        this.countdownText.putAll(countdownText);
    }

    public String getScoreText() {
        return scoreText;
    }

    public void setScoreText(String scoreText) {
        this.scoreText = scoreText;
    }

    public boolean isSimpleMode() {
        return simpleMode;
    }

    public void setSimpleMode(boolean simpleMode) {
        this.simpleMode = simpleMode;
    }

    public boolean isRenderBorder() {
        return renderBorder;
    }

    public void setRenderBorder(boolean renderBorder) {
        this.renderBorder = renderBorder;
    }

    public Set<String> getForcedPlayers() {
        return forcedPlayers;
    }

    public void setForcedPlayers(Set<String> forcedPlayers) {
        this.forcedPlayers.clear();
        this.forcedPlayers.addAll(forcedPlayers);
    }

    public SoundSetting getCountdownSound() {
        return countdownSound;
    }

    public void setCountdownSound(SoundSetting countdownSound) {
        this.countdownSound.copyFrom(countdownSound);
    }

    public SoundSetting getStartSound() {
        return startSound;
    }

    public void setStartSound(SoundSetting startSound) {
        this.startSound.copyFrom(startSound);
    }

    public SoundSetting getFinishSound() {
        return finishSound;
    }

    public void setFinishSound(SoundSetting finishSound) {
        this.finishSound.copyFrom(finishSound);
    }

    public EntityDetectionMode getEntityDetection() {
        return entityDetection;
    }

    public void setEntityDetection(EntityDetectionMode entityDetection) {
        this.entityDetection = entityDetection;
    }

    public boolean isEntityMove() {
        return entityMove;
    }

    public void setEntityMove(boolean entityMove) {
        this.entityMove = entityMove;
    }

    public ItemGivingData getItemGivingData() {
        return itemGivingData;
    }

    public void setItemGivingData(ItemGivingData itemGivingData) {
        this.itemGivingData.copyFrom(itemGivingData);
    }

    public int getHistoryLimit() {
        return historyLimit;
    }

    public void setHistoryLimit(int historyLimit) {
        this.historyLimit = historyLimit;
    }

    public boolean isEntityInstantKill() {
        return entityInstantKill;
    }

    public void setEntityInstantKill(boolean entityInstantKill) {
        this.entityInstantKill = entityInstantKill;
    }

    public BaseSetting getBaseSetting() {
        return baseSetting;
    }

    public void setBaseSetting(BaseSetting baseSetting) {
        this.baseSetting.copyFrom(baseSetting);
    }

    @Override
    public void save(CompoundTag tag) {
        tag.putInt("countdown", countdown);
        CompoundTag countdownTextTag = new CompoundTag();
        countdownText.forEach((k, v) -> countdownTextTag.putString(k.toString(), v));
        tag.put("countdownText", countdownTextTag);
        tag.putString("scoreText", scoreText);
        tag.putBoolean("simpleMode", simpleMode);
        tag.putBoolean("renderBorder", renderBorder);
        if (!forcedPlayers.isEmpty()) {
            tag.putString("forcedPlayers", String.join(",", forcedPlayers));
        }
        tag.put("countdownSound", countdownSound.toNbt());
        tag.put("startSound", startSound.toNbt());
        tag.put("finishSound", finishSound.toNbt());
        tag.putInt("entityDetection", entityDetection.ordinal());
        tag.putBoolean("entityMove", entityMove);
        tag.put("itemGivingData", itemGivingData.toNbt());
        tag.putInt("historyLimit", historyLimit);
        tag.putBoolean("entityInstantKill", entityInstantKill);
        tag.put("baseSetting", baseSetting.toNbt());
    }

    @Override
    public String toString() {
        return String.format(
                "AreaConfig(countdown: %d, " +
                "countdownText: %s, " +
                "scoreText: %s, " +
                "simpleMode: %b, " +
                "renderBorder: %b, " +
                "forcedPlayers: %s, " +
                "countdownSound: %s, " +
                "startSound: %s, " +
                "finishSound: %s, " +
                "entityDetection: %s, " +
                "entityMove: %b, " +
                "itemGivingData: %s, " +
                "historyLimit: %d, " +
                "entityInstantKill: %b, " +
                "baseSetting: %s)",
                countdown,
                countdownText.entrySet().stream().map(e -> e.getKey() + ": " + e.getValue()).collect(Collectors.joining(", ")),
                scoreText,
                simpleMode,
                renderBorder,
                String.join(", ", forcedPlayers),
                countdownSound,
                startSound,
                finishSound,
                entityDetection.getComponent().getString(),
                entityMove,
                itemGivingData,
                historyLimit,
                entityInstantKill,
                baseSetting
        );
    }

    public String formattedCountdownText(int countdown) {
        return countdownText.getOrDefault(countdown, String.valueOf(countdown));
    }

    public String formattedScoreText(String score) {
        return scoreText.replace(TIME_PLACEHOLDER, score);
    }

    public List<ServerPlayer> getForcedPlayers(ServerLevel level) {
        if (forcedPlayers.isEmpty()) {
            return List.of();
        }
        return level.getServer().getPlayerList().getPlayers().stream().filter(player -> forcedPlayers.contains(player.getDisplayName().getString())).collect(Collectors.toList());
    }

    @Override
    public void load(CompoundTag tag) {
        if (tag.contains("countdown")) {
            this.countdown = tag.getInt("countdown");
        }
        if (tag.contains("countdownText")) {
            CompoundTag countdownTextTag = tag.getCompound("countdownText");
            countdownTextTag.getAllKeys().forEach(key -> NumberUtil.getOptionalInt(key).ifPresent(i -> this.countdownText.put(i, countdownTextTag.getString(key))));
        }
        if (tag.contains("scoreText")) {
            this.scoreText = tag.getString("scoreText");
        }
        if (tag.contains("simpleMode")) {
            this.simpleMode = tag.getBoolean("simpleMode");
        }
        if (tag.contains("renderBorder")) {
            this.renderBorder = tag.getBoolean("renderBorder");
        }
        if (tag.contains("forcedPlayers")) {
            this.forcedPlayers.addAll(Arrays.asList(tag.getString("forcedPlayers").split(",")));
        }
        if (tag.contains("countdownSound")) {
            this.countdownSound.readNbt(tag.getCompound("countdownSound"));
        }
        if (tag.contains("startSound")) {
            this.startSound.readNbt(tag.getCompound("startSound"));
        }
        if (tag.contains("finishSound")) {
            this.finishSound.readNbt(tag.getCompound("finishSound"));
        }
        if (tag.contains("entityDetection")) {
            int ordinal = tag.getInt("entityDetection");
            if (ordinal >= 0 && ordinal < EntityDetectionMode.values().length) {
                this.entityDetection = EntityDetectionMode.values()[ordinal];
            }
        }
        if (tag.contains("entityMove")) {
            this.entityMove = tag.getBoolean("entityMove");
        }
        if (tag.contains("itemGivingData")) {
            this.itemGivingData.copyFrom(ItemGivingData.fromNbt(tag.getCompound("itemGivingData")));
        }
        if (tag.contains("historyLimit")) {
            this.historyLimit = tag.getInt("historyLimit");
        }
        if (tag.contains("entityInstantKill")) {
            this.entityInstantKill = tag.getBoolean("entityInstantKill");
        }
        if (tag.contains("baseSetting")) {
            this.baseSetting.copyFrom(BaseSetting.fromNbt(tag.getCompound("baseSetting")));
        }
    }

    @Override
    public void copyFrom(AreaConfig data) {
        this.countdown = data.countdown;
        this.countdownText.clear();
        this.countdownText.putAll(data.countdownText);
        this.scoreText = data.scoreText;
        this.simpleMode = data.simpleMode;
        this.renderBorder = data.renderBorder;
        this.forcedPlayers.clear();
        this.forcedPlayers.addAll(data.forcedPlayers);
        this.countdownSound.copyFrom(data.countdownSound);
        this.startSound.copyFrom(data.startSound);
        this.finishSound.copyFrom(data.finishSound);
        this.entityDetection = data.entityDetection;
        this.entityMove = data.entityMove;
        this.itemGivingData.copyFrom(data.itemGivingData);
        this.historyLimit = data.historyLimit;
        this.entityInstantKill = data.entityInstantKill;
        this.baseSetting.copyFrom(data.baseSetting);
    }

    public static AreaConfig fromNbt(CompoundTag tag) {
        AreaConfig config = new AreaConfig();
        if (tag == null) return config;
        return config.readNbt(tag);
    }

    public static String getDefaultStartText() {
        return Component.translatable("area.moddev.countdown.start.text").getString();
    }

    public enum Property {
        COUNTDOWN((old, config) -> old.setCountdown(config.countdown)),
        COUNTDOWN_TEXT((old, config) -> old.setCountdownText(config.countdownText)),
        SCORE_TEXT((old, config) -> old.setScoreText(config.scoreText)),
        SIMPLE_MODE((old, config) -> old.setSimpleMode(config.simpleMode)),
        RENDER_BORDER((old, config) -> old.setRenderBorder(config.renderBorder)),
        FORCED_PLAYERS((old, config) -> old.setForcedPlayers(config.forcedPlayers)),
        COUNTDOWN_SOUND((old, config) -> old.setCountdownSound(config.countdownSound)),
        START_SOUND((old, config) -> old.setStartSound(config.startSound)),
        FINISH_SOUND((old, config) -> old.setFinishSound(config.finishSound)),
        ENTITY_DETECTION((old, config) -> old.setEntityDetection(config.entityDetection)),
        ENTITY_MOVE((old, config) -> old.setEntityMove(config.entityMove)),
        ITEM_GIVING_DATA((old, config) -> old.setItemGivingData(config.itemGivingData)),
        HISTORY_LIMIT((old, config) -> old.setHistoryLimit(config.historyLimit)),
        ENTITY_INSTANT_KILL((old, config) -> old.setEntityInstantKill(config.entityInstantKill)),
        BASE_SETTING((old, config) -> old.setBaseSetting(config.baseSetting));

        private final BiConsumer<AreaConfig, AreaConfig> setter;

        Property(BiConsumer<AreaConfig, AreaConfig> setter) {
            this.setter = setter;
        }

        public void set(AreaConfig oldConfig, AreaConfig newConfig) {
            setter.accept(oldConfig, newConfig);
        }
    }
}
