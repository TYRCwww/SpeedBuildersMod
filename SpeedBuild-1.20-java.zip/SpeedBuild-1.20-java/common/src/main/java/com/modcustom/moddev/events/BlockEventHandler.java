package com.modcustom.moddev.events;

import com.modcustom.moddev.game.activity.Activity;
import com.modcustom.moddev.game.activity.ActivityManager;
import com.modcustom.moddev.game.area.FunctionArea;
import com.modcustom.moddev.game.area.ProtectedArea;
import com.modcustom.moddev.utils.PlayerUtil;
import com.modcustom.moddev.utils.TranslationUtil;
import dev.architectury.event.EventResult;
import dev.architectury.event.events.common.BlockEvent;
import dev.architectury.utils.value.IntValue;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

public class BlockEventHandler {

    public static void register() {
        BlockEvent.PLACE.register(BlockEventHandler::handlePlaceBlock);
        BlockEvent.BREAK.register(BlockEventHandler::handleBreakBlock);
    }

    private static EventResult handlePlaceBlock(Level level, BlockPos pos, BlockState state, Entity entity) {
        if (entity instanceof Player player && PlayerUtil.getGameMode(player) == GameType.ADVENTURE && !allowAdventureBlockAction(level, pos)) {
            return EventResult.interruptFalse();
        }
        if (state.isAir()) return EventResult.pass();
        Activity.tryStartActivity(level, pos, entity);
        if (level instanceof ServerLevel serverLevel) {
            ActivityManager.getActivities(serverLevel, pos).forEach(Activity::markBlockPlaced);
        }
        return EventResult.pass();
    }

    public static boolean allowAdventureBlockAction(Level level, BlockPos blockPos) {
        return ProtectedArea.hasArea(level, blockPos);
    }

    private static EventResult handleBreakBlock(Level level, BlockPos blockPos, BlockState blockState, ServerPlayer player, IntValue value) {
        if (ProtectedArea.isProtected(level, blockPos)) {
            player.sendSystemMessage(TranslationUtil.messageComponent("protected_area.break_block"), true);
            return EventResult.interruptFalse();
        } else if (FunctionArea.isLocked(level, blockPos)) {
//            player.sendSystemMessage(TranslationUtil.messageComponent("function_area.break_block"), true);
            return EventResult.interruptFalse();
        }
        return EventResult.pass();
    }
}
