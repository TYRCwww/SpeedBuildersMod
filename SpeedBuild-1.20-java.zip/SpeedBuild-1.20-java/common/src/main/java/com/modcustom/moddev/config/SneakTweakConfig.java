package com.modcustom.moddev.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import dev.architectury.platform.Platform;
import net.minecraft.client.Minecraft;
import org.slf4j.Logger;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import static com.modcustom.moddev.SpeedBuild.MOD_ID;

@SuppressWarnings("unused")
public class SneakTweakConfig {

    private static final Logger LOGGER = LogUtils.getLogger();
    private static final String CONFIG_NAME = MOD_ID + "-sneaktweak";
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final SneakTweakConfig DEFAULT_INSTANCE = new SneakTweakConfig();
    private static final SneakTweakConfig DEFAULT_OLD_INSTANCE = new SneakTweakConfig(true);
    private static File file = null;
    private static SneakTweakConfig instance = new SneakTweakConfig();
    private boolean smoothingEnabled = true;
    private final String _smoothingEnabled = "平滑移动";
    private int speedPercentage = 100;
    private final String _speedPercentage = "移动速度百分比(25-300)";
    private SneakingEyeHeightType sneakingEyeHeightPreset = SneakingEyeHeightType.DEFAULT;
    private final String _sneakingEyeHeightPreset = "潜行视距预设(" + String.join(", ", SneakingEyeHeightType.names()) + ")";
    private float customSneakingEyeHeight = 1.27f;
    private final String _customSneakingEyeHeight = "潜行视距(0-1.8)";
    private boolean modifyThirdPersonSneakingEyeHeight = false;
    private final String _modifyThirdPersonSneakingEyeHeight = "修改第三人称潜行视距";

    public SneakTweakConfig() {
        this(false);
    }

    public SneakTweakConfig(boolean old) {
        if (old) {
            this.smoothingEnabled = false;
            this.sneakingEyeHeightPreset = SneakingEyeHeightType.PRE_1_9;
            this.modifyThirdPersonSneakingEyeHeight = true;
        }
    }

    public boolean isSmoothingEnabled() {
        return smoothingEnabled;
    }

    public void setSmoothingEnabled(boolean smoothingEnabled) {
        this.smoothingEnabled = smoothingEnabled;
        save();
    }

    public void convertToOld() {
        copy(DEFAULT_OLD_INSTANCE);
    }

    public boolean isDefault() {
        return valueEquals(DEFAULT_INSTANCE);
    }

    public boolean valueEquals(SneakTweakConfig other) {
        return smoothingEnabled == other.smoothingEnabled && speedPercentage == other.speedPercentage && sneakingEyeHeightPreset == other.sneakingEyeHeightPreset && customSneakingEyeHeight == other.customSneakingEyeHeight && modifyThirdPersonSneakingEyeHeight == other.modifyThirdPersonSneakingEyeHeight;
    }

    public int getSpeedPercentage() {
        return speedPercentage;
    }

    public void setSpeedPercentage(int speedPercentage) {
        this.speedPercentage = Math.max(25, Math.min(speedPercentage, 300));
        save();
    }

    public SneakingEyeHeightType getSneakingEyeHeightPreset() {
        return sneakingEyeHeightPreset;
    }

    public void setSneakingEyeHeightPreset(SneakingEyeHeightType sneakingEyeHeightPreset) {
        this.sneakingEyeHeightPreset = sneakingEyeHeightPreset;
        save();
    }

    public float getCustomSneakingEyeHeight() {
        return customSneakingEyeHeight;
    }

    public void setCustomSneakingEyeHeight(float customSneakingEyeHeight) {
        this.customSneakingEyeHeight = Math.max(0f, Math.min(customSneakingEyeHeight, 1.8f));
        save();
    }

    public boolean isModifyThirdPersonSneakingEyeHeight() {
        return modifyThirdPersonSneakingEyeHeight;
    }

    public void setModifyThirdPersonSneakingEyeHeight(boolean modifyThirdPersonSneakingEyeHeight) {
        this.modifyThirdPersonSneakingEyeHeight = modifyThirdPersonSneakingEyeHeight;
        save();
    }

    public float getSpeedModifier() {
        return speedPercentage / 100f;
    }

    public float modifySneakingEyeHeight(float height) {
        float newHeight = height;
        if (Minecraft.getInstance().options.getCameraType().isFirstPerson() || modifyThirdPersonSneakingEyeHeight) {
            switch (sneakingEyeHeightPreset) {
                case DEFAULT:
                    break;
                case PRE_1_14:
                    newHeight = 1.42f;
                    break;
                case PRE_1_9:
                    newHeight = 1.54f;
                    break;
                case CUSTOM:
                    newHeight = customSneakingEyeHeight;
                    break;
            }
        }
        return newHeight;
    }

    public void reset() {
        copy(DEFAULT_INSTANCE);
    }

    public void copy(SneakTweakConfig config) {
        smoothingEnabled = config.smoothingEnabled;
        speedPercentage = config.speedPercentage;
        sneakingEyeHeightPreset = config.sneakingEyeHeightPreset;
        customSneakingEyeHeight = config.customSneakingEyeHeight;
        modifyThirdPersonSneakingEyeHeight = config.modifyThirdPersonSneakingEyeHeight;
    }

    public boolean isOld() {
        return valueEquals(DEFAULT_OLD_INSTANCE);
    }

    public PresetVersionType getPresetVersion() {
        if (isDefault()) {
            return PresetVersionType.DEFAULT;
        } else if (isOld()) {
            return PresetVersionType.PRE_1_12;
        } else {
            return PresetVersionType.CUSTOM;
        }
    }

    public static void load() {
        prepareConfigFile();
        if (!file.exists()) {
            save();
        } else {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                JsonElement jsonElement = JsonParser.parseReader(br);
                SneakTweakConfig config = fromJson(jsonElement.toString());
                if (config != null) {
                    instance = config;
                } else {
                    save();
                }
            } catch (Exception e) {
                LOGGER.error("Couldn't load file {}.json; reverting to defaults", CONFIG_NAME, e);
                save();
            }
        }
    }

    public static void save() {
        prepareConfigFile();
        try (FileWriter fileWriter = new FileWriter(file)) {
            fileWriter.write(instance.toJson());
        } catch (Exception e) {
            LOGGER.error("Couldn't save file {}.json", CONFIG_NAME, e);
        }
    }

    public String toJson() {
        return GSON.toJson(this);
    }

    public static SneakTweakConfig getInstance() {
        return instance;
    }

    private static void prepareConfigFile() {
        if (file == null) {
            file = new File(Platform.getConfigFolder().toFile(), CONFIG_NAME + ".json");
        }
    }

    public static SneakTweakConfig fromJson(String json) {
        return GSON.fromJson(json, SneakTweakConfig.class);
    }

    public enum SneakingEyeHeightType {
        DEFAULT, PRE_1_14, PRE_1_9, CUSTOM;

        public static String[] names() {
            SneakingEyeHeightType[] values = values();
            String[] names = new String[values.length];
            for (int i = 0; i < values.length; i++) {
                names[i] = values[i].name();
            }
            return names;
        }
    }

    public enum PresetVersionType {
        DEFAULT, PRE_1_12, CUSTOM
    }
}
