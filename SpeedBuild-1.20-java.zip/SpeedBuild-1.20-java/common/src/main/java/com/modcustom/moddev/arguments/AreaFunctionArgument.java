package com.modcustom.moddev.arguments;

import com.google.gson.JsonObject;
import com.modcustom.moddev.api.Function;
import com.modcustom.moddev.functions.AreaFunction;
import com.modcustom.moddev.functions.FunctionManager;
import com.modcustom.moddev.utils.TranslationUtil;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.synchronization.ArgumentTypeInfo;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;

public class AreaFunctionArgument implements ArgumentType<AreaFunction> {

    private static final Collection<String> EXAMPLES = Arrays.asList("moddev:clone_base", "moddev:start_activity");
    private static final DynamicCommandExceptionType ERROR_UNKNOWN_ID = new DynamicCommandExceptionType(object -> TranslationUtil.messageComponent("unknown_id", object));
    private final boolean requiresAreaId;

    public AreaFunctionArgument(boolean requiresAreaId) {
        this.requiresAreaId = requiresAreaId;
    }

    @Override
    public AreaFunction parse(StringReader reader) throws CommandSyntaxException {
        ResourceLocation location = ResourceLocation.read(reader);
        Function function = FunctionManager.create(location);
        if (function instanceof AreaFunction areaFunction && (!this.requiresAreaId || areaFunction.requiresAreaId())) {
            return areaFunction;
        }
        throw ERROR_UNKNOWN_ID.create(location);
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        return SharedSuggestionProvider.suggestResource(FunctionManager.getFunctions(AreaFunction.class).stream().filter(f -> !this.requiresAreaId || f.requiresAreaId()), builder, Function::getId, Function::getDisplayName);
    }

    @Override
    public Collection<String> getExamples() {
        return EXAMPLES;
    }

    public static AreaFunctionArgument function() {
        return new AreaFunctionArgument(false);
    }

    public static AreaFunctionArgument functionWithArea() {
        return new AreaFunctionArgument(true);
    }

    public static AreaFunction getFunction(CommandContext<CommandSourceStack> context, String name) {
        return context.getArgument(name, AreaFunction.class);
    }

    public static class Info implements ArgumentTypeInfo<AreaFunctionArgument, Info.Template> {

        @Override
        public void serializeToNetwork(Template template, FriendlyByteBuf buffer) {
            buffer.writeBoolean(template.requiresAreaId);
        }

        @Override
        public @NotNull Template deserializeFromNetwork(FriendlyByteBuf buffer) {
            return new Template(buffer.readBoolean());
        }

        @Override
        public void serializeToJson(Template template, JsonObject json) {
            json.addProperty("requires_area_id", template.requiresAreaId);
        }

        @Override
        public @NotNull Template unpack(AreaFunctionArgument argument) {
            return new Template(argument.requiresAreaId);
        }

        public final class Template implements ArgumentTypeInfo.Template<AreaFunctionArgument> {

            final boolean requiresAreaId;

            Template(boolean requiresAreaId) {
                this.requiresAreaId = requiresAreaId;
            }

            @Override
            public @NotNull AreaFunctionArgument instantiate(CommandBuildContext context) {
                return new AreaFunctionArgument(this.requiresAreaId);
            }

            @Override
            public @NotNull ArgumentTypeInfo<AreaFunctionArgument, ?> type() {
                return AreaFunctionArgument.Info.this;
            }
        }
    }
}
