package com.modcustom.moddev.utils;

import com.modcustom.moddev.game.area.Area;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.debug.DebugRenderer;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.awt.*;

public class RenderUtil {

    public static void render(PoseStack stack, int color, AABB area) {
        render(stack, color, area, false);
    }

    public static void render(PoseStack stack, int color, AABB area, boolean fill) {
        Color c = new Color(color, true);
        Minecraft mc = Minecraft.getInstance();
        stack.pushPose();
        Vec3 cameraPosition = mc.getEntityRenderDispatcher().camera.getPosition();
        stack.translate(area.minX - cameraPosition.x, area.minY - cameraPosition.y, area.minZ - cameraPosition.z);
        MultiBufferSource.BufferSource bufferSource = mc.renderBuffers().bufferSource();
        float r = c.getRed() / 255f;
        float g = c.getGreen() / 255f;
        float b = c.getBlue() / 255f;
        float a = c.getAlpha() / 255f;
        if (fill) {
            DebugRenderer.renderFilledBox(stack, bufferSource, 0.0, 0.0, 0.0, area.getXsize(), area.getYsize(), area.getZsize(), r, g, b, a);
        }
        LevelRenderer.renderLineBox(stack, bufferSource.getBuffer(RenderType.lines()), area.move(-area.minX, -area.minY, -area.minZ), r, g, b, a);
        stack.popPose();
    }

    public static void render(PoseStack stack, int outlineColor, int filledColor, AABB area) {
        Color c = new Color(filledColor, true);
        Color c1 = new Color(outlineColor, true);
        Minecraft mc = Minecraft.getInstance();
        stack.pushPose();
        Vec3 cameraPosition = mc.getEntityRenderDispatcher().camera.getPosition();
        stack.translate(area.minX - cameraPosition.x, area.minY - cameraPosition.y, area.minZ - cameraPosition.z);
        MultiBufferSource.BufferSource bufferSource = mc.renderBuffers().bufferSource();
        DebugRenderer.renderFilledBox(stack, bufferSource, 0.0, 0.0, 0.0, area.getXsize(), area.getYsize(), area.getZsize(), c.getRed() / 255f, c.getGreen() / 255f, c.getBlue() / 255f, c.getAlpha() / 255f);
        LevelRenderer.renderLineBox(stack, bufferSource.getBuffer(RenderType.lines()), area.move(-area.minX, -area.minY, -area.minZ), c1.getRed() / 255f, c1.getGreen() / 255f, c1.getBlue() / 255f, c1.getAlpha() / 255f);
        stack.popPose();
    }

    public static void renderFilledBox(PoseStack stack, int color, AABB area) {
        Color c = new Color(color, true);
        Minecraft mc = Minecraft.getInstance();
        stack.pushPose();
        Vec3 cameraPosition = mc.getEntityRenderDispatcher().camera.getPosition();
        stack.translate(area.minX - cameraPosition.x, area.minY - cameraPosition.y, area.minZ - cameraPosition.z);
        MultiBufferSource.BufferSource bufferSource = mc.renderBuffers().bufferSource();
        DebugRenderer.renderFilledBox(stack, bufferSource, 0.0, 0.0, 0.0, area.getXsize(), area.getYsize(), area.getZsize(), c.getRed() / 255f, c.getGreen() / 255f, c.getBlue() / 255f, c.getAlpha() / 255f);
        stack.popPose();
    }

    public static void renderAreaId(PoseStack poseStack, Area area, int areaId) {
        Vec3 textPos = area.getBox().getCenter().relative(Direction.UP, area.getBoundingBox().getYSpan() / 2.0 + 1);
        DebugRenderer.renderFloatingText(poseStack, Minecraft.getInstance().renderBuffers().bufferSource(), String.valueOf(areaId), textPos.x(), textPos.y(), textPos.z(), Color.WHITE.getRGB(), 0.1f);
    }
}
