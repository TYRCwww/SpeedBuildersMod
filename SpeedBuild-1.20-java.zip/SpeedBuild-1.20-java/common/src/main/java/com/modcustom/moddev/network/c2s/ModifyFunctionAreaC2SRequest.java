package com.modcustom.moddev.network.c2s;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.game.area.FunctionArea;
import com.modcustom.moddev.game.data.GameData;
import dev.architectury.networking.NetworkManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.function.Supplier;

public class ModifyFunctionAreaC2SRequest implements NetworkPacket {

    private final int areaId;
    private final FunctionArea area;

    public ModifyFunctionAreaC2SRequest(FriendlyByteBuf buf) {
        this(buf.readInt(), FunctionArea.fromNbt(buf.readNbt()));
    }

    public ModifyFunctionAreaC2SRequest(int areaId, FunctionArea area) {
        this.areaId = areaId;
        this.area = area;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(areaId);
        buf.writeNbt(area.toNbt());
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        if (contextSupplier.get().getPlayer() instanceof ServerPlayer player) {
            MinecraftServer server = player.server;
            FunctionArea area = GameData.getGameData(server).getFunctionArea(areaId);
            if (area != null && this.area != null) {
                area.copyFrom(this.area);
            }
        }
    }
}
