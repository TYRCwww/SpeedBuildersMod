package com.modcustom.moddev.network.c2s;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.utils.PlayerUtil;
import dev.architectury.networking.NetworkManager;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.game.ClientboundLevelParticlesPacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.server.level.ServerPlayer;

import java.util.function.Supplier;

public class DoubleJumpC2SRequest implements NetworkPacket {

    @Override
    public void encode(FriendlyByteBuf buf) {
        // No data to encode
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        if (contextSupplier.get().getPlayer() instanceof ServerPlayer player) {
            player.server.execute(() -> {
                int jumpCount = PlayerUtil.getJumpCount(player);
                if (jumpCount < PlayerUtil.getExtraJump(player) && !player.isFallFlying() && !player.onGround()) {
                    PlayerUtil.setJumpCount(player, jumpCount + 1);
                    player.fallDistance = 0f;
                    PlayerUtil.jump(player, PlayerUtil.getExtraJumpPower(player));
                    PlayerUtil.getJumpSound(player).play(player.level(), player.blockPosition(), player);

                    boolean particles = PlayerUtil.hasJumpingParticles(player);
                    player.server.getPlayerList().getPlayers().stream().filter(p -> p != player && p.hasLineOfSight(player)).forEach(p -> {
                        if (particles) {
                            p.connection.send(new ClientboundLevelParticlesPacket(ParticleTypes.CLOUD, false, player.getX(), player.getY(), player.getZ(), 0f, 0f, 0f, 0.1f, 5));
                        }
                        p.connection.send(new ClientboundSetEntityMotionPacket(player));
                    });
                }
            });
        }
    }
}
