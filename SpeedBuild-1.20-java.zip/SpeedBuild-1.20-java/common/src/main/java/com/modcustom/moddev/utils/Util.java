package com.modcustom.moddev.utils;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.levelgen.structure.BoundingBox;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Util {

    public static Color alpha(Color color, double alpha) {
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int) (255 * alpha));
    }

    public static int getRGBWithAlpha(Color color, double alpha) {
        return (color.getRGB() & 0xFFFFFF) | ((int) (255 * alpha) << 24);
    }

    public static void drawCenteredStringWithBackground(GuiGraphics guiGraphics, Component text, int centerX, int y, int textColor, int backgroundColor) {
        Minecraft minecraft = Minecraft.getInstance();
        int halfWidth = minecraft.font.width(text) / 2;
        guiGraphics.fill(centerX - halfWidth - 1, y, centerX + halfWidth + 1, y + minecraft.font.lineHeight + 1, backgroundColor);
        guiGraphics.drawCenteredString(minecraft.font, text, centerX, y + 1, textColor);
    }

    public static List<BlockPos> toBlockPosList(BoundingBox boundingBox) {
        return toBlockPosList(boundingBox, false);
    }

    public static List<BlockPos> toBlockPosList(BoundingBox boundingBox, boolean topToBottom) {
        return toBlockPosList(boundingBox, TraversalOrder.builder().yDescending(topToBottom).build());
    }

    public static List<BlockPos> toBlockPosList(BoundingBox boundingBox, TraversalOrder traversalOrder) {
        List<BlockPos> positions = new ArrayList<>();
        traversalOrder.generatePositions(boundingBox, positions::add);
        return positions;
    }

    public static boolean isKeyDown(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }
}
