package com.modcustom.moddev.mixin;

import com.modcustom.moddev.client.ClientGameManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.GameType;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(MultiPlayerGameMode.class)
public abstract class MultiPlayerGameModeMixin {

    @Shadow
    private GameType localPlayerMode;

    @Shadow
    @Final
    private Minecraft minecraft;

    @Redirect(method = "startDestroyBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/GameType;isCreative()Z"))
    public boolean speed_build$startDestroyBlock(GameType instance, BlockPos loc, Direction face) {
        if (this.minecraft.level != null && this.localPlayerMode == GameType.ADVENTURE && !ClientGameManager.getInstance().getActivityAreas(this.minecraft.level, loc).isEmpty()) {
            return true;
        }
        return instance.isCreative();
    }
}
