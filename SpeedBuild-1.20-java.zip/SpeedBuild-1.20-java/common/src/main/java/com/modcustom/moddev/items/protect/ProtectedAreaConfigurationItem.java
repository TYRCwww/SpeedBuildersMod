package com.modcustom.moddev.items.protect;

import com.modcustom.moddev.game.area.Area;
import com.modcustom.moddev.game.area.ProtectedArea;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.items.AreaVisibleItem;
import com.modcustom.moddev.network.Network;
import com.modcustom.moddev.utils.PlayerUtil;
import com.modcustom.moddev.utils.TranslationUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class ProtectedAreaConfigurationItem extends AreaVisibleItem {

    public ProtectedAreaConfigurationItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext useOnContext) {
        Level level = useOnContext.getLevel();
        if (level instanceof ServerLevel serverLevel) {
            Direction face = useOnContext.getClickedFace();
            BlockPos pos = useOnContext.getClickedPos();
            Player player = useOnContext.getPlayer();
            if (player instanceof ServerPlayer serverPlayer) {
                if (player.isDescending()) {
                    boolean removed = ProtectedArea.remove(serverLevel, pos, true) || ProtectedArea.remove(serverLevel, pos.relative(face), true);
                    if (removed) {
                        serverPlayer.sendSystemMessage(TranslationUtil.messageComponent("protected_area.delete"), true);
                    }
                } else {
                    GameData gameData = GameData.getGameData(serverLevel);
                    Boolean active = gameData.toggleProtectedAreaActive(serverLevel, pos);
                    if (active == null) {
                        active = gameData.toggleProtectedAreaActive(serverLevel, pos.relative(face));
                    }
                    sendActiveMessage(active, serverPlayer);
                    Network.updateProtectedAreas(serverLevel.getServer());
                }
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide());
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand interactionHand) {
        if (player instanceof ServerPlayer serverPlayer) {
            return handleAirRightClick(serverPlayer, interactionHand);
        } else {
            return InteractionResultHolder.pass(player.getItemInHand(interactionHand));
        }
    }

    private InteractionResultHolder<ItemStack> handleAirRightClick(ServerPlayer player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        InteractionResultHolder<ItemStack> pass = InteractionResultHolder.pass(stack);
        if (hand != InteractionHand.MAIN_HAND) return pass;

        ProtectedArea area = PlayerUtil.findFirstProtectedArea(player, 5);
        if (area != null) {
            MinecraftServer server = player.serverLevel().getServer();
            if (player.isDescending()) {
                if (GameData.getGameData(server).getProtectedAreas(player.level()).remove(area)) {
                    Network.updateProtectedAreas(server);
                    player.sendSystemMessage(TranslationUtil.messageComponent("protected_area.delete"), true);
                }
            } else {
                area.setActive(!area.isActive());
                Network.updateProtectedAreas(server);
                sendActiveMessage(area.isActive(), player);
            }
            return InteractionResultHolder.success(stack);
        }
        return pass;
    }

    private void sendActiveMessage(@Nullable Boolean active, ServerPlayer player) {
        if (active != null) {
            player.sendSystemMessage(TranslationUtil.messageComponent("protected_area." + (active ? "active" : "deactivate")), true);
        } else {
            player.sendSystemMessage(TranslationUtil.messageComponent("protected_area.not_found"), true);
        }
    }

    @Override
    public boolean isVisible(@Nullable Area.Type type) {
        return type == Area.Type.PROTECTED;
    }
}
