package com.modcustom.moddev.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.modcustom.moddev.utils.Util;
import com.mojang.logging.LogUtils;
import dev.architectury.platform.Platform;
import net.minecraft.world.phys.Vec2;
import org.slf4j.Logger;

import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import static com.modcustom.moddev.SpeedBuild.MOD_ID;

@SuppressWarnings("unused")
public class Config {

    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static File file = null;
    private static Config instance = new Config();
    private int constructionAreaColor = Color.YELLOW.getRGB();
    private final String _constructionAreaColor = "建筑区域颜色";
    private int targetAreaColor = Color.GREEN.getRGB();
    private final String _targetAreaColor = "目标区域颜色";
    private int combinationAreaColor = Color.WHITE.getRGB();
    private final String _combinationAreaColor = "区域颜色";
    private int previewAreaColor = Color.ORANGE.getRGB();
    private final String _previewAreaColor = "建筑区域预览颜色";
    private int differenceBlockRenderingTransparency = 50;
    private final String _differenceBlockRenderingTransparency = "差异方块渲染透明度(0-255)";
    private int countdownColor = Color.WHITE.getRGB();
    private final String _countdownColor = "倒计时文本颜色";
    private Vec2 countdownPos = new Vec2(50f, 55f);
    private final String _countdownPos = "倒计时文本位置(百分比)";
    private float countdownSize = 1f;
    private final String _countdownSize = "倒计时文本大小";
    private int scoreColor = Color.WHITE.getRGB();
    private final String _scoreColor = "成绩文本颜色";
    private Vec2 scorePos = new Vec2(50f, 75f);
    private final String _scorePos = "成绩文本位置(百分比)";
    private float scoreSize = 1f;
    private final String _scoreSize = "成绩文本大小";
    private int timerColor = Color.WHITE.getRGB();
    private final String _timerColor = "计时器文本颜色";
    private Vec2 timerPos = new Vec2(93f, 3f);
    private final String _timerPos = "计时器文本位置(百分比)";
    private float timerSize = 1f;
    private final String _timerSize = "计时器文本大小";
    private int timerBackgroundColor = Util.getRGBWithAlpha(Color.DARK_GRAY, 0.75);
    private final String _timerBackgroundColor = "计时器背景颜色";
    private String timerFormat = "{m,2}:{s,2}.{ms,3}";
    private final String _timerFormat = "计时器格式(例: {m,2}:{s,2}.{ms,3} -> 00:00.000)";
    private int maxRenderDistance = 64;
    private final String _maxRenderDistance = "最大区域渲染距离";
    private boolean protectedAreaVisible = true;
    private final String _protectedAreaVisible = "是否常显保护区";
    private boolean functionAreaVisible = true;
    private final String _functionAreaVisible = "是否常显功能区";
    private boolean playerConfigAutoSave = true;
    private final String _playerConfigAutoSave = "玩家设置自动保存";

    public int getConstructionAreaColor() {
        return constructionAreaColor;
    }

    public void setConstructionAreaColor(int constructionAreaColor) {
        this.constructionAreaColor = constructionAreaColor;
        save();
    }

    public static void load() {
        prepareConfigFile();
        if (!file.exists()) {
            save();
        } else {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                JsonElement jsonElement = JsonParser.parseReader(br);
                Config config = fromJson(jsonElement.toString());
                if (config != null) {
                    instance = config;
                } else {
                    save();
                }
            } catch (Exception e) {
                LOGGER.error("Couldn't load file {}.json; reverting to defaults", MOD_ID, e);
                save();
            }
        }
    }

    public static void save() {
        prepareConfigFile();
        try (FileWriter fileWriter = new FileWriter(file)) {
            fileWriter.write(instance.toJson());
        } catch (Exception e) {
            LOGGER.error("Couldn't save file {}.json", MOD_ID, e);
        }
    }

    public String toJson() {
        return GSON.toJson(this);
    }

    public int getTargetAreaColor() {
        return targetAreaColor;
    }

    public void setTargetAreaColor(int targetAreaColor) {
        this.targetAreaColor = targetAreaColor;
        save();
    }

    public int getCombinationAreaColor() {
        return combinationAreaColor;
    }

    public void setCombinationAreaColor(int combinationAreaColor) {
        this.combinationAreaColor = combinationAreaColor;
        save();
    }

    public int getPreviewAreaColor() {
        return previewAreaColor;
    }

    public void setPreviewAreaColor(int previewAreaColor) {
        this.previewAreaColor = previewAreaColor;
        save();
    }

    public int getDifferenceBlockRenderingTransparency() {
        return differenceBlockRenderingTransparency;
    }

    public void setDifferenceBlockRenderingTransparency(int differenceBlockRenderingTransparency) {
        this.differenceBlockRenderingTransparency = differenceBlockRenderingTransparency;
        save();
    }

    public int getCountdownColor() {
        return countdownColor;
    }

    public void setCountdownColor(int countdownColor) {
        this.countdownColor = countdownColor;
        save();
    }

    public Vec2 getCountdownPos() {
        return countdownPos;
    }

    public void setCountdownPos(Vec2 countdownPos) {
        this.countdownPos = countdownPos;
        save();
    }

    public float getCountdownSize() {
        return countdownSize;
    }

    public void setCountdownSize(float countdownSize) {
        this.countdownSize = countdownSize;
        save();
    }

    public int getScoreColor() {
        return scoreColor;
    }

    public void setScoreColor(int scoreColor) {
        this.scoreColor = scoreColor;
        save();
    }

    public Vec2 getScorePos() {
        return scorePos;
    }

    public void setScorePos(Vec2 scorePos) {
        this.scorePos = scorePos;
        save();
    }

    public float getScoreSize() {
        return scoreSize;
    }

    public void setScoreSize(float scoreSize) {
        this.scoreSize = scoreSize;
        save();
    }

    public int getTimerColor() {
        return timerColor;
    }

    public void setTimerColor(int timerColor) {
        this.timerColor = timerColor;
        save();
    }

    public Vec2 getTimerPos() {
        return timerPos;
    }

    public void setTimerPos(Vec2 timerPos) {
        this.timerPos = timerPos;
        save();
    }

    public float getTimerSize() {
        return timerSize;
    }

    public void setTimerSize(float timerSize) {
        this.timerSize = timerSize;
        save();
    }

    public int getTimerBackgroundColor() {
        return timerBackgroundColor;
    }

    public void setTimerBackgroundColor(int timerBackgroundColor) {
        this.timerBackgroundColor = timerBackgroundColor;
        save();
    }

    public String getTimerFormat() {
        return timerFormat;
    }

    public void setTimerFormat(String timerFormat) {
        this.timerFormat = timerFormat;
        save();
    }

    public int getMaxRenderDistance() {
        return maxRenderDistance;
    }

    public void setMaxRenderDistance(int maxRenderDistance) {
        this.maxRenderDistance = maxRenderDistance;
        save();
    }

    public boolean isProtectedAreaVisible() {
        return protectedAreaVisible;
    }

    public void setProtectedAreaVisible(boolean protectedAreaVisible) {
        this.protectedAreaVisible = protectedAreaVisible;
        save();
    }

    public boolean isFunctionAreaVisible() {
        return functionAreaVisible;
    }

    public void setFunctionAreaVisible(boolean functionAreaVisible) {
        this.functionAreaVisible = functionAreaVisible;
        save();
    }

    public boolean isPlayerConfigAutoSave() {
        return playerConfigAutoSave;
    }

    public void setPlayerConfigAutoSave(boolean playerConfigAutoSave) {
        this.playerConfigAutoSave = playerConfigAutoSave;
        save();
    }

    public static Config getInstance() {
        return instance;
    }

    private static void prepareConfigFile() {
        if (file == null) {
            file = new File(Platform.getConfigFolder().toFile(), MOD_ID + ".json");
        }
    }

    public static Config fromJson(String json) {
        return GSON.fromJson(json, Config.class);
    }
}
