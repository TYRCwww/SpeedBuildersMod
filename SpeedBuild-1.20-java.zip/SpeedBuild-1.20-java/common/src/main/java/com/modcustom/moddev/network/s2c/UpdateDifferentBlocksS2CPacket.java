package com.modcustom.moddev.network.s2c;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.client.ClientGameManager;
import com.mojang.datafixers.util.Pair;
import dev.architectury.networking.NetworkManager;
import dev.architectury.utils.Env;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;

import java.util.HashSet;
import java.util.Set;
import java.util.function.Supplier;

public class UpdateDifferentBlocksS2CPacket implements NetworkPacket {

    private final int id;
    private final Pair<Set<BlockPos>, Set<BlockPos>> differentBlocks;

    public UpdateDifferentBlocksS2CPacket(FriendlyByteBuf buf) {
        this(buf.readInt(), Pair.of(buf.readCollection(HashSet::new, FriendlyByteBuf::readBlockPos), buf.readCollection(HashSet::new, FriendlyByteBuf::readBlockPos)));
    }

    public UpdateDifferentBlocksS2CPacket(int id, Pair<Set<BlockPos>, Set<BlockPos>> differentBlocks) {
        this.id = id;
        this.differentBlocks = differentBlocks;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(id);
        buf.writeCollection(differentBlocks.getFirst(), FriendlyByteBuf::writeBlockPos);
        buf.writeCollection(differentBlocks.getSecond(), FriendlyByteBuf::writeBlockPos);
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        NetworkManager.PacketContext context = contextSupplier.get();
        if (context.getEnvironment() == Env.CLIENT) {
            ClientGameManager.getInstance().setServerDifferentBlocks(id, differentBlocks);
        }
    }
}
