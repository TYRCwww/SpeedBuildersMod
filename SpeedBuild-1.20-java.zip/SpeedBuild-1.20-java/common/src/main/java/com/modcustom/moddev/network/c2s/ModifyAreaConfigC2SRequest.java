package com.modcustom.moddev.network.c2s;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.area.AreaConfig;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.network.Network;
import dev.architectury.networking.NetworkManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.EnumSet;
import java.util.function.Supplier;

public class ModifyAreaConfigC2SRequest implements NetworkPacket {

    private final int id;
    private final AreaConfig config;
    private final boolean callback;
    private final EnumSet<AreaConfig.Property> propertySet;

    public ModifyAreaConfigC2SRequest(FriendlyByteBuf buf) {
        this(buf.readInt(), AreaConfig.fromNbt(buf.readAnySizeNbt()), buf.readBoolean(), buf.readEnumSet(AreaConfig.Property.class));
    }

    public ModifyAreaConfigC2SRequest(int id, AreaConfig config, boolean callback, EnumSet<AreaConfig.Property> propertySet) {
        this.id = id;
        this.config = config;
        this.callback = callback;
        this.propertySet = propertySet;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(id);
        buf.writeNbt(config.toNbt());
        buf.writeBoolean(callback);
        buf.writeEnumSet(propertySet, AreaConfig.Property.class);
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        if (contextSupplier.get().getPlayer() instanceof ServerPlayer player) {
            MinecraftServer server = player.server;
            ActivityArea area = GameData.getGameData(server).getActivityArea(id);
            if (area != null) {
                propertySet.forEach(prop -> prop.set(area.getConfig(), config));
                Network.updateAreaConfig(server, area, callback ? null : player);
            }
        }
    }
}
