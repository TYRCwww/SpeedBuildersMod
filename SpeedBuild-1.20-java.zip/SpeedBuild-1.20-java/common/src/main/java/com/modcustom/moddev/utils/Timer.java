package com.modcustom.moddev.utils;

import com.modcustom.moddev.config.Config;
import org.jetbrains.annotations.Nullable;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Timer {

    public static final String DEFAULT_FORMAT = "{m,2}:{s,2}.{ms,3}";
    private long startTime = 0;
    private long startCalculationTime = 0;
    private long pauseTime = 0;
    private boolean isPaused = false;

    public boolean isPaused() {
        return isPaused;
    }

    public void start() {
        start(0);
    }

    public void start(long time) {
        startTime = (time == 0) ? System.currentTimeMillis() : time;
        startCalculationTime = startTime;
        isPaused = false;
        pauseTime = 0;
    }

    public void toggle() {
        if (isPaused) {
            resume();
        } else {
            pause();
        }
    }

    public void resume() {
        if (isPaused) {
            startCalculationTime += System.currentTimeMillis() - pauseTime;
            isPaused = false;
        }
    }

    public void pause() {
        pauseTime = System.currentTimeMillis();
        isPaused = true;
    }

    public long stop() {
        return stop(null);
    }

    public long stop(@Nullable Long timeFix) {
        long resultTime = (timeFix != null) ? calculateTime(startTime + timeFix) : getTime();
        startTime = 0;
        startCalculationTime = 0;
        pauseTime = 0;
        isPaused = false;
        return resultTime;
    }

    private long calculateTime(long time) {
        return isPaused ? pauseTime - startCalculationTime : time - startCalculationTime;
    }

    public long getTime() {
        if (startTime == 0 && startCalculationTime == 0) {
            return 0;
        }
        return calculateTime(System.currentTimeMillis());
    }

    public boolean isRunning() {
        return startTime != 0 && startCalculationTime != 0 && !isPaused;
    }

    public String getFormattedTime() {
        return formatTime(getTime());
    }

    public static String formatTime(long time) {
        String timerFormat = Config.getInstance().getTimerFormat();
        if (timerFormat.isEmpty()) {
            timerFormat = DEFAULT_FORMAT;
        }
        return formatTime(time, timerFormat);
    }

    public static String formatTime(long time, String pattern) {
        try {
            Pattern minutePattern = Pattern.compile("\\{\\s*(m)\\s*,\\s*(\\d+)\\s*}");
            Matcher minuteMatcher = minutePattern.matcher(pattern);
            boolean hasMinutes = minuteMatcher.find() && !"0".equals(minuteMatcher.group(2));

            long minutes = hasMinutes ? time / (60 * 1000) : 0;
            long seconds = hasMinutes ? (time / 1000) % 60 : time / 1000;
            long milliseconds = time % 1000;

            Pattern p = Pattern.compile("\\{\\s*(m|s|ms)\\s*,\\s*(\\d+)\\s*}");
            Matcher m = p.matcher(pattern);

            StringBuilder formattedTime = new StringBuilder();

            while (m.find()) {
                String unit = m.group(1);
                int width = Integer.parseInt(m.group(2));

                String replacement = switch (unit) {
                    case "m" -> hasMinutes ? String.format("%0" + width + "d", minutes) : "";
                    case "s" -> String.format("%0" + Math.max(width, 1) + "d", seconds);
                    case "ms" -> formatMilliseconds(milliseconds, width);
                    default -> "";
                };

                m.appendReplacement(formattedTime, replacement);
            }

            m.appendTail(formattedTime);

            return formattedTime.toString();
        } catch (Exception e) {
            return "ERROR";
        }
    }

    private static String formatMilliseconds(long milliseconds, int width) {
        return switch (width) {
            case 0 -> "";
            case 1 -> String.valueOf(milliseconds / 100);
            case 2 -> String.format("%02d", milliseconds / 10);
            default -> String.format("%0" + width + "d", milliseconds);
        };
    }

    public static String formatTime(long time, int decimalPlaces) {
        double totalSeconds = time / 1000.0;
        int minutes = (int) (totalSeconds / 60);
        double seconds = totalSeconds % 60;
        String format = "%02d:%06." + decimalPlaces + "f";
        return String.format(format, minutes, seconds);
    }
}
