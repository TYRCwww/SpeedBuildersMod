package com.modcustom.moddev.network.s2c;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.client.ClientGameManager;
import dev.architectury.networking.NetworkManager;
import dev.architectury.utils.Env;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

public class ProtectedBlocksUpdateS2CPacket implements NetworkPacket {

    public static final int SERVER_UPDATE_FLAGS = 19;
    private final Map<BlockPos, BlockState> updates = new HashMap<>();

    public ProtectedBlocksUpdateS2CPacket(FriendlyByteBuf buf) {
        this(buf.readMap(FriendlyByteBuf::readBlockPos, buf1 -> buf1.readById(Block.BLOCK_STATE_REGISTRY)));
    }

    public ProtectedBlocksUpdateS2CPacket(Map<BlockPos, BlockState> updates) {
        this.updates.putAll(updates);
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeMap(updates, FriendlyByteBuf::writeBlockPos, (buf1, state) -> buf1.writeId(Block.BLOCK_STATE_REGISTRY, state));
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        NetworkManager.PacketContext context = contextSupplier.get();
        if (context.getEnvironment() == Env.CLIENT) {
            ClientLevel level = Minecraft.getInstance().level;
            if (level != null) {
                updates.forEach((pos, state) -> {
                    if (!level.isLoaded(pos)) return;
                    ClientGameManager.getInstance().addServerUpdate(level, pos);
                    level.setServerVerifiedBlockState(pos, state, SERVER_UPDATE_FLAGS);
                });
            }
        }
    }
}
