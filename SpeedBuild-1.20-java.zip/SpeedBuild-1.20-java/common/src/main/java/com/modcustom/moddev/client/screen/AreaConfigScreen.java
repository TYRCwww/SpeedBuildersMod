package com.modcustom.moddev.client.screen;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.client.components.CallbackCheckbox;
import com.modcustom.moddev.client.components.HorizontalComponentList;
import com.modcustom.moddev.client.components.SoundEventEditBox;
import com.modcustom.moddev.client.components.SoundValueEditBox;
import com.modcustom.moddev.game.BaseSetting;
import com.modcustom.moddev.game.EntityDetectionMode;
import com.modcustom.moddev.game.SoundSetting;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.area.AreaConfig;
import com.modcustom.moddev.game.area.AreaConfig.Property;
import com.modcustom.moddev.game.data.ItemGivingData;
import com.modcustom.moddev.network.Network;
import com.modcustom.moddev.utils.AxisOrder;
import com.modcustom.moddev.utils.NumberUtil;
import com.modcustom.moddev.utils.TraversalOrder;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.screens.ConfirmScreen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import org.jetbrains.annotations.Nullable;

import java.awt.*;
import java.util.List;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static com.modcustom.moddev.utils.TranslationUtil.calculateButtonWidth;
import static com.modcustom.moddev.utils.TranslationUtil.screenComponent;

public class AreaConfigScreen extends SyncAreaScreen {

    private static final MutableComponent TITLE = screenComponent("area_config.title");
    private HorizontalComponentList componentList;
    private HorizontalComponentList.Entry secondButtonLine;
    private EditBox countdownBox;
    private EditBox scoreBox;
    private EditBox secondTextBox;
    private CycleButton<Integer> secondButton;
    private CycleButton<Boolean> simpleModeButton;
    private CallbackCheckbox renderBorderBox;
    private EditBox forcedPlayerBox;
    private SoundEventEditBox countdownSoundEventBox;
    private SoundValueEditBox.Volume countdownSoundVolumeBox;
    private SoundValueEditBox.Pitch countdownSoundPitchBox;
    private SoundEventEditBox startSoundEventBox;
    private SoundValueEditBox.Volume startSoundVolumeBox;
    private SoundValueEditBox.Pitch startSoundPitchBox;
    private SoundEventEditBox finishSoundEventBox;
    private SoundValueEditBox.Volume finishSoundVolumeBox;
    private SoundValueEditBox.Pitch finishSoundPitchBox;
    private CycleButton<EntityDetectionMode> entityDetectionButton;
    private CallbackCheckbox entityMoveBox;
    private CycleButton<ItemGivingData.Mode> itemGivingModeButton;
    private CycleButton<ItemGivingData.TriggerCondition> itemGivingConditionButton;
    private EditBox historyLimitBox;
    private CallbackCheckbox clearInventoryBox;
    private CallbackCheckbox clearHotbarBox;
    private CallbackCheckbox entityInstantKillBox;
    private CallbackCheckbox ignoreProtectedAreaBox;
    private CallbackCheckbox copyAirBox;
    private CallbackCheckbox autoFillBox;
    private EditBox fillBlockBox;
    private CallbackCheckbox showDifferenceBox;
    private EditBox scanOrderBox;
    private CallbackCheckbox xDescendingBox;
    private CallbackCheckbox yDescendingBox;
    private CallbackCheckbox zDescendingBox;
    @Nullable
    private String forcedPlayerSuggestion;
    @Nullable
    private String countdownSoundEventSuggestion;
    @Nullable
    private String startSoundEventSuggestion;
    @Nullable
    private String finishSoundEventSuggestion;

    public AreaConfigScreen(ActivityArea area) {
        super(TITLE, area);
    }

    @Override
    public void tick() {
        componentList.tick();
        if (ClientGameManager.getInstance().getActivityAreas(id) == null) {
            if (minecraft != null) {
                minecraft.gui.setOverlayMessage(screenComponent("deleted"), false);
            }
            onClose();
            return;
        }
        super.tick();
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.render(guiGraphics, mouseX, mouseY, partialTick);
        int x = 10;
        int y = 26;
        Component component = Component.translatable("area.moddev.id", id);
        guiGraphics.drawString(font, component, x, y, 0xFFFFFF);
        x += font.width(component) + 10;
        String name = area.getNameCache();
        if (name != null) {
            component = Component.translatable("area.moddev.owner", name);
            guiGraphics.drawString(font, component, x, y, 0xFFFFFF);
            x += font.width(component) + 10;
        }
        BoundingBox box = area.getBoundingBox();
        component = Component.translatable("area.moddev.size", String.format("%d×%d×%d", box.getXSpan(), box.getYSpan(), box.getZSpan()));
        guiGraphics.drawString(font, component, x, y, 0xFFFFFF);
//        x += font.width(component) + 10;
    }

    @Override
    public void update() {
        ClientGameManager manager = ClientGameManager.getInstance();
        ActivityArea area = manager.getActivityAreas(id);
        if (area == null) return;
        AreaConfig config = area.getConfig();
        if (config == null) return;

        String newCountdown = String.valueOf(config.getCountdown());
        if (!countdownBox.getValue().equals(newCountdown)) {
            int position = countdownBox.getCursorPosition();
            countdownBox.setValue(newCountdown);
            countdownBox.setCursorPosition(position);
        }

        String newScoreText = config.getScoreText();
        if (!scoreBox.getValue().equals(newScoreText)) {
            int position = scoreBox.getCursorPosition();
            scoreBox.setValue(newScoreText);
            scoreBox.setCursorPosition(position);
        }

        String newCountdownText = config.getCountdownText().get(secondButton.getValue());
        if (!secondTextBox.getValue().equals(newCountdownText)) {
            int position = secondTextBox.getCursorPosition();
            secondTextBox.setValue(newCountdownText);
            secondTextBox.setCursorPosition(position);
        }

        boolean newSimpleMode = config.isSimpleMode();
        if (simpleModeButton.getValue() != newSimpleMode) {
            simpleModeButton.setValue(newSimpleMode);
        }

        boolean newRenderBorder = config.isRenderBorder();
        if (renderBorderBox.selected() != newRenderBorder) {
            renderBorderBox.setSelected(newRenderBorder);
        }

        SoundSetting countdownSound = config.getCountdownSound();

        SoundEvent sound = countdownSound.getSound();
        String newCountdownSoundEvent = "";
        if (sound != null) {
            newCountdownSoundEvent = sound.getLocation().toString();
        }
        if (!countdownSoundEventBox.getValue().equals(newCountdownSoundEvent)) {
            countdownSoundEventBox.setValue(newCountdownSoundEvent);
        }

        String newCountdownSoundVolume = String.valueOf(countdownSound.getVolume());
        if (!countdownSoundVolumeBox.getValue().equals(newCountdownSoundVolume)) {
            countdownSoundVolumeBox.setValue(newCountdownSoundVolume);
        }

        String newCountdownSoundPitch = String.valueOf(countdownSound.getPitch());
        if (!countdownSoundPitchBox.getValue().equals(newCountdownSoundPitch)) {
            countdownSoundPitchBox.setValue(newCountdownSoundPitch);
        }

        SoundSetting startSound = config.getStartSound();

        sound = startSound.getSound();
        String newStartSoundEvent = "";
        if (sound != null) {
            newStartSoundEvent = sound.getLocation().toString();
        }
        if (!startSoundEventBox.getValue().equals(newStartSoundEvent)) {
            startSoundEventBox.setValue(newStartSoundEvent);
        }

        String newStartSoundVolume = String.valueOf(startSound.getVolume());
        if (!startSoundVolumeBox.getValue().equals(newStartSoundVolume)) {
            startSoundVolumeBox.setValue(newStartSoundVolume);
        }

        String newStartSoundPitch = String.valueOf(startSound.getPitch());
        if (!startSoundPitchBox.getValue().equals(newStartSoundPitch)) {
            startSoundPitchBox.setValue(newStartSoundPitch);
        }

        SoundSetting finishSound = config.getFinishSound();

        sound = finishSound.getSound();
        String newFinishSoundEvent = "";
        if (sound != null) {
            newFinishSoundEvent = sound.getLocation().toString();
        }
        if (!finishSoundEventBox.getValue().equals(newFinishSoundEvent)) {
            finishSoundEventBox.setValue(newFinishSoundEvent);
        }

        String newFinishSoundVolume = String.valueOf(finishSound.getVolume());
        if (!finishSoundVolumeBox.getValue().equals(newFinishSoundVolume)) {
            finishSoundVolumeBox.setValue(newFinishSoundVolume);
        }

        String newFinishSoundPitch = String.valueOf(finishSound.getPitch());
        if (!finishSoundPitchBox.getValue().equals(newFinishSoundPitch)) {
            finishSoundPitchBox.setValue(newFinishSoundPitch);
        }

        EntityDetectionMode newEntityDetection = config.getEntityDetection();
        if (entityDetectionButton.getValue() != newEntityDetection) {
            entityDetectionButton.setValue(newEntityDetection);
        }

        boolean newEntityMove = config.isEntityMove();
        if (entityMoveBox.selected() != newEntityMove) {
            entityMoveBox.setSelected(newEntityMove);
        }

        ItemGivingData itemGivingData = config.getItemGivingData();
        ItemGivingData.TriggerCondition newItemGivingCondition = itemGivingData.getCondition();
        if (itemGivingConditionButton.getValue() != newItemGivingCondition) {
            itemGivingConditionButton.setValue(newItemGivingCondition);
        }
        ItemGivingData.Mode newItemGivingMode = itemGivingData.getMode();
        if (itemGivingModeButton.getValue() != newItemGivingMode) {
            itemGivingModeButton.setValue(newItemGivingMode);
        }

        boolean newClearInventory = itemGivingData.isClearInventory();
        if (clearInventoryBox.selected() != newClearInventory) {
            clearInventoryBox.setSelected(newClearInventory);
        }
        boolean newClearHotbar = itemGivingData.isClearHotbar();
        if (clearHotbarBox.selected() != newClearHotbar) {
            clearHotbarBox.setSelected(newClearHotbar);
        }
        boolean newEntityInstantKill = config.isEntityInstantKill();
        if (entityInstantKillBox.selected() != newEntityInstantKill) {
            entityInstantKillBox.setSelected(newEntityInstantKill);
        }

        BaseSetting baseSetting = config.getBaseSetting();

        boolean newIgnoreProtectedArea = baseSetting.isIgnoreProtectedArea();
        if (ignoreProtectedAreaBox.selected() != newIgnoreProtectedArea) {
            ignoreProtectedAreaBox.setSelected(newIgnoreProtectedArea);
        }

        boolean newAutoFill = baseSetting.isAutoFill();
        if (autoFillBox.selected() != newAutoFill) {
            autoFillBox.setSelected(newAutoFill);
        }

        boolean newCopyAir = baseSetting.isCopyAir();
        if (copyAirBox.selected() != newCopyAir) {
            copyAirBox.setSelected(newCopyAir);
        }

        ResourceLocation fillBlockId = baseSetting.getFillBlockId();
        String idString = fillBlockId != null ? fillBlockId.toString() : "";
        if (!fillBlockBox.getValue().equals(idString)) {
            fillBlockBox.setValue(idString);
        }

        showDifferenceBox.active = manager.hasActivity(id);
        showDifferenceBox.setSelected(manager.isShowingDifference(id));
    }

    @Override
    public boolean keyPressed(int i, int j, int k) {
        if (forcedPlayerBox.isFocused() && i == 258) {
            if (forcedPlayerSuggestion != null && forcedPlayerBox.getCursorPosition() == forcedPlayerBox.getValue().length()) {
                forcedPlayerBox.insertText(forcedPlayerSuggestion);
            }
            return true;
        }
        if (countdownSoundEventBox.keyPressed(i, j, k, () -> countdownSoundEventSuggestion)) return true;
        if (startSoundEventBox.keyPressed(i, j, k, () -> startSoundEventSuggestion)) return true;
        if (finishSoundEventBox.keyPressed(i, j, k, () -> finishSoundEventSuggestion)) return true;
        return super.keyPressed(i, j, k);
    }

    @Override
    protected void init() {
        super.init();
        initComponentList();
        addFunctionalButtons();
        addCountdownWidgets();
        addScoreTextWidgets();
        addCountdownTextWidgets();
        addForcedPlayerWidgets();
        addCountdownSoundWidgets();
        addStartSoundWidgets();
        addFinishSoundWidgets();
        addSimpleModeButton();
        addItemGivingSettingButton();
        addDeleteButton();
        addHistoryButton();
        addHistoryLimitWidgets();
        addEntityWidgets();
        addItemGivingButtons();
        addBaseSettingWidgets();
        addTraversalOrderWidgets();
    }

    private void initComponentList() {
        componentList = new HorizontalComponentList(minecraft, width, height - 32 - 40, 32 + 10, height - 40, 32);
        addRenderableWidget(componentList);
    }

    private void addFunctionalButtons() {
        Button resetTargetButton = createAdaptiveButton(screenComponent("reset_target.button"), button -> Network.requestResetTargetArea(id));

        Button cloneBaseButton = createAdaptiveButton(screenComponent("clone_base"), button -> Network.requestCloneBase(id));

        ClientGameManager manager = ClientGameManager.getInstance();

        showDifferenceBox = new CallbackCheckbox(font, screenComponent("show_difference"), manager.isShowingDifference(id), selected -> {
            Network.requestShowDifference(id, selected);
            if (!selected) {
                ClientGameManager.getInstance().clearDifferentBlocks(id);
            }
            return true;
        });
        showDifferenceBox.active = manager.hasActivity(id);

        renderBorderBox = new CallbackCheckbox(font, screenComponent("render_border"), area.getConfig().isRenderBorder(), selected -> {
            area.getConfig().setRenderBorder(selected);
            markModified(Property.RENDER_BORDER);
            return true;
        });

        addLine(resetTargetButton, cloneBaseButton);
        addLine(renderBorderBox, showDifferenceBox);
    }

    protected HorizontalComponentList.Entry addLine(AbstractWidget... widgets) {
        HorizontalComponentList.Entry entry = new HorizontalComponentList.Entry(10, 10, widgets);
        componentList.addEntry(entry);
        return entry;
    }

    private void addEntityWidgets() {
        MutableComponent title = screenComponent("entity_detection");
        int maxWidth = calculateButtonWidth(font, Arrays.stream(EntityDetectionMode.values()).map(EntityDetectionMode::getComponent).toList());
        entityDetectionButton = CycleButton.builder(EntityDetectionMode::getComponent)
                                           .withValues(EntityDetectionMode.values())
                                           .withInitialValue(area.getConfig().getEntityDetection())
                                           .displayOnlyValue()
                                           .create(0, 0, maxWidth, 20, title, (button, mode) -> {
                                               AreaConfig config = area.getConfig();
                                               if (config.getEntityDetection() == mode) return;
                                               config.setEntityDetection(mode);
                                               markModified(Property.ENTITY_DETECTION);
                                           });

        entityMoveBox = new CallbackCheckbox(font, screenComponent("entity_move"), area.getConfig().isEntityMove(), selected -> {
            area.getConfig().setEntityMove(selected);
            markModified(Property.ENTITY_MOVE);
            return true;
        });

        entityInstantKillBox = new CallbackCheckbox(font, screenComponent("entity_instant_kill"), area.getConfig().isEntityInstantKill(), isChecked -> {
            area.getConfig().setEntityInstantKill(isChecked);
            markModified(Property.ENTITY_INSTANT_KILL);
            return true;
        });

        addLines(title, entityDetectionButton, entityMoveBox, entityInstantKillBox);
    }

    protected void addLines(@Nullable Component title, AbstractWidget... widgets) {
        addLines(title, Arrays.asList(widgets));
    }

    @SafeVarargs
    protected final void addLines(@Nullable Component title, Collection<AbstractWidget>... widgetCollections) {
        StringWidget titleWidget = title != null ? createStringWidget(title) : null;
        int line = 0;
        HorizontalComponentList.Entry firstEntry = null;
        List<HorizontalComponentList.Entry> lines = new ArrayList<>();

        int startXFirstLine = titleWidget != null ? 10 : 20;
        int startXOtherLines = title != null ? 20 + font.width(title) : 10;

        for (Collection<AbstractWidget> widgets : widgetCollections) {
            List<AbstractWidget> remainingWidgets = new ArrayList<>(widgets);

            while (!remainingWidgets.isEmpty()) {
                line++;

                if (line == 1 && titleWidget != null) {
                    remainingWidgets.add(0, titleWidget);
                }

                int startX = (line == 1) ? startXFirstLine : startXOtherLines;

                HorizontalComponentList.Entry entry = new HorizontalComponentList.Entry(startX, 10, remainingWidgets);
                remainingWidgets.clear();

                int totalWidth = entry.getWidth();
                while (startX + totalWidth > componentList.getRowWidth() - 6 && entry.children().size() > 2) {
                    remainingWidgets.add(0, entry.removeLastWidget());
                    totalWidth = entry.getWidth();
                }

                componentList.addEntry(entry);
                lines.add(entry);

                if (firstEntry == null) {
                    firstEntry = entry;
                }
            }
        }

        if (line > 1 && titleWidget != null) {
            int totalHeight = lines.stream().mapToInt(HorizontalComponentList.Entry::getHeight).sum();
            firstEntry.setFirstStringWidgetYOffset((totalHeight - titleWidget.getHeight()) / 2);
        }
    }

    private void addItemGivingButtons() {
        AreaConfig config = area.getConfig();
        ItemGivingData itemGivingData = config.getItemGivingData();
        itemGivingConditionButton = CycleButton.<ItemGivingData.TriggerCondition>builder(triggerCondition -> triggerCondition.component)
                                               .withValues(ItemGivingData.TriggerCondition.values())
                                               .withInitialValue(itemGivingData.getCondition())
                                               .displayOnlyValue()
                                               .create(0, 0, 100, 20, screenComponent("item_giving_condition"), (button, condition) -> {
                                                   if (itemGivingData.getCondition() == condition) return;
                                                   itemGivingData.setCondition(condition);
                                                   markModified(Property.ITEM_GIVING_DATA);
                                               });

        clearInventoryBox = new CallbackCheckbox(font, screenComponent("clear_inventory"), itemGivingData.isClearInventory(), (isChecked) -> {
            itemGivingData.setClearInventory(isChecked);
            markModified(Property.ITEM_GIVING_DATA);
            return true;
        });

        clearHotbarBox = new CallbackCheckbox(font, screenComponent("clear_hotbar"), itemGivingData.isClearHotbar(), (isChecked) -> {
            itemGivingData.setClearHotbar(isChecked);
            markModified(Property.ITEM_GIVING_DATA);
            return true;
        });

        addLines(screenComponent("item_giving_data"), List.of(createStringWidget(screenComponent("item_giving_condition")), itemGivingConditionButton), List.of(clearInventoryBox, clearHotbarBox));
    }

    private void addCountdownWidgets() {
        countdownBox = new EditBox(font, 0, 0, 100, 20, screenComponent("countdown"));
        countdownBox.setFilter(text -> NumberUtil.isIntBetweenOrEmpty(text, 0, 1000));
        countdownBox.setValue(String.valueOf(area.getConfig().getCountdown()));
        countdownBox.setResponder(text -> {
            NumberUtil.getOptionalInt(text).ifPresent(i -> {
                AreaConfig config = area.getConfig();
                if (config.getCountdown() == i) return;
                config.setCountdown(i);
                markModified(Property.COUNTDOWN);
                CycleButton<Integer> newSecondButton = createNewSecondButton(secondButton.getX(), secondButton.getY());
                int newValue = Math.min(i, secondButton.getValue());
                secondButtonLine.replaceWidget(1, newSecondButton);
                secondButton = newSecondButton;
                secondButton.setValue(newValue);
                secondTextBox.setValue(config.getCountdownText().get(newValue));
            });
        });

        addLine(createStringWidget(screenComponent("countdown.text")), countdownBox, createResetButton(s -> countdownBox.setValue("3")));
    }

    private CycleButton<Integer> createNewSecondButton() {
        return createNewSecondButton(0, 0);
    }

    private void addScoreTextWidgets() {
        scoreBox = new EditBox(font, 10, 64 + 32, 100, 20, screenComponent("score_text"));
        scoreBox.setValue(area.getConfig().getScoreText());
        scoreBox.setResponder(text -> {
            if (text.equals(area.getConfig().getScoreText())) return;
            area.getConfig().setScoreText(text);
            markModified(Property.SCORE_TEXT);
        });

        addLine(createStringWidget(screenComponent("score_text.text")), scoreBox, createResetButton(s -> scoreBox.setValue(AreaConfig.DEFAULT_SCORE_TEXT)));
    }

    private void addCountdownTextWidgets() {
        secondTextBox = new EditBox(font, 0, 0, 100, 20, screenComponent("score_text.second"));

        secondButton = createNewSecondButton();

        secondTextBox.setValue(area.getConfig().getCountdownText().get(secondButton.getValue()));
        secondTextBox.setResponder(text -> {
            if (text.equals(area.getConfig().getCountdownText().get(secondButton.getValue()))) return;
            area.getConfig().getCountdownText().put(secondButton.getValue(), text);
            markModified(Property.COUNTDOWN_TEXT);
        });

        secondButtonLine = addLine(createStringWidget(screenComponent("countdown_text")), secondButton, secondTextBox, createResetButton(s -> {
            secondTextBox.setValue(secondButton.getValue() == 0 ? AreaConfig.getDefaultStartText() : String.valueOf(secondButton.getValue()));
        }));
    }

    private CycleButton<Integer> createNewSecondButton(int x, int y) {
        return CycleButton.<Integer>builder(value -> screenComponent("second_button", value)).withValues(IntStream.rangeClosed(0, Math.min(area.getConfig().getCountdown(), 999)).boxed().collect(Collectors.toList())).displayOnlyValue().create(x, y, 50, 20, Component.empty(), (button, value) -> secondTextBox.setValue(area.getConfig().getCountdownText().get(value)));
    }

    private void addForcedPlayerWidgets() {
        forcedPlayerBox = new EditBox(font, 0, 0, 100, 20, screenComponent("forced_player"));
        forcedPlayerBox.setFormatter((text, index) -> FormattedCharSequence.forward(text, Style.EMPTY.withColor(area.getConfig().getForcedPlayers().contains(forcedPlayerBox.getValue()) ? Color.GREEN.getRGB() : Color.WHITE.getRGB())));
        forcedPlayerBox.setResponder(text -> {
            String suggestion = null;
            Set<String> forcedPlayers = area.getConfig().getForcedPlayers();
            if (!text.isEmpty() && !forcedPlayers.contains(text)) {
                suggestion = forcedPlayers.stream().sorted(Comparator.comparingInt(String::length)).filter(name -> name.startsWith(text) && name.length() > text.length()).findFirst().map(name -> name.substring(text.length())).orElse(null);
            }
            forcedPlayerSuggestion = suggestion;
            forcedPlayerBox.setSuggestion(suggestion);
        });

        addLine(createStringWidget(screenComponent("forced_player.text")),
                forcedPlayerBox,
                createResetButton(s -> forcedPlayerBox.setValue("")),
                createButton(Component.literal("+"), button -> {
                    if (forcedPlayerBox.getValue().isEmpty()) return;
                    area.getConfig().getForcedPlayers().add(forcedPlayerBox.getValue());
                    markModified(Property.FORCED_PLAYERS);
                }),
                createButton(Component.literal("-"), button -> {
                    if (forcedPlayerBox.getValue().isEmpty()) return;
                    area.getConfig().getForcedPlayers().remove(forcedPlayerBox.getValue());
                    markModified(Property.FORCED_PLAYERS);
                }));
    }

    private void addCountdownSoundWidgets() {
        countdownSoundEventBox = new SoundEventEditBox(font, area.getConfig().getCountdownSound(), screenComponent("countdown_sound"), SoundEvents.NOTE_BLOCK_PLING.value().getLocation().toString(), suggestion -> countdownSoundEventSuggestion = suggestion);
        countdownSoundEventBox.setPostResponder(() -> markModified(Property.COUNTDOWN_SOUND));
        addLine(countdownSoundEventBox.createRow());

        countdownSoundVolumeBox = new SoundValueEditBox.Volume(font, area.getConfig().getCountdownSound(), screenComponent("countdown_sound_volume"));
        countdownSoundVolumeBox.setPostResponder(() -> markModified(Property.COUNTDOWN_SOUND));
        addLine(countdownSoundVolumeBox.createRow());

        countdownSoundPitchBox = new SoundValueEditBox.Pitch(font, area.getConfig().getCountdownSound(), screenComponent("countdown_sound_pitch"));
        countdownSoundPitchBox.setPostResponder(() -> markModified(Property.COUNTDOWN_SOUND));
        addLine(countdownSoundPitchBox.createRow());
    }

    private void addStartSoundWidgets() {
        startSoundEventBox = new SoundEventEditBox(font, area.getConfig().getStartSound(), screenComponent("start_sound"), SoundEvents.NOTE_BLOCK_PLING.value().getLocation().toString(), suggestion -> startSoundEventSuggestion = suggestion);
        startSoundEventBox.setPostResponder(() -> markModified(Property.START_SOUND));
        addLine(startSoundEventBox.createRow());

        startSoundVolumeBox = new SoundValueEditBox.Volume(font, area.getConfig().getStartSound(), screenComponent("start_sound_volume"));
        startSoundVolumeBox.setPostResponder(() -> markModified(Property.START_SOUND));
        addLine(startSoundVolumeBox.createRow());

        startSoundPitchBox = new SoundValueEditBox.Pitch(font, area.getConfig().getStartSound(), screenComponent("start_sound_pitch"), 2f);
        startSoundPitchBox.setPostResponder(() -> markModified(Property.START_SOUND));
        addLine(startSoundPitchBox.createRow());
    }

    private void addFinishSoundWidgets() {
        finishSoundEventBox = new SoundEventEditBox(font, area.getConfig().getFinishSound(), screenComponent("finish_sound"), SoundEvents.PLAYER_LEVELUP.getLocation().toString(), suggestion -> finishSoundEventSuggestion = suggestion);
        finishSoundEventBox.setPostResponder(() -> markModified(Property.FINISH_SOUND));
        addLine(finishSoundEventBox.createRow());

        finishSoundVolumeBox = new SoundValueEditBox.Volume(font, area.getConfig().getFinishSound(), screenComponent("finish_sound_volume"));
        finishSoundVolumeBox.setPostResponder(() -> markModified(Property.FINISH_SOUND));
        addLine(finishSoundVolumeBox.createRow());

        finishSoundPitchBox = new SoundValueEditBox.Pitch(font, area.getConfig().getFinishSound(), screenComponent("finish_sound_pitch"));
        finishSoundPitchBox.setPostResponder(() -> markModified(Property.FINISH_SOUND));
        addLine(finishSoundPitchBox.createRow());
    }

    private void addSimpleModeButton() {
        int simpleModeTextWidth = Math.max(font.width(screenComponent("mode_selection").append(": ").append(screenComponent("simple_mode.on"))), font.width(screenComponent("mode_selection").append(": ").append(screenComponent("simple_mode.off")))) + BUTTON_SPACE_WIDTH;

        simpleModeButton = CycleButton.booleanBuilder(screenComponent("simple_mode.on"), screenComponent("simple_mode.off")).create(10, height - 30, Math.max(simpleModeTextWidth, 100), 20, screenComponent("mode_selection"), (button, isSimpleMode) -> {
            if (isSimpleMode == area.getConfig().isSimpleMode()) return;
            area.getConfig().setSimpleMode(isSimpleMode);
            markModified(Property.SIMPLE_MODE);
        });
        simpleModeButton.setValue(area.getConfig().isSimpleMode());

        addRenderableWidget(simpleModeButton);
    }

    private void addItemGivingSettingButton() {
        itemGivingModeButton = CycleButton.<ItemGivingData.Mode>builder(mode -> mode.component)
                                          .withValues(ItemGivingData.Mode.values())
                                          .withInitialValue(area.getConfig().getItemGivingData().getMode())
                                          .create(simpleModeButton.getX() + simpleModeButton.getWidth() + 10, height - 30, 150, 20, screenComponent("item_giving_mode"), (button, mode) -> {
                                              AreaConfig config = area.getConfig();
                                              if (config.getItemGivingData().getMode() == mode) return;
                                              config.getItemGivingData().setMode(mode);
                                              markModified(Property.ITEM_GIVING_DATA);
                                          });

        addRenderableWidget(itemGivingModeButton);

        Button itemGivingDataButton = Button.builder(Component.literal("..."), button -> {
            if (minecraft != null) {
                minecraft.setScreen(new ItemGivingDataScreen(area, this));
            }
        }).bounds(itemGivingModeButton.getX() + itemGivingModeButton.getWidth() + 10, height - 30, 20, 20).build();

        addRenderableWidget(itemGivingDataButton);
    }

    private void addDeleteButton() {
        ConfirmScreen confirmScreen = new ConfirmScreen(result -> {
            if (result) requestDelete();
            if (minecraft != null) {
                minecraft.setScreen(this);
            }
        }, screenComponent("delete.title", id), screenComponent("delete.subtitle"));

        Button deleteButton = Button.builder(screenComponent("delete.button"), button -> {
            if (minecraft != null) {
                minecraft.setScreen(confirmScreen);
            }
        }).bounds(width - 110, height - 30, 100, 20).build();
        addRenderableWidget(deleteButton);
    }

    private void addHistoryButton() {
        Button historyButton = Button.builder(screenComponent("history.button"), button -> {
            if (minecraft != null) {
                minecraft.setScreen(new ScoreHistoryScreen(area, this));
            }
        }).bounds(width - 110, 10, 100, 20).build();
        addRenderableWidget(historyButton);
    }

    private void addHistoryLimitWidgets() {
        historyLimitBox = new EditBox(font, 0, 0, 50, 20, screenComponent("history_limit"));
        historyLimitBox.setValue(String.valueOf(area.getConfig().getHistoryLimit()));
        historyLimitBox.setFilter(text -> NumberUtil.isIntBetweenOrEmpty(text, 0, 1000));
        historyLimitBox.setResponder(text -> {
            NumberUtil.getOptionalInt(text).ifPresent(i -> {
                area.getConfig().setHistoryLimit(i);
                markModified(Property.HISTORY_LIMIT);
            });
        });
        historyLimitBox.setTooltip(Tooltip.create(screenComponent("history_limit_tip").withStyle(ChatFormatting.RED)));

        addLine(
                createStringWidget(screenComponent("history_limit")),
                historyLimitBox,
                createResetButton(button -> historyLimitBox.setValue("10")),
                createButton(Component.literal("+"), button -> NumberUtil.getOptionalInt(historyLimitBox.getValue()).ifPresent(i -> historyLimitBox.setValue(String.valueOf(i + 10)))),
                createButton(Component.literal("-"), button -> NumberUtil.getOptionalInt(historyLimitBox.getValue()).ifPresent(i -> historyLimitBox.setValue(String.valueOf(i - 10))))
        );
    }

    private void addBaseSettingWidgets() {
        BaseSetting baseSetting = area.getConfig().getBaseSetting();

        ignoreProtectedAreaBox = new CallbackCheckbox(font, screenComponent("ignore_protected_area"), baseSetting.isIgnoreProtectedArea(), button -> {
            baseSetting.setIgnoreProtectedArea(!baseSetting.isIgnoreProtectedArea());
            markModified(Property.BASE_SETTING);
            return true;
        });

        copyAirBox = new CallbackCheckbox(font, screenComponent("copy_air"), baseSetting.isCopyAir(), button -> {
            baseSetting.setCopyAir(!baseSetting.isCopyAir());
            markModified(Property.BASE_SETTING);
            return true;
        });

        autoFillBox = new CallbackCheckbox(font, screenComponent("auto_fill"), baseSetting.isAutoFill(), button -> {
            baseSetting.setAutoFill(!baseSetting.isAutoFill());
            markModified(Property.BASE_SETTING);
            return true;
        });

        fillBlockBox = new EditBox(font, 0, 0, 150, 20, screenComponent("fill_block"));
        ResourceLocation fillBlock = baseSetting.getFillBlockId();
        if (fillBlock != null) {
            fillBlockBox.setValue(fillBlock.toString());
        }
        fillBlockBox.setResponder(text -> {
            Block block = BaseSetting.tryParse(text);
            if (block != null) {
                baseSetting.setFillBlock(block);
                markModified(Property.BASE_SETTING);
            }
        });
        fillBlockBox.setFormatter((s, i) -> {
            boolean valid = BaseSetting.tryParse(fillBlockBox.getValue()) != null;
            return FormattedCharSequence.forward(s, Style.EMPTY.withColor(valid ? ChatFormatting.GREEN : ChatFormatting.WHITE));
        });

        Button resetButton = createResetButton(button -> fillBlockBox.setValue(BuiltInRegistries.BLOCK.getKey(BaseSetting.DEFAULT_FILL_BLOCK).toString()));

        MutableComponent component = screenComponent("base_settings");
        addLines(component, List.of(ignoreProtectedAreaBox, copyAirBox, autoFillBox), List.of(createStringWidget(screenComponent("fill_block")), fillBlockBox, resetButton));
    }

    private void addTraversalOrderWidgets() {
        scanOrderBox = new EditBox(font, 0, 0, 50, 20, screenComponent("scan_order"));
        scanOrderBox.setValue(area.getConfig().getItemGivingData().getScanOrder().getOrder().toString());
        scanOrderBox.setTooltip(Tooltip.create(screenComponent("scan_order_tooltip")));
        scanOrderBox.setFilter(text -> text.isEmpty() || (text.chars().distinct().count() == text.length() && text.toLowerCase().chars().allMatch(c -> Set.of('x', 'y', 'z').contains((char) c))));
        scanOrderBox.setResponder(text -> {
            AxisOrder order = AxisOrder.fromString(text);
            if (order != null) {
                area.getConfig().getItemGivingData().getScanOrder().setOrder(order);
                markModified(Property.ITEM_GIVING_DATA);
            }
        });
        xDescendingBox = new CallbackCheckbox(font, screenComponent("x_descending"), area.getConfig().getItemGivingData().getScanOrder().isXDescending(), button -> {
            TraversalOrder order = area.getConfig().getItemGivingData().getScanOrder();
            order.setXDescending(!order.isXDescending());
            markModified(Property.ITEM_GIVING_DATA);
            return true;
        });
        yDescendingBox = new CallbackCheckbox(font, screenComponent("y_descending"), area.getConfig().getItemGivingData().getScanOrder().isYDescending(), button -> {
            TraversalOrder order = area.getConfig().getItemGivingData().getScanOrder();
            order.setYDescending(!order.isYDescending());
            markModified(Property.ITEM_GIVING_DATA);
            return true;
        });
        zDescendingBox = new CallbackCheckbox(font, screenComponent("z_descending"), area.getConfig().getItemGivingData().getScanOrder().isZDescending(), button -> {
            TraversalOrder order = area.getConfig().getItemGivingData().getScanOrder();
            order.setZDescending(!order.isZDescending());
            markModified(Property.ITEM_GIVING_DATA);
            return true;
        });
        addLines(screenComponent("scan_order"),
                 List.of(scanOrderBox, createResetButton(button -> scanOrderBox.setValue("XZY"))),
                 List.of(xDescendingBox, yDescendingBox, zDescendingBox)
        );
    }
}
