package com.modcustom.moddev.network.c2s;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.game.AreaFinder;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.game.data.ItemGivingData;
import com.modcustom.moddev.utils.PlayerUtil;
import com.modcustom.moddev.utils.TranslationUtil;
import dev.architectury.networking.NetworkManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import java.util.function.Supplier;

public class ResetActivityAreaC2SRequest implements NetworkPacket {

    private final int id;
    private final Type type;

    public ResetActivityAreaC2SRequest(FriendlyByteBuf buf) {
        this(buf.readInt(), buf.readEnum(Type.class));
    }

    public ResetActivityAreaC2SRequest(int id, Type type) {
        this.id = id;
        this.type = type;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(id);
        buf.writeEnum(type);
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        NetworkManager.PacketContext context = contextSupplier.get();
        if (context.getPlayer() instanceof ServerPlayer player) {
            context.queue(() -> {
                GameData gameData = GameData.getGameData(player);
                ServerLevel level = player.serverLevel();
                ActivityArea area = id == -1 ? PlayerUtil.getAreaFinder(player).find(level, player.blockPosition()) : gameData.getActivityArea(id);
                if (area != null) {
                    type.action(area, player);
                } else if (id == -1 && PlayerUtil.getAreaFinder(player) == AreaFinder.POSITION) {
                    player.sendSystemMessage(TranslationUtil.messageComponent("not_in_area"));
                }
            });
        }
    }

    public enum Type {
        CONSTRUCTION {
            @Override
            public void action(ActivityArea area, ServerPlayer player) {
                area.startResetConstructionAreaTask(player.serverLevel());
                ItemGivingData data = area.getConfig().getItemGivingData();
                if (data.getCondition() == ItemGivingData.TriggerCondition.CLEAR) {
                    data.run(player, area);
                }
            }
        }, TARGET {
            @Override
            public void action(ActivityArea area, ServerPlayer player) {
                area.startResetTargetAreaTask(player.serverLevel());
            }
        };

        public abstract void action(ActivityArea area, ServerPlayer player);
    }
}
