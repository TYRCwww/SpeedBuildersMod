package com.modcustom.moddev.network.s2c;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.client.ClientGameManager;
import dev.architectury.networking.NetworkManager;
import dev.architectury.utils.Env;
import net.minecraft.network.FriendlyByteBuf;

import java.util.function.Supplier;

public class CountdownMessageS2CPacket implements NetworkPacket {

    private final String text;
    private final int time;

    public CountdownMessageS2CPacket(FriendlyByteBuf buf) {
        this(buf.readUtf(), buf.readInt());
    }

    public CountdownMessageS2CPacket(String text, int time) {
        this.text = text;
        this.time = time;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeUtf(text);
        buf.writeInt(time);
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        NetworkManager.PacketContext context = contextSupplier.get();
        if (context.getEnvironment() == Env.CLIENT) {
            ClientGameManager.getInstance().updateCountdown(text, time);
        }
    }
}
