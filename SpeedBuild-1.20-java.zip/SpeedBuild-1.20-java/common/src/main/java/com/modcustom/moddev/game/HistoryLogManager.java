package com.modcustom.moddev.game;

import com.modcustom.moddev.game.activity.ActivityRecord;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.mixin.LevelStorageAccessAccessor;
import com.modcustom.moddev.mixin.MinecraftServerAccessor;
import com.mojang.logging.LogUtils;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Comparator;
import java.util.List;
import java.util.stream.IntStream;

public class HistoryLogManager {

    public static final String HISTORY_LOG_FILENAME = "history.log";
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final int MAX_FAIL_COUNT = 5;
    private static int failTimes = 0;
    private static long lastRecordFinishTime = -1;
    private static int lastRecordCount = -1;

    public static void appendHistory(MinecraftServer server, ActivityRecord newRecord) {
        try {
            File file = getHistoryFile(server);
            if (!file.exists()) {
                saveHistory(server);
                return;
            }

            List<ActivityRecord> sortedHistory = GameData.getGameData(server).getActivityAreas().parallelStream()
                                                         .flatMap(area -> area.getHistory().stream())
                                                         .sorted(Comparator.comparingLong(ActivityRecord::getFinishTime))
                                                         .toList();

            int actualRecordCount = sortedHistory.size();
            long actualLastFinishTime = sortedHistory.isEmpty() ? -1 : sortedHistory.get(actualRecordCount - 1).getFinishTime();

            if (actualRecordCount != lastRecordCount || actualLastFinishTime != lastRecordFinishTime) {
                saveHistory(server);
                lastRecordCount = actualRecordCount;
                lastRecordFinishTime = actualLastFinishTime;
                return;
            }

            int fileLineCount = 0;
            if (file.length() > 0) {
                try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    fileLineCount = (int) reader.lines().count();
                }
            }

            String newRecordLine = fileLineCount + ": " + newRecord;

            try (FileWriter fileWriter = new FileWriter(file, true)) {
                fileWriter.write("\n" + newRecordLine);
            }

            lastRecordFinishTime = newRecord.getFinishTime();
            lastRecordCount++;

            failTimes = 0;
        } catch (Exception e) {
            if (failTimes < MAX_FAIL_COUNT) {
                LOGGER.error("Failed to append history ({}/{})", ++failTimes, MAX_FAIL_COUNT, e);
            }
        }
    }

    public static void saveHistory(MinecraftServer server) {
        try {
            File file = getHistoryFile(server);
            if (!file.exists() && !file.createNewFile()) return;

            List<ActivityRecord> sortedHistory = GameData.getGameData(server).getActivityAreas().parallelStream()
                                                         .flatMap(area -> area.getHistory().stream())
                                                         .sorted(Comparator.comparingLong(ActivityRecord::getFinishTime))
                                                         .toList();

            List<String> records = IntStream.range(0, sortedHistory.size())
                                            .mapToObj(i -> i + ": " + sortedHistory.get(i))
                                            .toList();

            try (FileWriter fileWriter = new FileWriter(file)) {
                fileWriter.write(String.join("\n", records));
            }

            failTimes = 0;
        } catch (Exception e) {
            if (failTimes < MAX_FAIL_COUNT) {
                LOGGER.error("Failed to save history ({}/{})", ++failTimes, MAX_FAIL_COUNT, e);
            }
        }
    }

    private static File getHistoryFile(MinecraftServer server) {
        return ((LevelStorageAccessAccessor) ((MinecraftServerAccessor) server).getStorageSource()).getLevelDirectory().path().resolve(HISTORY_LOG_FILENAME).toFile();
    }
}
