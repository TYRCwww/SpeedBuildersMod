package com.modcustom.moddev.game.area;

import com.modcustom.moddev.api.SerializableData;
import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.network.Network;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class ProtectedArea extends Area implements SerializableData<ProtectedArea> {

    private boolean active = true;

    public ProtectedArea(BlockPos start, BlockPos end) {
        super(start, end);
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Override
    public void save(CompoundTag tag) {
        super.save(tag);
        tag.putBoolean("active", active);
    }

    @Override
    public Type getType() {
        return Type.PROTECTED;
    }

    @Override
    public void load(CompoundTag tag) {
        if (tag.contains("active")) {
            active = tag.getBoolean("active");
        }
    }

    @Override
    public void copyFrom(ProtectedArea data) {
        active = data.active;
    }

    public static ProtectedArea fromNbt(CompoundTag tag) {
        Area area = Area.fromNbt(tag);
        if (area != null) {
            ProtectedArea protectedArea = new ProtectedArea(area.getMinPos(), area.getMaxPos());
            return protectedArea.readNbt(tag);
        }
        return null;
    }

    public static boolean isProtected(Level level, BlockPos pos) {
        if (level instanceof ServerLevel serverLevel) {
            return GameData.getGameData(serverLevel).isProtected(serverLevel, pos);
        } else {
            return ClientGameManager.getInstance().isProtected(level, pos);
        }
    }

    public static boolean add(ServerLevel level, ProtectedArea area, boolean overlapping, boolean notifyClient) {
        GameData gameData = GameData.getGameData(level);
        if (!overlapping && (gameData.getActivityAreas().stream().anyMatch(a -> a.intersects(area)) || gameData.getProtectedAreas(level).stream().anyMatch(a -> a.intersects(area)))) {
            return false;
        }
        gameData.getProtectedAreas(level).add(area);
        if (notifyClient) {
            Network.updateNewProtectedArea(level, area);
        }
        return true;
    }

    public static boolean remove(ServerLevel level, BlockPos pos, boolean notifyClient) {
        boolean removed = GameData.getGameData(level).getProtectedAreas(level).removeIf(area -> area.contains(pos));
        if (removed && notifyClient) {
            Network.updateProtectedAreas(level.getServer());
        }
        return removed;
    }

    @Nullable
    public static ProtectedArea get(ServerLevel level, BlockPos pos) {
        return GameData.getGameData(level).getProtectedAreas(level).stream().filter(area -> area.contains(pos)).findFirst().orElse(null);
    }
}
