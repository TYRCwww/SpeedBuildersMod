package com.modcustom.moddev.mixin;

import com.modcustom.moddev.game.area.Area;
import com.modcustom.moddev.utils.PlayerUtil;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.GameType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ItemStack.class)
public class ItemStackMixin {

    @Inject(method = "useOn", at = @At("HEAD"), cancellable = true)
    public void speed_build$useOn(UseOnContext context, CallbackInfoReturnable<InteractionResult> cir) {
        Player player = context.getPlayer();
        if (player != null && GameType.ADVENTURE == PlayerUtil.getGameMode(player) && !Area.hasArea(context.getLevel(), context.getClickedPos().relative(context.getClickedFace()))) {
            cir.setReturnValue(InteractionResult.PASS);
        }
    }
}
