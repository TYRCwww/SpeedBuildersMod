package com.modcustom.moddev.network.s2c;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.area.ActivityArea;
import dev.architectury.networking.NetworkManager;
import dev.architectury.utils.Env;
import net.minecraft.network.FriendlyByteBuf;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Supplier;

public class UpdateActivityAreasS2CPacket implements NetworkPacket {

    private final List<ActivityArea> areas;
    private final boolean replace;

    public UpdateActivityAreasS2CPacket(FriendlyByteBuf buf) {
        this(buf.readCollection(ArrayList::new, FriendlyByteBuf::readNbt).stream().map(ActivityArea::parseNbt).filter(Objects::nonNull).toList(), buf.readBoolean());
    }

    public UpdateActivityAreasS2CPacket(List<ActivityArea> areas, boolean replace) {
        this.areas = areas;
        this.replace = replace;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeCollection(areas, (buf1, area) -> buf1.writeNbt(area.toNbt()));
        buf.writeBoolean(replace);
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        NetworkManager.PacketContext context = contextSupplier.get();
        if (context.getEnvironment() == Env.CLIENT) {
            ClientGameManager manager = ClientGameManager.getInstance();
            if (replace) {
                manager.setCachedServerAreas(areas);
            } else {
                manager.addCachedServerAreas(areas);
            }
        }
    }

    public List<ActivityArea> getAreas() {
        return areas;
    }
}
