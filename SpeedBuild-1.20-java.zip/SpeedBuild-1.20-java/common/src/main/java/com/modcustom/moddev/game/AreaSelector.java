package com.modcustom.moddev.game;

import com.modcustom.moddev.game.area.Area;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class AreaSelector {

    @Nullable
    private BlockPos start;
    @Nullable
    private BlockPos end;
    @Nullable
    private ResourceLocation dimension;
    @Nullable
    private Area area;

    @Nullable
    public BlockPos getStart() {
        return start;
    }

    @Nullable
    public BlockPos getEnd() {
        return end;
    }

    public boolean select(Level level, BlockPos pos) {
        ResourceLocation location = level.dimension().location();
        if (start == null || !location.equals(dimension)) {
            start = pos;
            end = null;
            dimension = location;
        } else {
            end = pos;
            area = null;
        }
        return hasArea();
    }

    public boolean hasArea() {
        return getArea() != null;
    }

    @Nullable
    public Area getArea() {
        if (area == null && start != null && end != null) {
            area = new Area(start, end);
        }
        return area;
    }

    @Nullable
    public Area selectWithSelector(Level level, BlockPos pos, AreaSelector selector) {
        Area otherArea = selector.getArea();
        if (otherArea == null) {
            return null;
        }
        ResourceLocation location = level.dimension().location();
        if (!location.equals(selector.getDimension())) {
            return null;
        }
        start = pos;
        area = new Area(start, otherArea);
        end = area.getMaxPos();
        return area;
    }

    @Nullable
    public ResourceLocation getDimension() {
        return dimension;
    }

    public void clear() {
        start = null;
        end = null;
        dimension = null;
        area = null;
    }

    public boolean hasStart() {
        return start != null;
    }

    public void deselectLast() {
        if (end != null) {
            end = null;
        } else if (start != null) {
            start = null;
            dimension = null;
        }
        area = null;
    }
}
