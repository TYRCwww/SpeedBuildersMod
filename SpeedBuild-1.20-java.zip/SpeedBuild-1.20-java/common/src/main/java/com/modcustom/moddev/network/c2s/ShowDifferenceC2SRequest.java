package com.modcustom.moddev.network.c2s;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.game.activity.Activity;
import com.modcustom.moddev.game.activity.ActivityManager;
import dev.architectury.networking.NetworkManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;

import java.util.function.Supplier;

public class ShowDifferenceC2SRequest implements NetworkPacket {

    private final int id;
    private final boolean enabled;

    public ShowDifferenceC2SRequest(FriendlyByteBuf buf) {
        this(buf.readInt(), buf.readBoolean());
    }

    public ShowDifferenceC2SRequest(int id, boolean enabled) {
        this.id = id;
        this.enabled = enabled;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(id);
        buf.writeBoolean(enabled);
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        NetworkManager.PacketContext context = contextSupplier.get();
        if (context.getPlayer() instanceof ServerPlayer) {
            context.queue(() -> {
                Activity activity = ActivityManager.getActivity(id);
                if (activity != null) {
                    activity.setSyncDifference(enabled);
                }
            });
        }
    }
}
