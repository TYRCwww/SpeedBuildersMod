package com.modcustom.moddev.utils;

import net.minecraft.client.gui.Font;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.MutableComponent;

import java.util.Collection;

import static com.modcustom.moddev.SpeedBuild.MOD_ID;

public class TranslationUtil {

    public static MutableComponent screenComponent(String str, Object... args) {
        return Component.translatable("screen." + MOD_ID + "." + str, args);
    }

    public static MutableComponent successComponent() {
        return messageComponent("successful_operation");
    }

    public static MutableComponent messageComponent(String str, Object... args) {
        return Component.translatable("message." + MOD_ID + "." + str, args);
    }

    public static MutableComponent failComponent(String reason) {
        return messageComponent("operation_failed", reason);
    }

    public static MutableComponent failComponent(Component reason) {
        return messageComponent("operation_failed", reason.getString());
    }

    public static int calculateButtonWidth(Font font, FormattedText text) {
        return Math.max(100, font.width(text) + 20);
    }

    public static int calculateButtonWidth(Font font, Collection<? extends FormattedText> texts) {
        return Math.max(100, texts.stream().mapToInt(font::width).max().orElse(0) + 20);
    }
}
