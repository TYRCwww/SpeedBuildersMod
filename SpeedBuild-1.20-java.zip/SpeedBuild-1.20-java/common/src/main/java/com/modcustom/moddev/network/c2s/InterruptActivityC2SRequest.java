package com.modcustom.moddev.network.c2s;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.game.activity.ActivityManager;
import dev.architectury.networking.NetworkManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;

import java.util.function.Supplier;

public class InterruptActivityC2SRequest implements NetworkPacket {

    private final int id;

    public InterruptActivityC2SRequest(FriendlyByteBuf buf) {
        this(buf.readInt());
    }

    public InterruptActivityC2SRequest(int id) {
        this.id = id;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(id);
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        NetworkManager.PacketContext context = contextSupplier.get();
        if (context.getPlayer() instanceof ServerPlayer) {
            context.queue(() -> ActivityManager.stopActivity(id));
        }
    }
}
