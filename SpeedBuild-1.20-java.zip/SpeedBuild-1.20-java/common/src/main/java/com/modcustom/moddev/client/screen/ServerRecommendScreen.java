package com.modcustom.moddev.client.screen;

import com.modcustom.moddev.utils.TranslationUtil;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.*;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class ServerRecommendScreen extends SyncScreen {

    public static final String SERVER_HOST = "b.rainplay.cn";
    public static final int SERVER_PORT = 36668;
    public static final String SERVER_IP = SERVER_HOST + ":" + SERVER_PORT;
    private static final MutableComponent TITLE = TranslationUtil.screenComponent("server_recommend.title");

    public ServerRecommendScreen() {
        this(null);
    }

    public ServerRecommendScreen(@Nullable Screen parent) {
        super(TITLE, parent);
    }

    @Override
    protected void init() {
        super.init();

        addRenderableWidget(Button.builder(TranslationUtil.screenComponent("back"), button -> {
            if (minecraft != null) {
                minecraft.setScreen(parent);
            }
        }).bounds(10, height - 30, 100, 20).build());

        addRenderableWidget(Button.builder(TranslationUtil.screenComponent("connect_button"), button -> {
            if (minecraft != null) {
                minecraft.setScreen(new ConfirmScreen(result -> {
                    if (result) {
                        disconnectAndStartConnecting();
                    } else {
                        minecraft.setScreen(this);
                    }
                }, TranslationUtil.screenComponent("connect_title"), TranslationUtil.screenComponent("connect_message")));
            }
        }).bounds(width - 110, height - 30, 100, 20).build());
    }

    private void disconnectAndStartConnecting() {
        onDisconnect();
        if (minecraft != null) {
            ConnectScreen.startConnecting(new JoinMultiplayerScreen(new TitleScreen()), minecraft, new ServerAddress(SERVER_HOST, SERVER_PORT), new ServerData(TranslationUtil.screenComponent("server_name").getString(), SERVER_IP, false), false);
        }
    }

    private void onDisconnect() {
        if (minecraft == null) return;
        boolean isLocal = minecraft.isLocalServer();
        if (minecraft.level != null) {
            minecraft.level.disconnect();
        }
        if (isLocal) {
            minecraft.clearLevel(new GenericDirtMessageScreen(Component.translatable("menu.savingLevel")));
        } else {
            minecraft.clearLevel();
        }
        minecraft.setScreen(new JoinMultiplayerScreen(new TitleScreen()));
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.render(guiGraphics, mouseX, mouseY, partialTick);
        int y = 32;
        List<String> lines = List.of(I18n.get("screen.moddev.server_info", I18n.get("screen.moddev.server_name"), SERVER_IP).split("\n"));
        for (String line : lines) {
            guiGraphics.drawString(font, line, 10, y, 0xFFFFFF);
            y += 16;
        }
    }

    @Override
    public void update() {

    }
}
