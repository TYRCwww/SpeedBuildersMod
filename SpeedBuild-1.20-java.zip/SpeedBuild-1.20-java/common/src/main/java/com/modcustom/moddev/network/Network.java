package com.modcustom.moddev.network;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.activity.Activity;
import com.modcustom.moddev.game.activity.ActivityRecord;
import com.modcustom.moddev.game.area.*;
import com.modcustom.moddev.game.data.ClientCachedData;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.network.c2s.*;
import com.modcustom.moddev.network.s2c.*;
import com.modcustom.moddev.utils.TranslationUtil;
import com.mojang.datafixers.util.Pair;
import com.mojang.logging.LogUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.*;

public class Network {

    private static final Logger LOGGER = LogUtils.getLogger();

    public static void requestCreateArea(Area constructionArea, Area targetArea) {
        ModChannels.CREATE_ACTIVITY_AREA_C2S_CHANNEL.sendToServer(new CreateActivityAreaC2SRequest(constructionArea, targetArea));
    }

    public static void updateActivityAreas(ServerPlayer player) {
        List<ActivityArea> areas = GameData.getGameData(player).getActivityAreas();
        UpdateActivityAreasS2CPacket packet = new UpdateActivityAreasS2CPacket(areas, true);

        if (!packet.isOverflowing()) {
            ModChannels.UPDATE_ACTIVITY_AREAS_S2C_CHANNEL.sendToPlayer(player, packet);
            return;
        }

        packet = new UpdateActivityAreasS2CPacket(List.of(), false);
        for (ActivityArea area : areas) {
            packet.getAreas().add(area);
            if (packet.isOverflowing()) {
                Area removed = packet.getAreas().remove(packet.getAreas().size() - 1);
                if (packet.getAreas().isEmpty()) {
                    player.sendSystemMessage(TranslationUtil.messageComponent("area.too_large"));
                    LOGGER.warn("Area data is too large to send packet: {}", removed);
                    continue;
                }
                ModChannels.UPDATE_ACTIVITY_AREAS_S2C_CHANNEL.sendToPlayer(player, packet);
                packet = new UpdateActivityAreasS2CPacket(List.of(area), false);
            }
        }

        if (!packet.getAreas().isEmpty()) {
            ModChannels.UPDATE_ACTIVITY_AREAS_S2C_CHANNEL.sendToPlayer(player, packet);
        }
    }

    public static void updateActivityAreasForAll(MinecraftServer server) {
        List<ActivityArea> areas = GameData.getGameData(server).getActivityAreas();
        List<ServerPlayer> players = server.getPlayerList().getPlayers();
        UpdateActivityAreasS2CPacket packet = new UpdateActivityAreasS2CPacket(areas, true);

        if (!packet.isOverflowing()) {
            ModChannels.UPDATE_ACTIVITY_AREAS_S2C_CHANNEL.sendToPlayers(players, packet);
            return;
        }

        packet = new UpdateActivityAreasS2CPacket(List.of(), true);
        for (ActivityArea area : areas) {
            packet.getAreas().add(area);
            if (packet.isOverflowing()) {
                Area removed = packet.getAreas().remove(packet.getAreas().size() - 1);
                if (packet.getAreas().isEmpty()) {
                    for (ServerPlayer player : players) {
                        player.sendSystemMessage(TranslationUtil.messageComponent("area.too_large"));
                    }
                    LOGGER.warn("Area data is too large to send packet: {}", removed);
                    continue;
                }
                ModChannels.UPDATE_ACTIVITY_AREAS_S2C_CHANNEL.sendToPlayers(players, packet);
                packet = new UpdateActivityAreasS2CPacket(List.of(area), false);
            }
        }

        if (!packet.getAreas().isEmpty()) {
            ModChannels.UPDATE_ACTIVITY_AREAS_S2C_CHANNEL.sendToPlayers(players, packet);
        }
    }

    public static void requestDeleteActivityArea(int id) {
        ModChannels.DELETE_ACTIVITY_AREA_C2S_CHANNEL.sendToServer(new DeleteActivityAreaC2SRequest(id));
    }

    public static void updateAreaConfig(MinecraftServer server, ActivityArea area) {
        updateAreaConfig(server, area, null);
    }

    public static void updateAreaConfig(MinecraftServer server, ActivityArea area, @Nullable ServerPlayer except) {
        ModChannels.UPDATE_AREA_CONFIG_S2C_CHANNEL.sendToPlayers(server.getPlayerList().getPlayers().stream().filter(player -> !Objects.equals(player, except)).toList(), new UpdateAreaConfigS2CPacket(area.getId(), area.getConfig()));
    }

    public static void requestStartActivity() {
        requestStartActivity(-1);
    }

    public static void requestStartActivity(int id) {
        ModChannels.START_ACTIVITY_C2S_CHANNEL.sendToServer(new StartActivityC2SRequest(id));
    }

    public static void startActivityTimer(Activity activity) {
        startActivityTimer(activity, 0);
    }

    public static void startActivityTimer(Activity activity, long startTime) {
        ModChannels.START_ACTIVITY_TIMER_S2C_CHANNEL.sendToPlayers(activity.getPlayers(), new StartActivityTimerS2CPacket(activity.getArea().getId(), startTime));
    }

    public static void finishActivity(Activity activity) {
        finishActivity(activity, activity.getArea().getId(), -1);
    }

    public static void finishActivity(Activity activity, int id, long runtime) {
        ModChannels.FINISH_ACTIVITY_S2C_CHANNEL.sendToPlayers(activity.getPlayers(), new FinishActivityS2CPacket(id, runtime));
    }

    public static void finishActivity(ServerPlayer player) {
        ModChannels.FINISH_ACTIVITY_S2C_CHANNEL.sendToPlayer(player, new FinishActivityS2CPacket());
    }

    public static void sendCountdownMessage(ServerPlayer player, String text, int time) {
        ModChannels.COUNTDOWN_MESSAGE_S2C_CHANNEL.sendToPlayer(player, new CountdownMessageS2CPacket(text, time));
    }

    public static void sendCountdownMessageForAll(Collection<ServerPlayer> players, String text, int time) {
        ModChannels.COUNTDOWN_MESSAGE_S2C_CHANNEL.sendToPlayers(players, new CountdownMessageS2CPacket(text, time));
    }

    public static void requestResetConstructionArea() {
        requestResetConstructionArea(-1);
    }

    public static void requestResetConstructionArea(int id) {
        ModChannels.RESET_ACTIVITY_AREA_C2S_CHANNEL.sendToServer(new ResetActivityAreaC2SRequest(id, ResetActivityAreaC2SRequest.Type.CONSTRUCTION));
    }

    public static void requestResetTargetArea(int id) {
        ModChannels.RESET_ACTIVITY_AREA_C2S_CHANNEL.sendToServer(new ResetActivityAreaC2SRequest(id, ResetActivityAreaC2SRequest.Type.TARGET));
    }

    public static void requestModifyAreaConfig(int id, AreaConfig config, boolean callback, AreaConfig.Property first, AreaConfig.Property... rest) {
        ModChannels.MODIFY_AREA_CONFIG_C2S_CHANNEL.sendToServer(new ModifyAreaConfigC2SRequest(id, config, callback, EnumSet.of(first, rest)));
    }

    public static void requestModifyAreaConfig(int id, AreaConfig config, boolean callback, List<AreaConfig.Property> properties) {
        if (!properties.isEmpty()) {
            ModChannels.MODIFY_AREA_CONFIG_C2S_CHANNEL.sendToServer(new ModifyAreaConfigC2SRequest(id, config, callback, EnumSet.copyOf(properties)));
        }
    }

    public static void previewActivity(Activity activity) {
        ModChannels.PREVIEW_ACTIVITY_S2C_CHANNEL.sendToPlayers(activity.getPlayers(), new PreviewActivityS2CPacket(activity.getArea().getId()));
    }

    public static void updateAreaHistory(MinecraftServer server, ActivityArea area) {
        List<ActivityRecord> history = area.getLimitedHistory();
        int chunkSize = history.size();
        List<List<ActivityRecord>> chunks = chunk(history, chunkSize);

        while (chunks.stream().anyMatch(chunk -> new UpdateAreaHistoryS2CPacket(area.getId(), chunk, true).isOverflowing()) && chunkSize > 1) {
            chunkSize /= 2;
            chunks = chunk(history, chunkSize);
        }

        for (int index = 0; index < chunks.size(); index++) {
            ModChannels.UPDATE_AREA_HISTORY_S2C_CHANNEL.sendToPlayers(server.getPlayerList().getPlayers(), new UpdateAreaHistoryS2CPacket(area.getId(), chunks.get(index), index == 0));
        }
    }

    private static <T> List<List<T>> chunk(List<T> list, int chunkSize) {
        List<List<T>> chunks = new ArrayList<>();
        int listSize = list.size();
        for (int i = 0; i < listSize; i += chunkSize) {
            chunks.add(list.subList(i, Math.min(i + chunkSize, listSize)));
        }
        return chunks;
    }

    public static void updateNewAreaHistory(MinecraftServer server, int areaId, ActivityRecord record) {
        ModChannels.UPDATE_AREA_HISTORY_S2C_CHANNEL.sendToPlayers(server.getPlayerList().getPlayers(), new UpdateAreaHistoryS2CPacket(areaId, List.of(record), false));
    }

    public static void requestDoubleJump() {
        ModChannels.DOUBLE_JUMP_C2S_CHANNEL.sendToServer(new DoubleJumpC2SRequest());
    }

    public static void updateProtectedAreas(ServerPlayer player) {
        ModChannels.UPDATE_PROTECTED_AREAS_S2C_CHANNEL.sendToPlayer(player, new UpdateProtectedAreasS2CPacket(GameData.getGameData(player).getProtectedAreas(), true));
    }

    public static void updateProtectedAreas(MinecraftServer server) {
        ModChannels.UPDATE_PROTECTED_AREAS_S2C_CHANNEL.sendToPlayers(server.getPlayerList().getPlayers(), new UpdateProtectedAreasS2CPacket(GameData.getGameData(server).getProtectedAreas(), true));
    }

    public static void updateNewProtectedArea(ServerLevel level, ProtectedArea area) {
        ModChannels.UPDATE_PROTECTED_AREAS_S2C_CHANNEL.sendToPlayers(level.getServer().getPlayerList().getPlayers(), new UpdateProtectedAreasS2CPacket(Map.of(level.dimension().location().toString(), List.of(area)), false));
    }

    public static void requestCreateProtectedArea(Area area) {
        ModChannels.CREATE_PROTECTED_AREA_C2S_CHANNEL.sendToServer(new CreateProtectedAreaC2SRequest(area));
    }

    public static void syncPlayerData(Player player) {
        if (player instanceof ServerPlayer serverPlayer) {
            ModChannels.SYNC_PLAYER_DATA_CHANNEL.sendToPlayer(serverPlayer, new SyncPlayerDataPacket(ClientCachedData.get(serverPlayer)));
        } else {
            ModChannels.SYNC_PLAYER_DATA_CHANNEL.sendToServer(new SyncPlayerDataPacket(ClientGameManager.getInstance().getCachedData()));
        }
    }

    public static void requestSync(RequestSyncC2SPacket.Type type) {
        ModChannels.REQUEST_SYNC_C2S_CHANNEL.sendToServer(new RequestSyncC2SPacket(type));
    }

    public static void requestReloadGlobeConfig() {
        ModChannels.RELOAD_GLOBE_CONFIG_C2S_CHANNEL.sendToServer(new ReloadGlobeConfigC2SPacket());
    }

    public static void requestModifyGlobeConfig(String key, String value, ModifyGlobeConfigC2SRequest.Action action) {
        ModChannels.MODIFY_GLOBE_CONFIG_C2S_CHANNEL.sendToServer(new ModifyGlobeConfigC2SRequest(key, value, action));
    }

    public static void updateProtectedBlocks(Iterable<ServerPlayer> players, Map<BlockPos, BlockState> updates) {
        ModChannels.PROTECTED_BLOCK_UPDATE_S2C_CHANNEL.sendToPlayers(players, new ProtectedBlocksUpdateS2CPacket(updates));
    }

    public static void requestInterruptActivity(int id) {
        ModChannels.INTERRUPT_ACTIVITY_C2S_CHANNEL.sendToServer(new InterruptActivityC2SRequest(id));
    }

    public static void requestCloneBase(int id) {
        ModChannels.CLONE_BASE_C2S_CHANNEL.sendToServer(new CloneBaseC2SRequest(id));
    }

    public static void controlTimer(ServerPlayer player, ControlTimerS2CPacket.Action action) {
        ModChannels.CONTROL_TIMER_S2C_CHANNEL.sendToPlayer(player, new ControlTimerS2CPacket(action));
    }

    public static void requestCreateFunctionArea(BlockPos minPos, BlockPos maxPos) {
        ModChannels.CREATE_FUNCTION_AREA_C2S_CHANNEL.sendToServer(new CreateFunctionAreaC2SRequest(minPos, maxPos));
    }

    public static void updateFunctionAreas(ServerPlayer player) {
        ModChannels.UPDATE_FUNCTION_AREAS_S2C_CHANNEL.sendToPlayer(player, new UpdateFunctionAreasS2CPacket(GameData.getGameData(player).getFunctionAreas(), true));
    }

    public static void updateFunctionAreas(MinecraftServer server) {
        ModChannels.UPDATE_FUNCTION_AREAS_S2C_CHANNEL.sendToPlayers(server.getPlayerList().getPlayers(), new UpdateFunctionAreasS2CPacket(GameData.getGameData(server).getFunctionAreas(), true));
    }

    public static void updateNewFunctionArea(ServerLevel level, FunctionArea area) {
        ModChannels.UPDATE_FUNCTION_AREAS_S2C_CHANNEL.sendToPlayers(level.getServer().getPlayerList().getPlayers(), new UpdateFunctionAreasS2CPacket(Map.of(level.dimension().location().toString(), List.of(area)), false));
    }

    public static void requestModifyFunctionArea(int areaId, FunctionArea area) {
        ModChannels.MODIFY_FUNCTION_AREA_C2S_CHANNEL.sendToServer(new ModifyFunctionAreaC2SRequest(areaId, area));
    }

    public static void requestShowDifference(int id, boolean enabled) {
        ModChannels.SHOW_DIFFERENCE_C2S_CHANNEL.sendToServer(new ShowDifferenceC2SRequest(id, enabled));
    }

    public static void updateDifferentBlocks(Iterable<ServerPlayer> players, int id, Pair<Set<BlockPos>, Set<BlockPos>> blocks) {
        ModChannels.UPDATE_DIFFERENT_BLOCKS_S2C_CHANNEL.sendToPlayers(players, new UpdateDifferentBlocksS2CPacket(id, blocks));
    }
}
