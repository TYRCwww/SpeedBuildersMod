package com.modcustom.moddev.network;

import com.modcustom.moddev.SpeedBuild;
import com.modcustom.moddev.network.c2s.*;
import com.modcustom.moddev.network.s2c.*;
import dev.architectury.networking.NetworkChannel;
import net.minecraft.resources.ResourceLocation;

public class ModChannels {

    public static final NetworkChannel CREATE_ACTIVITY_AREA_C2S_CHANNEL = create("create_area_c2s");
    public static final NetworkChannel UPDATE_ACTIVITY_AREAS_S2C_CHANNEL = create("update_areas_s2c");
    public static final NetworkChannel DELETE_ACTIVITY_AREA_C2S_CHANNEL = create("delete_area_c2s");
    public static final NetworkChannel UPDATE_AREA_CONFIG_S2C_CHANNEL = create("update_area_config_s2c");
    public static final NetworkChannel START_ACTIVITY_C2S_CHANNEL = create("start_activity_c2s");
    public static final NetworkChannel START_ACTIVITY_TIMER_S2C_CHANNEL = create("start_activity_timer_s2c");
    public static final NetworkChannel FINISH_ACTIVITY_S2C_CHANNEL = create("finish_activity_s2c");
    public static final NetworkChannel COUNTDOWN_MESSAGE_S2C_CHANNEL = create("countdown_message_s2c");
    public static final NetworkChannel RESET_ACTIVITY_AREA_C2S_CHANNEL = create("reset_area_c2s");
    public static final NetworkChannel MODIFY_AREA_CONFIG_C2S_CHANNEL = create("modify_area_config_c2s");
    public static final NetworkChannel PREVIEW_ACTIVITY_S2C_CHANNEL = create("preview_activity_s2c");
    public static final NetworkChannel UPDATE_AREA_HISTORY_S2C_CHANNEL = create("update_area_history_s2c");
    public static final NetworkChannel DOUBLE_JUMP_C2S_CHANNEL = create("double_jump_c2s");
    public static final NetworkChannel UPDATE_PROTECTED_AREAS_S2C_CHANNEL = create("update_protected_areas_s2c");
    public static final NetworkChannel CREATE_PROTECTED_AREA_C2S_CHANNEL = create("create_protected_area_c2s");
    public static final NetworkChannel SYNC_PLAYER_DATA_CHANNEL = create("sync_player_data");
    public static final NetworkChannel REQUEST_SYNC_C2S_CHANNEL = create("request_sync_c2s");
    public static final NetworkChannel RELOAD_GLOBE_CONFIG_C2S_CHANNEL = create("reload_globe_config_c2s");
    public static final NetworkChannel MODIFY_GLOBE_CONFIG_C2S_CHANNEL = create("modify_globe_config_c2s");
    public static final NetworkChannel PROTECTED_BLOCK_UPDATE_S2C_CHANNEL = create("protected_block_update_s2c");
    public static final NetworkChannel INTERRUPT_ACTIVITY_C2S_CHANNEL = create("interrupt_activity_c2s");
    public static final NetworkChannel CLONE_BASE_C2S_CHANNEL = create("clone_base_c2s");
    public static final NetworkChannel CONTROL_TIMER_S2C_CHANNEL = create("control_timer_s2c");
    public static final NetworkChannel CREATE_FUNCTION_AREA_C2S_CHANNEL = create("create_function_area_c2s");
    public static final NetworkChannel UPDATE_FUNCTION_AREAS_S2C_CHANNEL = create("update_function_areas_s2c");
    public static final NetworkChannel MODIFY_FUNCTION_AREA_C2S_CHANNEL = create("modify_function_area_c2s");
    public static final NetworkChannel SHOW_DIFFERENCE_C2S_CHANNEL = create("show_difference_c2s");
    public static final NetworkChannel UPDATE_DIFFERENT_BLOCKS_S2C_CHANNEL = create("update_different_blocks_s2c");

    public static void register() {
        CREATE_ACTIVITY_AREA_C2S_CHANNEL.register(CreateActivityAreaC2SRequest.class, CreateActivityAreaC2SRequest::encode, CreateActivityAreaC2SRequest::new, CreateActivityAreaC2SRequest::apply);
        UPDATE_ACTIVITY_AREAS_S2C_CHANNEL.register(UpdateActivityAreasS2CPacket.class, UpdateActivityAreasS2CPacket::encode, UpdateActivityAreasS2CPacket::new, UpdateActivityAreasS2CPacket::apply);
        DELETE_ACTIVITY_AREA_C2S_CHANNEL.register(DeleteActivityAreaC2SRequest.class, DeleteActivityAreaC2SRequest::encode, DeleteActivityAreaC2SRequest::new, DeleteActivityAreaC2SRequest::apply);
        UPDATE_AREA_CONFIG_S2C_CHANNEL.register(UpdateAreaConfigS2CPacket.class, UpdateAreaConfigS2CPacket::encode, UpdateAreaConfigS2CPacket::new, UpdateAreaConfigS2CPacket::apply);
        START_ACTIVITY_C2S_CHANNEL.register(StartActivityC2SRequest.class, StartActivityC2SRequest::encode, StartActivityC2SRequest::new, StartActivityC2SRequest::apply);
        START_ACTIVITY_TIMER_S2C_CHANNEL.register(StartActivityTimerS2CPacket.class, StartActivityTimerS2CPacket::encode, StartActivityTimerS2CPacket::new, StartActivityTimerS2CPacket::apply);
        FINISH_ACTIVITY_S2C_CHANNEL.register(FinishActivityS2CPacket.class, FinishActivityS2CPacket::encode, FinishActivityS2CPacket::new, FinishActivityS2CPacket::apply);
        COUNTDOWN_MESSAGE_S2C_CHANNEL.register(CountdownMessageS2CPacket.class, CountdownMessageS2CPacket::encode, CountdownMessageS2CPacket::new, CountdownMessageS2CPacket::apply);
        RESET_ACTIVITY_AREA_C2S_CHANNEL.register(ResetActivityAreaC2SRequest.class, ResetActivityAreaC2SRequest::encode, ResetActivityAreaC2SRequest::new, ResetActivityAreaC2SRequest::apply);
        MODIFY_AREA_CONFIG_C2S_CHANNEL.register(ModifyAreaConfigC2SRequest.class, ModifyAreaConfigC2SRequest::encode, ModifyAreaConfigC2SRequest::new, ModifyAreaConfigC2SRequest::apply);
        PREVIEW_ACTIVITY_S2C_CHANNEL.register(PreviewActivityS2CPacket.class, PreviewActivityS2CPacket::encode, PreviewActivityS2CPacket::new, PreviewActivityS2CPacket::apply);
        UPDATE_AREA_HISTORY_S2C_CHANNEL.register(UpdateAreaHistoryS2CPacket.class, UpdateAreaHistoryS2CPacket::encode, UpdateAreaHistoryS2CPacket::new, UpdateAreaHistoryS2CPacket::apply);
        DOUBLE_JUMP_C2S_CHANNEL.register(DoubleJumpC2SRequest.class, DoubleJumpC2SRequest::encode, friendlyByteBuf -> new DoubleJumpC2SRequest(), DoubleJumpC2SRequest::apply);
        UPDATE_PROTECTED_AREAS_S2C_CHANNEL.register(UpdateProtectedAreasS2CPacket.class, UpdateProtectedAreasS2CPacket::encode, UpdateProtectedAreasS2CPacket::new, UpdateProtectedAreasS2CPacket::apply);
        CREATE_PROTECTED_AREA_C2S_CHANNEL.register(CreateProtectedAreaC2SRequest.class, CreateProtectedAreaC2SRequest::encode, CreateProtectedAreaC2SRequest::new, CreateProtectedAreaC2SRequest::apply);
        SYNC_PLAYER_DATA_CHANNEL.register(SyncPlayerDataPacket.class, SyncPlayerDataPacket::encode, SyncPlayerDataPacket::new, SyncPlayerDataPacket::apply);
        REQUEST_SYNC_C2S_CHANNEL.register(RequestSyncC2SPacket.class, RequestSyncC2SPacket::encode, RequestSyncC2SPacket::new, RequestSyncC2SPacket::apply);
        RELOAD_GLOBE_CONFIG_C2S_CHANNEL.register(ReloadGlobeConfigC2SPacket.class, ReloadGlobeConfigC2SPacket::encode, friendlyByteBuf -> new ReloadGlobeConfigC2SPacket(), ReloadGlobeConfigC2SPacket::apply);
        MODIFY_GLOBE_CONFIG_C2S_CHANNEL.register(ModifyGlobeConfigC2SRequest.class, ModifyGlobeConfigC2SRequest::encode, ModifyGlobeConfigC2SRequest::new, ModifyGlobeConfigC2SRequest::apply);
        PROTECTED_BLOCK_UPDATE_S2C_CHANNEL.register(ProtectedBlocksUpdateS2CPacket.class, ProtectedBlocksUpdateS2CPacket::encode, ProtectedBlocksUpdateS2CPacket::new, ProtectedBlocksUpdateS2CPacket::apply);
        INTERRUPT_ACTIVITY_C2S_CHANNEL.register(InterruptActivityC2SRequest.class, InterruptActivityC2SRequest::encode, InterruptActivityC2SRequest::new, InterruptActivityC2SRequest::apply);
        CLONE_BASE_C2S_CHANNEL.register(CloneBaseC2SRequest.class, CloneBaseC2SRequest::encode, CloneBaseC2SRequest::new, CloneBaseC2SRequest::apply);
        CONTROL_TIMER_S2C_CHANNEL.register(ControlTimerS2CPacket.class, ControlTimerS2CPacket::encode, ControlTimerS2CPacket::new, ControlTimerS2CPacket::apply);
        CREATE_FUNCTION_AREA_C2S_CHANNEL.register(CreateFunctionAreaC2SRequest.class, CreateFunctionAreaC2SRequest::encode, CreateFunctionAreaC2SRequest::new, CreateFunctionAreaC2SRequest::apply);
        UPDATE_FUNCTION_AREAS_S2C_CHANNEL.register(UpdateFunctionAreasS2CPacket.class, UpdateFunctionAreasS2CPacket::encode, UpdateFunctionAreasS2CPacket::new, UpdateFunctionAreasS2CPacket::apply);
        MODIFY_FUNCTION_AREA_C2S_CHANNEL.register(ModifyFunctionAreaC2SRequest.class, ModifyFunctionAreaC2SRequest::encode, ModifyFunctionAreaC2SRequest::new, ModifyFunctionAreaC2SRequest::apply);
        SHOW_DIFFERENCE_C2S_CHANNEL.register(ShowDifferenceC2SRequest.class, ShowDifferenceC2SRequest::encode, ShowDifferenceC2SRequest::new, ShowDifferenceC2SRequest::apply);
        UPDATE_DIFFERENT_BLOCKS_S2C_CHANNEL.register(UpdateDifferentBlocksS2CPacket.class, UpdateDifferentBlocksS2CPacket::encode, UpdateDifferentBlocksS2CPacket::new, UpdateDifferentBlocksS2CPacket::apply);
    }

    private static NetworkChannel create(String name) {
        return NetworkChannel.create(new ResourceLocation(SpeedBuild.MOD_ID, name));
    }
}
