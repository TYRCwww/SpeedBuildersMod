package com.modcustom.moddev.game;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.area.ActivityArea;
import com.modcustom.moddev.game.data.GameData;
import com.modcustom.moddev.utils.TranslationUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.function.Predicate;

public enum AreaFinder {
    NEAREST {
        @Nullable
        @Override
        public ActivityArea find(Level level, BlockPos pos, Predicate<ActivityArea> predicate) {
            if (level instanceof ServerLevel serverLevel) {
                return GameData.getGameData(serverLevel).getNearestActivityArea(level, pos, 15, predicate);
            } else {
                return ClientGameManager.getInstance().getNearestArea(level, pos, 15, predicate);
            }
        }
    },
    POSITION {
        @Nullable
        @Override
        public ActivityArea find(Level level, BlockPos pos, Predicate<ActivityArea> predicate) {
            if (level instanceof ServerLevel serverLevel) {
                return GameData.getGameData(serverLevel).getActivityArea(level, pos, predicate);
            } else {
                return ClientGameManager.getInstance().getActivityAreas(level, area -> area.contains(pos) && predicate.test(area)).stream().findFirst().orElse(null);
            }
        }
    };

    public MutableComponent getComponent() {
        return TranslationUtil.screenComponent("area_finder." + name().toLowerCase());
    }

    @Nullable
    public ActivityArea find(Level level, BlockPos pos) {
        return find(level, pos, area -> true);
    }

    @Nullable
    public abstract ActivityArea find(Level level, BlockPos pos, Predicate<ActivityArea> predicate);
}
