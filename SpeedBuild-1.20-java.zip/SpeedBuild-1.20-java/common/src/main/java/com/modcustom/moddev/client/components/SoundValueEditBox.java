package com.modcustom.moddev.client.components;

import com.modcustom.moddev.client.screen.PlayerConfigScreen;
import com.modcustom.moddev.game.SoundSetting;
import com.modcustom.moddev.utils.NumberUtil;
import com.modcustom.moddev.utils.TranslationUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.Nullable;

import java.util.function.BiConsumer;
import java.util.function.Function;

@Environment(EnvType.CLIENT)
public abstract class SoundValueEditBox extends EditBox {

    private final Font font;
    private final float defaultValue;
    @Nullable
    private Runnable postResponder;
    private boolean autoSetting = true;

    public SoundValueEditBox(Font font, SoundSetting setting, Component message, float defaultValue, float min, float max, Function<SoundSetting, Float> valueGetter, BiConsumer<SoundSetting, Float> valueSetter) {
        super(font, 0, 0, 50, 20, message);
        this.font = font;
        this.defaultValue = defaultValue;
        this.setValue(Float.toString(valueGetter.apply(setting)));
        this.setFilter(s -> NumberUtil.isFloatBetweenOrEmpty(s, min, max));
        this.setResponder(s -> NumberUtil.getOptionalFloat(s).ifPresent(value -> {
            if (this.isAutoSetting()) {
                valueSetter.accept(setting, value);
            }
            if (this.postResponder != null) this.postResponder.run();
        }));
    }

    public AbstractWidget[] createRow() {
        return new AbstractWidget[]{new StringWidget(getMessage(), this.font).alignCenter(), this, createResetButton(), createIncreaseButton(), createDecreaseButton()};
    }

    public Button createResetButton() {
        return Button.builder(TranslationUtil.screenComponent("reset_button"), button -> setValue(Float.toString(defaultValue))).bounds(0, 0, 50, 20).build();
    }

    public Button createIncreaseButton() {
        return Button.builder(Component.literal("+"), button -> NumberUtil.getOptionalDouble(getValue()).ifPresent(value -> setValue(PlayerConfigScreen.toFormattedString(value + (Screen.hasShiftDown() ? 1.0 : 0.1))))).size(20, 20).build();
    }

    public Button createDecreaseButton() {
        return Button.builder(Component.literal("-"), button -> {
            NumberUtil.getOptionalDouble(getValue()).ifPresent(value -> setValue(PlayerConfigScreen.toFormattedString(value - (Screen.hasShiftDown() ? 1.0 : 0.1))));
        }).size(20, 20).build();
    }

    public void setPostResponder(@Nullable Runnable postResponder) {
        this.postResponder = postResponder;
    }

    public boolean isAutoSetting() {
        return autoSetting;
    }

    public void setAutoSetting(boolean autoSetting) {
        this.autoSetting = autoSetting;
    }

    public static class Volume extends SoundValueEditBox {

        public Volume(Font font, SoundSetting setting, Component message) {
            this(font, setting, message, 1f);
        }

        public Volume(Font font, SoundSetting setting, Component message, float defaultValue) {
            super(font, setting, message, defaultValue, 0f, Float.MAX_VALUE, SoundSetting::getVolume, SoundSetting::setVolume);
        }
    }

    public static class Pitch extends SoundValueEditBox {

        public Pitch(Font font, SoundSetting setting, Component message) {
            this(font, setting, message, 1f);
        }

        public Pitch(Font font, SoundSetting setting, Component message, float defaultValue) {
            super(font, setting, message, defaultValue, 0f, 2f, SoundSetting::getPitch, SoundSetting::setPitch);
        }
    }
}
