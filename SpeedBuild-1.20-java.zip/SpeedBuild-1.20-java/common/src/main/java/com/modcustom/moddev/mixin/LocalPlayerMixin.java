package com.modcustom.moddev.mixin;

import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.config.SneakTweakConfig;
import com.modcustom.moddev.events.BlockEventHandler;
import com.modcustom.moddev.game.area.FunctionArea;
import com.modcustom.moddev.game.area.ProtectedArea;
import com.modcustom.moddev.utils.TranslationUtil;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(LocalPlayer.class)
public class LocalPlayerMixin extends AbstractClientPlayer {

    private LocalPlayerMixin(ClientLevel world, GameProfile profile) {
        super(world, profile);
    }

    @Redirect(method = "aiStep", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;isSwimming()Z", ordinal = 2))
    private boolean onAiStep(LocalPlayer instance) {
        if (ClientGameManager.getInstance().getCachedData().isExtraJumpEnabled()) {
            return true;
        }
        return instance.isSwimming();
    }

    @Override
    public boolean blockActionRestricted(Level level, BlockPos pos, GameType gameMode) {
        if (ProtectedArea.isProtected(level, pos)) {
            Minecraft.getInstance().gui.setOverlayMessage(TranslationUtil.messageComponent("protected_area.break_block"), false);
            return true;
        } else if (FunctionArea.isLocked(level, pos)) {
//            Minecraft.getInstance().gui.setOverlayMessage(TranslationUtil.messageComponent("function_area.break_block"), false);
            return true;
        } else if (gameMode == GameType.ADVENTURE) {
            return !BlockEventHandler.allowAdventureBlockAction(level, pos);
        }
        return super.blockActionRestricted(level, pos, gameMode);
    }

    @Override
    public float getStandingEyeHeight(Pose pose, EntityDimensions dimensions) {
        float height = super.getStandingEyeHeight(pose, dimensions);
        if (pose == Pose.CROUCHING && canEnterPose(Pose.STANDING)) {
            height = SneakTweakConfig.getInstance().modifySneakingEyeHeight(height);
        }
        return height;
    }
}
