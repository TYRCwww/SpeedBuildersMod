package com.modcustom.moddev.network;

import com.modcustom.moddev.api.NetworkPacket;
import com.modcustom.moddev.client.ClientGameManager;
import com.modcustom.moddev.game.data.ClientCachedData;
import com.modcustom.moddev.game.data.PlayerData;
import dev.architectury.networking.NetworkManager;
import dev.architectury.utils.Env;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

import java.util.function.Supplier;

public class SyncPlayerDataPacket implements NetworkPacket {

    private final ClientCachedData data;

    public SyncPlayerDataPacket(FriendlyByteBuf buf) {
        this(new ClientCachedData());
        CompoundTag nbt = buf.readAnySizeNbt();
        if (nbt == null) {
            throw new IllegalArgumentException("Invalid data");
        }
        this.data.load(nbt);
    }

    public SyncPlayerDataPacket(ClientCachedData data) {
        this.data = data;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeNbt(data.toNbt());
    }

    @Override
    public void apply(Supplier<NetworkManager.PacketContext> contextSupplier) {
        NetworkManager.PacketContext context = contextSupplier.get();
        Player player = context.getPlayer();

        if (context.getEnvironment() == Env.CLIENT) {
            ClientGameManager.getInstance().setCachedData(data);
        } else if (player instanceof ServerPlayer serverPlayer) {
            PlayerData.get(serverPlayer).readData(data);
        }
    }
}
