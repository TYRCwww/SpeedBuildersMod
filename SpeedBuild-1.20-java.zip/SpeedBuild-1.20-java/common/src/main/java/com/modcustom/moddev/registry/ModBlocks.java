package com.modcustom.moddev.registry;

import com.modcustom.moddev.blocks.TranslucentBlock;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;

import static com.modcustom.moddev.SpeedBuild.MOD_ID;

public class ModBlocks {

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(MOD_ID, Registries.BLOCK);

    public static final RegistrySupplier<Block> TRANSLUCENT_BLOCK = BLOCKS.register("translucent_block", () -> new TranslucentBlock(Block.Properties.of().noOcclusion().instrument(NoteBlockInstrument.HAT).sound(SoundType.GLASS).strength(-1, 3600000.0f).noLootTable().noParticlesOnBreak().lightLevel(value -> 12).isValidSpawn(ModBlocks::never).isRedstoneConductor(ModBlocks::never).isSuffocating(ModBlocks::never).isViewBlocking(ModBlocks::never)));

    private static boolean never(BlockState state, BlockGetter blockGetter, BlockPos blockPos) {
        return false;
    }

    private static Boolean never(BlockState state, BlockGetter blockGetter, BlockPos pos, EntityType<?> entity) {
        return false;
    }

    public static void register() {
        BLOCKS.register();
    }
}
