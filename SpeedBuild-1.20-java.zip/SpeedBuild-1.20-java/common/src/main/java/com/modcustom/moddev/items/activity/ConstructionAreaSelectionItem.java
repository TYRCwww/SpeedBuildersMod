package com.modcustom.moddev.items.activity;

import com.modcustom.moddev.items.AreaVisibleItem;

public class ConstructionAreaSelectionItem extends AreaVisibleItem {

    public ConstructionAreaSelectionItem(Properties properties) {
        super(properties);
    }
}
