package com.modcustom.moddev.api;

import dev.architectury.networking.NetworkManager.PacketContext;
import io.netty.buffer.Unpooled;
import net.minecraft.network.FriendlyByteBuf;

import java.util.function.Supplier;

public interface NetworkPacket {

    int MAX_PAYLOAD_SIZE = 0x100000;

    default boolean isOverflowing() {
        return getSize() > MAX_PAYLOAD_SIZE;
    }

    default int getSize() {
        FriendlyByteBuf buf = new FriendlyByteBuf(Unpooled.buffer());
        encode(buf);
        return buf.readableBytes();
    }

    void encode(FriendlyByteBuf buf);

    void apply(Supplier<PacketContext> contextSupplier);
}
