package com.modcustom.moddev.forge;

import com.modcustom.moddev.SpeedBuild;
import com.modcustom.moddev.SpeedBuildClient;
import com.modcustom.moddev.api.LevelRenderLastEvent;
import dev.architectury.platform.forge.EventBuses;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(SpeedBuild.MOD_ID)
public class SpeedBuildForge {

    public SpeedBuildForge() {
        EventBuses.registerModEventBus(SpeedBuild.MOD_ID, FMLJavaModLoadingContext.get().getModEventBus());
        SpeedBuild.init();
        DistExecutor.safeRunWhenOn(Dist.CLIENT, () -> ForgeClient::init);
        DistExecutor.safeRunWhenOn(Dist.CLIENT, () -> SpeedBuildClient::init);
    }

    private static class ForgeClient {

        static void init() {
            MinecraftForge.EVENT_BUS.<RenderLevelStageEvent>addListener(event -> {
                if (event.getStage() == RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) {
                    LevelRenderLastEvent.EVENT.invoker().onRenderLast(event.getPoseStack());
                }
            });
        }
    }
}